// NewobjDlg.cpp : implementation file
//

#include "stdafx.h"
#include "T3ED.h"
#include "T3EDDoc.h"
#include "NewobjDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewobjDlg dialog


CNewobjDlg::CNewobjDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewobjDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewobjDlg)
	m_chunk = -1;
	m_xobj = -1;
	m_texture = 0;
	//}}AFX_DATA_INIT
	m_chunk=0;
	m_xobj=0;
	m_flags=0;
}


void CNewobjDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewobjDlg)
	DDX_Radio(pDX, IDC_CHUNK0, m_chunk);
	DDX_Radio(pDX, IDC_RADIO1, m_xobj);
	DDX_Text(pDX, IDC_EDIT1, m_texture);
	//}}AFX_DATA_MAP
	DDV_MinMaxInt(pDX, m_texture, 0, qfs->nColEntries-1);
}


BEGIN_MESSAGE_MAP(CNewobjDlg, CDialog)
	//{{AFX_MSG_MAP(CNewobjDlg)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewobjDlg message handlers

void CNewobjDlg::OnBrowse() 
{
	BOOL isok;
	int res;

	res=GetDlgItemInt(IDC_EDIT1,&isok,TRUE);
	if (!isok||(res<0)||(res>=qfs->nColEntries)) res=0;
	qfs->m_nBmp=res;
	qfs->m_flags=m_flags;
	if (qfs->DoModal()!=IDOK) return;
	SetDlgItemInt(IDC_EDIT1,qfs->m_nBmp,TRUE);
	m_flags=qfs->m_flags;
}
