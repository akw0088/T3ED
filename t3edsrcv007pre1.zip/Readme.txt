========================================================================
       T3ED - Version 0.07pre1.1 - (c) Denis Auroux, 1998-99,2001
========================================================================

e-mail: auroux@math.polytechnique.fr
http://www.math.polytechnique.fr/cmat/auroux/nfs/
http://auroux.free.fr/nfs/

Release date : January 24, 2001

THIS IS NOT A FULLY STABLE RELEASE VERSION. NO HELP IS PROVIDED
CONCERNING THE NEW FEATURES OF THIS VERSION OF T3ED.

Added in Version 0.07pre1.1 :

- Multiple selection in point, polygon and object modes.
  Press Control or Shift while clicking in order to add to the current
  selection.

- Multiple selection support for the Move XY and Move Z tools.
  Note that you must keep the Control or Shift key pressed when you
  click to move the selected items, otherwise the multiple selection
  is lost.

- Multiple selection support for the Polygon flags and Textures dialog
  boxes in polygon mode.

- Light sources are handled as objects: in object mode they can be
  selected, moved, duplicated and deleted.

- Texture Properties dialog box accessible from Textures dialog box
  (in NFSHS mode only).

If you are looking for a stable release of T3ED, please download
version 0.06 at one of the above-mentioned web sites.
