// T3EDDoc.cpp : implementation of the CT3EDDoc class
//

#include "stdafx.h"
#include "T3ED.h"
#include <math.h>

#include "T3EDDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CT3EDDoc

IMPLEMENT_DYNCREATE(CT3EDDoc, CDocument)

BEGIN_MESSAGE_MAP(CT3EDDoc, CDocument)
	//{{AFX_MSG_MAP(CT3EDDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CT3EDDoc construction/destruction

CT3EDDoc::CT3EDDoc()
{
	ASSERT(sizeof(struct FLOATPT)==12);
	ASSERT(sizeof(struct INTPT)==12);
	ASSERT(sizeof(struct NEIGHBORDATA)==4);
	ASSERT(sizeof(struct POSITIONDATA)==8);
//	ASSERT(sizeof(struct POLYVROADDATA)==8); no longer true !
	ASSERT(sizeof(struct VROADDATA)==12);
	ASSERT(sizeof(struct REFXOBJ)==20);
//	ASSERT(sizeof(struct REFPOLYOBJ)==20);
	ASSERT(sizeof(struct SOUNDSRC)==16);
	ASSERT(sizeof(struct LIGHTSRC)==16);
	ASSERT(sizeof(struct POLYGONDATA)==14);
	ASSERT(sizeof(struct ANIMDATA)==20);
	ASSERT(sizeof(struct XBHEAD)==8);
	ASSERT(sizeof(struct COLTEXTUREINFO)==8);
	ASSERT(sizeof(struct COLVERTEX)==16);
	ASSERT(sizeof(struct COLPOLYGON)==6);
	ASSERT(sizeof(struct COLVECTOR)==4);
	ASSERT(sizeof(struct COLVROAD)==36);
	bEmpty=TRUE;
	undoLevel=0;
}

CT3EDDoc::~CT3EDDoc()
{
	// clean the embedded QFS stock bitmaps
	for (int i=0;i<14;i++)
		if (qfsView.pStockBitmaps[i]!=NULL)
			::DeleteObject(qfsView.pStockBitmaps[i]);
}

BOOL CT3EDDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	bEmpty=TRUE;
	undoLevel=0;
	SendInitialUpdate(); // reset the view
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CT3EDDoc serialization

BOOL CT3EDDoc::LoadHSFRD(CArchive& ar,long nPos)
{
	int i,j,k,l,m,remn;
	struct TRKBLOCK *b;
	struct POLYGONBLOCK *p;
	struct XOBJDATA *x;
	struct OBJPOLYBLOCK *o;
	struct COLVROAD *vr;
	struct HS_VROADBLOCK vroadblk;
	struct VROADDATA *v;
	LPPOLYGONDATA pp;
	short *vno;
	unsigned char ptrspace[44]; // some useless data from HS FRDs
	struct FLOATPT v1,v2,norm;
	unsigned char *belong;
	float len;
	struct POLYGONDATA tmppoly;

	// emulate the COL file
	memcpy(col.collID,"COLL",4);
	col.version=11;
	col.fileLength=36*nPos+48;
	col.nBlocks=2;
	col.xbTable[0]=8; col.xbTable[1]=24;
	// fake a texture table with only one entry to please NFS3/T3ED
	col.textureHead.size=16;
	col.textureHead.xbid=XBID_TEXTUREINFO;
	col.textureHead.nrec=1;
	col.texture=(struct COLTEXTUREINFO *) malloc(sizeof(struct COLTEXTUREINFO));
	if (col.texture==NULL) return FALSE;
	memset(col.texture,0,8);
	// vroad XB
	col.vroadHead.size=8+36*nPos;
	col.vroadHead.xbid=XBID_VROAD;
	col.vroadHead.nrec=(short)nPos;
	col.vroad=(struct COLVROAD *)malloc(nPos*sizeof(struct COLVROAD));
	if (col.vroad==NULL) return FALSE;
	col.hs_extra=(long *)malloc(7*nPos*sizeof(long));
	if (col.hs_extra==NULL) return FALSE;
	for (i=0,vr=col.vroad;i<nPos;i++,vr++) {
		if (ar.Read(&vroadblk,84)!=84) return FALSE;
		vr->refPt.x=(long)(vroadblk.refPt.x*65536);
		vr->refPt.z=(long)(vroadblk.refPt.z*65536);
		vr->refPt.y=(long)(vroadblk.refPt.y*65536);
		// a wild guess
		vr->unknown=(long)((vroadblk.unknown2[3]&0xFFFF)+       // unknownLanes[2]
			               ((vroadblk.unknown2[4]&0xF)<<16)+    // wallKinds[0]
						   ((vroadblk.unknown2[4]&0xF00)<<20)); // wallKinds[1]
		if (vroadblk.normal.x>=1.0) vr->normal.x=127;
		else vr->normal.x=(signed char)(vroadblk.normal.x*128);
		if (vroadblk.normal.z>=1.0) vr->normal.z=127;
		else vr->normal.z=(signed char)(vroadblk.normal.z*128);
		if (vroadblk.normal.y>=1.0) vr->normal.y=127;
		else vr->normal.y=(signed char)(vroadblk.normal.y*128);
		if (vroadblk.forward.x>=1.0) vr->forward.x=127;
		else vr->forward.x=(signed char)(vroadblk.forward.x*128);
		if (vroadblk.forward.z>=1.0) vr->forward.z=127;
		else vr->forward.z=(signed char)(vroadblk.forward.z*128);
		if (vroadblk.forward.y>=1.0) vr->forward.y=127;
		else vr->forward.y=(signed char)(vroadblk.forward.y*128);
		if (vroadblk.right.x>=1.0) vr->right.x=127;
		else vr->right.x=(signed char)(vroadblk.right.x*128);
		if (vroadblk.right.z>=1.0) vr->right.z=127;
		else vr->right.z=(signed char)(vroadblk.right.z*128);
		if (vroadblk.right.y>=1.0) vr->right.y=127;
		else vr->right.y=(signed char)(vroadblk.right.y*128);
		vr->leftWall=(long)(vroadblk.leftWall*65536);
		vr->rightWall=(long)(vroadblk.rightWall*65536);
		memcpy(col.hs_extra+7*i,&(vroadblk.unknown1[0]),28);
	}

	// TRKBLOCKs
	for (i=0;i<nBlocks;i++) {
		b=&(trk[i]);
		p=&(poly[i]);
		// 7 track polygon numbers
		if (ar.Read(p->sz,28)!=28) return FALSE;
		memcpy(p->szdup,p->sz,28);
		// 4 object polygon numbers
		for (j=0;j<4;j++) if (ar.Read(&(p->obj[j].n1),4)!=4) return FALSE;
		// pointer space
		if (ar.Read(ptrspace,44)!=44) return FALSE;
		// 6 nVertices
		if (ar.Read(&(b->nVertices),24)!=24) return FALSE;
		if ((b->nVertices<0)/*||(b->nVertices>1000)*/) return FALSE;
		// pointer space
		if (ar.Read(ptrspace,8)!=8) return FALSE;
		// ptCentre, ptBounding == 60 bytes
		if (ar.Read(b,60)!=60) return FALSE;
		// nbdData
		if (ar.Read(b->nbdData,4*0x12C)!=4*0x12C) return FALSE;
		// xobj numbers
		for (j=4*i;j<4*i+4;j++) {
			if (ar.Read(&(xobj[j].nobj),4)!=4) return FALSE;
			if (ar.Read(ptrspace,4)!=4) return FALSE;
		}
		// nVRoad is not the same as in NFS3, will change later
		if (ar.Read(&(b->nVRoad),4)!=4) return FALSE;
		// 2 unknown specific FLOATPTs
		if (ar.Read(&(b->hs_ptMin),24)!=24) return FALSE;
		if (ar.Read(ptrspace,4)!=4) return FALSE;
		// nPositions
		if (ar.Read(&(b->nPositions),4)!=4) return FALSE;
		if (i==0) b->nStartPos=0;
		else b->nStartPos=trk[i-1].nStartPos+trk[i-1].nPositions;
		b->nPolygons=p->sz[4];
		// nXobj etc...
		if (ar.Read(&(b->nXobj),4)!=4) return FALSE;
		if (ar.Read(ptrspace,4)!=4) return FALSE;
		if (ar.Read(&(b->nPolyobj),4)!=4) return FALSE;
		if (ar.Read(ptrspace,4)!=4) return FALSE;
		if (ar.Read(&(b->nSoundsrc),4)!=4) return FALSE;
		if (ar.Read(ptrspace,4)!=4) return FALSE;
		if (ar.Read(&(b->nLightsrc),4)!=4) return FALSE;
		if (ar.Read(ptrspace,4)!=4) return FALSE;
		// neighbor data
		if (ar.Read(b->hs_neighbors,32)!=32) return FALSE;
	}
	
	// TRKBLOCKDATA
	for (i=0;i<nBlocks;i++) {
		b=&(trk[i]);
		p=&(poly[i]);
		// vertices
		b->vert=(struct FLOATPT *)malloc(b->nVertices*sizeof(struct FLOATPT));
		if (b->vert==NULL) return FALSE;
		if ((long)ar.Read(b->vert,12*b->nVertices)!=12*b->nVertices) return FALSE;
		b->unknVertices=(long *)malloc(b->nVertices*sizeof(long));
		if (b->unknVertices==NULL) return FALSE;
		if ((long)ar.Read(b->unknVertices,4*b->nVertices)!=4*b->nVertices) return FALSE;
		// polyData is a bit tricky
		b->polyData=(struct POLYVROADDATA *)malloc(b->nPolygons*sizeof(struct POLYVROADDATA));
		if (b->polyData==NULL) return FALSE;
		memset(b->polyData,0,b->nPolygons*sizeof(struct POLYVROADDATA));
		b->vroadData=(struct VROADDATA *)malloc(b->nPolygons*sizeof(struct VROADDATA));
		if (b->vroadData==NULL) return FALSE;
		for (j=0;j<b->nPolygons;j++) {
			b->polyData[j].vroadEntry=j;
			b->polyData[j].flags=0xE; // not passable
		}
		for (j=0;j<b->nVRoad;j++) {
			if (ar.Read(ptrspace,10)!=10) return FALSE;
			k=0;
			if (ar.Read(&k,2)!=2) return FALSE;
			memcpy(b->polyData[k].hs_minmax,ptrspace,8);
			b->polyData[k].flags=ptrspace[8];
			b->polyData[k].hs_unknown=ptrspace[9];
			if ((ptrspace[8]&15)==14) return FALSE;
			if (ar.Read(b->vroadData+k,12)!=12) return FALSE;
		}
		b->nVRoad=b->nPolygons;

		// the 4 misc. tables
		if (b->nXobj>0) {
			b->xobj=(struct REFXOBJ *)malloc(b->nXobj*sizeof(struct REFXOBJ));
			if (b->xobj==NULL) return FALSE;
			if ((long)ar.Read(b->xobj,20*b->nXobj)!=20*b->nXobj) return FALSE;
			// crossindex is f***ed up, but we don't really care
		}
		if (b->nPolyobj>0) {
			char *buffer=(char *)malloc(b->nPolyobj*20);
			if ((long)ar.Read(buffer,20*b->nPolyobj)!=20*b->nPolyobj) return FALSE;
			free(buffer);
		}
		b->nPolyobj=0;
		if (b->nSoundsrc>0) {
			b->soundsrc=(struct SOUNDSRC *)malloc(b->nSoundsrc*sizeof(struct SOUNDSRC));
			if (b->soundsrc==NULL) return FALSE;
			if ((long)ar.Read(b->soundsrc,16*b->nSoundsrc)!=16*b->nSoundsrc) return FALSE;
		}
		if (b->nLightsrc>0) {
			b->lightsrc=(struct LIGHTSRC *)malloc(b->nLightsrc*sizeof(struct LIGHTSRC));
			if (b->lightsrc==NULL) return FALSE;
			if ((long)ar.Read(b->lightsrc,16*b->nLightsrc)!=16*b->nLightsrc) return FALSE;
		}

		// track polygons
		for (j=0;j<7;j++) if (p->sz[j]!=0) {
			p->poly[j]=(LPPOLYGONDATA)malloc(p->sz[j]*sizeof(struct POLYGONDATA));
			if (p->poly[j]==NULL) return FALSE;
			for (k=0;k<p->sz[j];k++) {
				if (ar.Read(&tmppoly,13)!=13) return FALSE;
				for (m=0;m<4;m++) p->poly[j][k].vertex[m]=tmppoly.vertex[m^1];
				memcpy(&(p->poly[j][k].texture),&(tmppoly.texture),5);
				p->poly[j][k].unknown2=0xF9;
			}
		}

		// make up some fake posData
		b->posData=(struct POSITIONDATA *)malloc(b->nPositions*sizeof(struct POSITIONDATA));
		if (b->posData==NULL) return FALSE;
		k=0; pp=p->poly[4];
		for (j=0;j<b->nPositions;j++) {
			b->posData[j].polygon=k;
			b->posData[j].unknown=0;
			b->posData[j].extraNeighbor1=-1;
			b->posData[j].extraNeighbor2=-1;
			do {
				l=0;
				do { if ((b->polyData[k].flags&0x0f)%14) l++; k++; pp++; }
				while ((k<b->nPolygons)&&(pp->vertex[0]==(pp-1)->vertex[1])&&(pp->vertex[3]==(pp-1)->vertex[2]));
				if (((j==b->nPositions-1)&&(k<b->nPolygons))||(k>b->nPolygons)) {
//					MessageBeep(MB_ICONEXCLAMATION);
//					afxDump << "failed " << i << " : " << k << " instead of " << b->nPolygons << "\n";
//					for (l=0;l<b->nPositions;l++) afxDump << b->posData[l].polygon << " ";
//					afxDump << "\n";
					k=b->nPolygons;
				}
			} while ((l==0)&&(k<b->nPolygons));
			b->posData[j].nPolygons=k-b->posData[j].polygon;
		}
		
		// still vroadData is missing for unpassable polygons
		for (j=0;j<b->nPolygons;j++) 
			if (b->polyData[j].flags==0xE) {
				v=b->vroadData+j;
				vno=p->poly[4][j].vertex;
				v1.x=b->vert[vno[1]].x-b->vert[vno[3]].x;
				v1.z=b->vert[vno[1]].z-b->vert[vno[3]].z;
				v1.y=b->vert[vno[1]].y-b->vert[vno[3]].y;
				v2.x=b->vert[vno[2]].x-b->vert[vno[0]].x;
				v2.z=b->vert[vno[2]].z-b->vert[vno[0]].z;
				v2.y=b->vert[vno[2]].y-b->vert[vno[0]].y;
				norm.x=-v1.y*v2.z+v1.z*v2.y;
				norm.y=-v1.z*v2.x+v1.x*v2.z;
				norm.z=-v1.x*v2.y+v1.y*v2.x;
				len=(float)sqrt(norm.x*norm.x+norm.y*norm.y+norm.z*norm.z);
				v->xNorm=(short)(norm.x*32767/len);
				v->zNorm=(short)(norm.z*32767/len);
				v->yNorm=(short)(norm.y*32767/len);
				v1.x=(float)col.vroad[b->nStartPos].forward.x; 
				v1.z=(float)col.vroad[b->nStartPos].forward.z; 
				v1.y=(float)col.vroad[b->nStartPos].forward.y; 
				len=(float)sqrt(v1.x*v1.x+v1.y*v1.y+v1.z*v1.z);
				v->xForw=(short)(v1.x*32767/len);
				v->zForw=(short)(v1.z*32767/len);
				v->yForw=(short)(v1.y*32767/len);
			}

		// POLYGONBLOCK OBJECTS
		o=p->obj;
		belong=(unsigned char*)malloc(b->nObjectVert);
		if (belong==NULL) return FALSE;
		for (j=0;j<4;j++,o++) if (o->n1>0) {
			memset(belong,0xFF,b->nObjectVert);
			pp=(LPPOLYGONDATA)malloc(14*o->n1);
			if (pp==NULL) return FALSE;
			for (k=0;k<o->n1;k++) {
				if (ar.Read(&tmppoly,13)!=13) return FALSE;
				for (m=0;m<4;m++) pp[k].vertex[m]=tmppoly.vertex[m^1];
				memcpy(&(pp[k].texture),&(tmppoly.texture),5);
				pp[k].unknown2=0xFF; // will temporarily store object's #
			}
			remn=o->n1; o->nobj=0;
			while (remn>0) {  // there are still polygons to be connected
				k=0; while (pp[k].unknown2!=0xFF) k++;
				pp[k].unknown2=(unsigned char)o->nobj;
				remn--;
				for (l=0;l<4;l++) belong[pp[k].vertex[l]]=(unsigned char)o->nobj;
				do {
					m=0;
					for (k=0;k<o->n1;k++) if (pp[k].unknown2==0xFF) {
						for (l=0;l<4;l++)
							if (belong[pp[k].vertex[l]]==(unsigned char)o->nobj) break;
						if (l<4) {
							remn--; m++;
							pp[k].unknown2=(unsigned char)o->nobj;
							for (l=0;l<4;l++)
								belong[pp[k].vertex[l]]=(unsigned char)o->nobj;
						}
					}
				} while (m>0); // we've been adding more polygons
				o->nobj++;
			}
			o->n2=o->nobj+xobj[4*i+j].nobj;
			o->types=(long *)malloc(o->n2*sizeof(long));
			if (o->types==NULL) return FALSE;
			o->numpoly=(long *)malloc(o->nobj*sizeof(long));
			if (o->numpoly==NULL) return FALSE;
			o->poly=(LPPOLYGONDATA *)malloc(4*o->nobj);
			if (o->poly==NULL) return FALSE;
			memset(o->poly,0,4*o->nobj);
			for (l=0;l<o->nobj;l++) {
				remn=0; 
				for (k=0;k<o->n1;k++) if (pp[k].unknown2==l) remn++;
				o->numpoly[l]=remn;
				o->poly[l]=(LPPOLYGONDATA)malloc(remn*sizeof(struct POLYGONDATA));
				if (o->poly[l]==NULL) return FALSE;
				remn=0;
				for (k=0;k<o->n1;k++) if (pp[k].unknown2==l) {
					memcpy(o->poly[l]+remn,pp+k,sizeof(struct POLYGONDATA));
					o->poly[l][remn].unknown2=0xF9;
					remn++;
				}
			}
			free(pp);
			// there used to be something with REFPOLYOBJs if chunk 0
			for (k=0;k<o->nobj;k++)
				o->types[k]=1;
			for (k=o->nobj;k<o->n2;k++)
				o->types[k]=4; // to be replaced by 3/... later
		}
		free(belong);

	// XOBJs
		for (j=4*i;j<4*i+4;j++) if (xobj[j].nobj>0) {
			xobj[j].obj=(struct XOBJDATA *)malloc(xobj[j].nobj*sizeof(struct XOBJDATA));
			if (xobj[j].obj==NULL) return FALSE;
			memset(xobj[j].obj,0,xobj[j].nobj*sizeof(struct XOBJDATA));
			for (k=0;k<xobj[j].nobj;k++) {
				x=&(xobj[j].obj[k]);
				// 3 headers == 12 bytes 
				if (ar.Read(x,12)!=12) return FALSE;
				if ((x->crosstype==4)||(x->crosstype==2)) // basic objects
					{ if (ar.Read(&(x->ptRef),12)!=12) return FALSE; }
				else if (x->crosstype==3) { // animated objects
					// unkn3 instead of ptRef
					if (ar.Read(x->unknown3,12)!=12) return FALSE;
				}
				else return FALSE; // unknown object type
				if (p->obj[j&3].nobj!=0)
					p->obj[j&3].types[p->obj[j&3].nobj+k]=x->crosstype;
				// common part : vertices & polygons
				if (ar.Read(&(x->unknown2),4)!=4) return FALSE;
				if (ar.Read(ptrspace,4)!=4) return FALSE;
				if (ar.Read(&(x->nVertices),4)!=4) return FALSE;
				if (ar.Read(ptrspace,8)!=8) return FALSE;
				x->vert=(struct FLOATPT *)malloc(12*x->nVertices);
				if (x->vert==NULL) return FALSE;
				x->unknVertices=(long *)malloc(4*x->nVertices);
				if (x->unknVertices==NULL) return FALSE;
				if (ar.Read(&(x->nPolygons),4)!=4) return FALSE;
				if (ar.Read(ptrspace,4)!=4) return FALSE;
				x->polyData=(struct POLYGONDATA *)malloc(x->nPolygons*14);
				if (x->polyData==NULL) return FALSE;
			}
			// now the xobjdata
			for (k=0;k<xobj[j].nobj;k++) {
				x=&(xobj[j].obj[k]);
				if (x->crosstype==3) { // animated-specific header
					if (ar.Read(x->unknown3+6,2)!=2) return FALSE;
					// if (x->unknown3[6]!=4) return FALSE;  // fails
					// type3, objno, animLength, unknown4
					if (ar.Read(&(x->type3),6)!=6) return FALSE;
					if (x->type3!=3) return FALSE;
					x->animData=(struct ANIMDATA *)malloc(20*x->nAnimLength);
					if (x->animData==NULL) return FALSE;
					if ((long)ar.Read(x->animData,20*x->nAnimLength)!=20*x->nAnimLength) return FALSE;
					// make a ref point from first anim position
					x->ptRef.x=(float)(x->animData->pt.x/65536.0);
					x->ptRef.z=(float)(x->animData->pt.z/65536.0);
					x->ptRef.y=(float)(x->animData->pt.y/65536.0);
				}
// appears in REFPOLYOBJ & REFXOBJ but not in XOBJs !
/*				if (x->crosstype==6) { // object with byte data
					x->hs_type6=(char *)malloc(x->unknown2);
					if ((long)ar.Read(x->hs_type6,x->unknown2)!=x->unknown2) return FALSE;
				}
*/				if ((long)ar.Read(x->vert,12*x->nVertices)!=12*x->nVertices) return FALSE;
				if ((long)ar.Read(x->unknVertices,4*x->nVertices)!=4*x->nVertices) return FALSE;
				for (l=0;l<x->nPolygons;l++) {
					if (ar.Read(&tmppoly,13)!=13) return FALSE;
					for (m=0;m<4;m++) x->polyData[l].vertex[m]=tmppoly.vertex[m^1];
					memcpy(&(x->polyData[l].texture),&(tmppoly.texture),5);
					x->polyData[l].unknown2=0xF9;
				}
			}
		}
	}

	// remainder of the FRD file
	hs_morexobj=(char *)malloc(100000); // no more than 100K, I hope !
	hs_morexobjlen=ar.Read(hs_morexobj,100000);
	if (hs_morexobjlen==100000) return FALSE;
	hs_morexobj=(char *)realloc(hs_morexobj,hs_morexobjlen);

	// TEXTUREBLOCKs
	m=0;
	for (i=0;i<nBlocks;i++) {
		for (j=0;j<7;j++) 
			for (k=0,pp=poly[i].poly[j];k<poly[i].sz[j];k++,pp++)
				if (pp->texture>m) m=pp->texture;
		for (j=0;j<4;j++)
			for (k=0;k<poly[i].obj[j].nobj;k++)
				for (l=0,pp=poly[i].obj[j].poly[k];l<poly[i].obj[j].numpoly[k];l++,pp++)
					if (pp->texture>m) m=pp->texture;
	}
	for (i=0;i<4*nBlocks;i++)
		for (j=0;j<xobj[i].nobj;j++)
			for (k=0,pp=xobj[i].obj[j].polyData;k<xobj[i].obj[j].nPolygons;k++,pp++)
				if (pp->texture>m) m=pp->texture;
	nTextures=++m;
	texture=(struct TEXTUREBLOCK*)malloc(m*sizeof(struct TEXTUREBLOCK));
	if (texture==NULL) return FALSE;
	memset(texture,0,m*sizeof(struct TEXTUREBLOCK));
	for (i=0;i<m;i++) {
		texture[i].width=16; texture[i].height=16; // WHY ?????
		texture[i].corners[2]=1.0; // (1,0)
		texture[i].corners[4]=1.0; // (1,1)
		texture[i].corners[5]=1.0;
		texture[i].corners[7]=1.0; // (0,1)
		texture[i].texture=i&0x7FF;  // ANYWAY WE CAN'T FIND IT !
		texture[i].islane=i>>11;
	}

	return TRUE;
}

BOOL CT3EDDoc::LoadFRD(CArchive& ar)
{
	int i,j,k,l;
	struct TRKBLOCK *b;
	struct POLYGONBLOCK *p;
	struct XOBJDATA *x;
	struct OBJPOLYBLOCK *o;

	if (ar.Read(header,28)!=28) return FALSE; // header & numblocks
	if (ar.Read(&nBlocks,4)<4) return FALSE;
	nBlocks++;
	if ((nBlocks<1)||(nBlocks>500)) return FALSE; // 1st sanity check

	trk=(struct TRKBLOCK *)malloc(nBlocks*sizeof(struct TRKBLOCK));
	if (trk==NULL) return FALSE;
	memset(trk,0,nBlocks*sizeof(struct TRKBLOCK));
	poly=(struct POLYGONBLOCK *)malloc(nBlocks*sizeof(struct POLYGONBLOCK));
	if (poly==NULL) return FALSE;
	memset(poly,0,nBlocks*sizeof(struct POLYGONBLOCK));
	xobj=(struct XOBJBLOCK *)malloc((4*nBlocks+1)*sizeof(struct XOBJBLOCK));
	if (xobj==NULL) return FALSE;
	memset(xobj,0,(4*nBlocks+1)*sizeof(struct XOBJBLOCK));

	if (ar.Read(&l,4)<4) return FALSE; // choose between NFS3 & NFSHS
	if ((l<0)||(l>5000)) bHSMode=FALSE;
	else if (((l+7)/8)==nBlocks) bHSMode=TRUE;
	else return FALSE; // unknown file type

	if (bHSMode) return LoadHSFRD(ar,l);
    
	memcpy(trk,&l,4);
    if (ar.Read(((char *)trk)+4,80)!=80) return FALSE;
	// TRKBLOCKs
	for (i=0;i<nBlocks;i++) {
		b=&(trk[i]);
		// ptCentre, ptBounding, 6 nVertices == 84 bytes
		if (i!=0) { if (ar.Read(b,84)!=84) return FALSE; }
		if ((b->nVertices<0)/*||(b->nVertices>1000)*/) return FALSE;
		b->vert=(struct FLOATPT *)malloc(b->nVertices*sizeof(struct FLOATPT));
		if (b->vert==NULL) return FALSE;
		if ((long)ar.Read(b->vert,12*b->nVertices)!=12*b->nVertices) return FALSE;
		b->unknVertices=(long *)malloc(b->nVertices*sizeof(long));
		if (b->unknVertices==NULL) return FALSE;
		if ((long)ar.Read(b->unknVertices,4*b->nVertices)!=4*b->nVertices) return FALSE;
		if (ar.Read(b->nbdData,4*0x12C)!=4*0x12C) return FALSE;

		// nStartPos & various blk sizes == 32 bytes
		if (ar.Read(&(b->nStartPos),32)!=32) return FALSE;
		if (i>0) if (b->nStartPos!=trk[i-1].nStartPos+trk[i-1].nPositions) return FALSE;
		b->posData=(struct POSITIONDATA *)malloc(b->nPositions*sizeof(struct POSITIONDATA));
		if (b->posData==NULL) return FALSE;
		if ((long)ar.Read(b->posData,8*b->nPositions)!=8*b->nPositions) return FALSE;
		b->polyData=(struct POLYVROADDATA *)malloc(b->nPolygons*sizeof(struct POLYVROADDATA));
		if (b->polyData==NULL) return FALSE;
		memset(b->polyData,0,b->nPolygons*sizeof(struct POLYVROADDATA));
		for (j=0;j<b->nPolygons;j++)
			if (ar.Read(b->polyData+j,8)!=8) return FALSE;
		b->vroadData=(struct VROADDATA *)malloc(b->nVRoad*sizeof(struct VROADDATA));
		if (b->vroadData==NULL) return FALSE;
		if ((long)ar.Read(b->vroadData,12*b->nVRoad)!=12*b->nVRoad) return FALSE;
		if (b->nXobj>0) {
			b->xobj=(struct REFXOBJ *)malloc(b->nXobj*sizeof(struct REFXOBJ));
			if (b->xobj==NULL) return FALSE;
			if ((long)ar.Read(b->xobj,20*b->nXobj)!=20*b->nXobj) return FALSE;
		}
		if (b->nPolyobj>0) {
			char *buffer=(char *)malloc(b->nPolyobj*20);
			if ((long)ar.Read(buffer,20*b->nPolyobj)!=20*b->nPolyobj) return FALSE;
			free(buffer);
		}
		b->nPolyobj=0;
		if (b->nSoundsrc>0) {
			b->soundsrc=(struct SOUNDSRC *)malloc(b->nSoundsrc*sizeof(struct SOUNDSRC));
			if (b->soundsrc==NULL) return FALSE;
			if ((long)ar.Read(b->soundsrc,16*b->nSoundsrc)!=16*b->nSoundsrc) return FALSE;
		}
		if (b->nLightsrc>0) {
			b->lightsrc=(struct LIGHTSRC *)malloc(b->nLightsrc*sizeof(struct LIGHTSRC));
			if (b->lightsrc==NULL) return FALSE;
			if ((long)ar.Read(b->lightsrc,16*b->nLightsrc)!=16*b->nLightsrc) return FALSE;
		}
	}

	// POLYGONBLOCKs
	for (i=0;i<nBlocks;i++) {
		p=&(poly[i]);
		for (j=0;j<7;j++) {
			if (ar.Read(&(p->sz[j]),4)!=4) return FALSE;
			if (p->sz[j]!=0) {
				if (ar.Read(&(p->szdup[j]),4)!=4) return FALSE;
				if (p->szdup[j]!=p->sz[j]) return FALSE;
				p->poly[j]=(LPPOLYGONDATA)malloc(p->sz[j]*sizeof(struct POLYGONDATA));
				if (p->poly[j]==NULL) return FALSE;
				if ((long)ar.Read(p->poly[j],14*p->sz[j])!=14*p->sz[j]) return FALSE;
			}
		}
		if (p->sz[4]!=trk[i].nPolygons) return FALSE; // sanity check
		for (j=0;j<4;j++) {
			o=&(p->obj[j]);
			if (ar.Read(&(o->n1),4)!=4) return FALSE;
			if (o->n1>0) {
				if (ar.Read(&(o->n2),4)!=4) return FALSE;
				o->types=(long *)malloc(o->n2*sizeof(long));
				if (o->types==NULL) return FALSE;
				o->numpoly=(long *)malloc(o->n2*sizeof(long));
				if (o->numpoly==NULL) return FALSE;
				o->poly=(LPPOLYGONDATA *)malloc(o->n2*sizeof(LPPOLYGONDATA));
				if (o->poly==NULL) return FALSE;
				o->nobj=0; l=0;
/*				if (j==0) // sanity check with TRKBLOCK
					if (trk[i].nPolyobj!=o->n2) return FALSE; */
				for(k=0;k<o->n2;k++) {
					if (ar.Read(o->types+k,4)!=4) return FALSE;
/*					if (j==0) // sanity check with TRKBLOCK
						if (o->types[k]!=trk[i].polyobj[k]->type) return FALSE; */
					if (o->types[k]==1) {
						if (ar.Read(o->numpoly+o->nobj,4)!=4) return FALSE;
						o->poly[o->nobj]=(LPPOLYGONDATA)malloc(o->numpoly[o->nobj]*sizeof(struct POLYGONDATA));
						if (o->poly[o->nobj]==NULL) return FALSE;
						if ((long)ar.Read(o->poly[o->nobj],14*o->numpoly[o->nobj])!=14*o->numpoly[o->nobj]) return FALSE;
						l+=o->numpoly[o->nobj];
						o->nobj++;
					}
				}
				if (l!=o->n1) return FALSE; // n1 == total nb polygons
			}
		}
	}

	// XOBJBLOCKs
	for (i=0;i<=4*nBlocks;i++) {
		if (ar.Read(&(xobj[i].nobj),4)!=4) return FALSE;
		if (xobj[i].nobj>0) {
			xobj[i].obj=(struct XOBJDATA *)malloc(xobj[i].nobj*sizeof(struct XOBJDATA));
			if (xobj[i].obj==NULL) return FALSE;
			memset(xobj[i].obj,0,xobj[i].nobj*sizeof(struct XOBJDATA));
		}
		for (j=0;j<xobj[i].nobj;j++) {
			x=&(xobj[i].obj[j]);
			// 3 headers == 12 bytes 
			if (ar.Read(x,12)!=12) return FALSE;
			if (x->crosstype==4) { // basic objects
				if (ar.Read(&(x->ptRef),12)!=12) return FALSE;
				if (ar.Read(&(x->unknown2),4)!=4) return FALSE;
			}
			else if (x->crosstype==3) { // animated objects
				// unkn3, type3, objno, nAnimLength, unkn4 == 24 bytes
				if (ar.Read(x->unknown3,24)!=24) return FALSE;
				if (x->type3!=3) return FALSE;
				x->animData=(struct ANIMDATA *)malloc(20*x->nAnimLength);
				if (x->animData==NULL) return FALSE;
				if ((long)ar.Read(x->animData,20*x->nAnimLength)!=20*x->nAnimLength) return FALSE;
				// make a ref point from first anim position
				x->ptRef.x=(float)(x->animData->pt.x/65536.0);
				x->ptRef.z=(float)(x->animData->pt.z/65536.0);
				x->ptRef.y=(float)(x->animData->pt.y/65536.0);
			}
			else return FALSE; // unknown object type
			// common part : vertices & polygons
			if (ar.Read(&(x->nVertices),4)!=4) return FALSE;
			x->vert=(struct FLOATPT *)malloc(12*x->nVertices);
			if (x->vert==NULL) return FALSE;
			if ((long)ar.Read(x->vert,12*x->nVertices)!=12*x->nVertices) return FALSE;
			x->unknVertices=(long *)malloc(4*x->nVertices);
			if (x->unknVertices==NULL) return FALSE;
			if ((long)ar.Read(x->unknVertices,4*x->nVertices)!=4*x->nVertices) return FALSE;
			if (ar.Read(&(x->nPolygons),4)!=4) return FALSE;
			x->polyData=(struct POLYGONDATA *)malloc(x->nPolygons*14);
			if (x->polyData==NULL) return FALSE;
			if ((long)ar.Read(x->polyData,14*x->nPolygons)!=14*x->nPolygons) return FALSE;
		}
	}
// sanity check with TRKBLOCK fails for TR00/TR04 with animated objects
/*	for (i=0;i<nBlocks;i++)
		if ((xobj[4*i].nobj+xobj[4*i+1].nobj+xobj[4*i+2].nobj+
				xobj[4*i+3].nobj)!=trk[i].nXobj) return FALSE;  */

	// TEXTUREBLOCKs
	if (ar.Read(&nTextures,4)!=4) return FALSE;
	texture=(struct TEXTUREBLOCK *)malloc(nTextures*sizeof(struct TEXTUREBLOCK));
	for (i=0;i<nTextures;i++)
		if (ar.Read(&(texture[i]),47)!=47) return FALSE;

	if (ar.Read(&i,4)!=0) return FALSE; // we ought to be at EOF now
	return TRUE;
}

BOOL CT3EDDoc::LoadCOL(CFile& coll)
{
	struct COLSTRUCT3D *s;
	struct COLOBJECT *o;
	int i,delta,dummy;

	col.hs_extra=NULL;
	if (coll.Read(&col,16)!=16) return FALSE;
	if ((col.collID[0]!='C')||(col.collID[1]!='O')||
		(col.collID[2]!='L')||(col.collID[3]!='L')) return FALSE;
	if (col.version!=11) return FALSE;
	if ((col.nBlocks!=2)&&(col.nBlocks!=4)&&(col.nBlocks!=5)) return FALSE;
	if ((long)coll.Read(col.xbTable,4*col.nBlocks)!=4*col.nBlocks) return FALSE;

	// texture XB
	if (coll.Read(&col.textureHead,8)!=8) return FALSE;
	if (col.textureHead.xbid!=XBID_TEXTUREINFO) return FALSE;
	if (col.textureHead.size!=8+8*col.textureHead.nrec) return FALSE;
	col.texture=(struct COLTEXTUREINFO *)
			malloc(col.textureHead.nrec*sizeof(struct COLTEXTUREINFO));
	if (col.texture==NULL) return FALSE;
	if ((long)coll.Read(col.texture,8*col.textureHead.nrec)!=8*col.textureHead.nrec) return FALSE;

	// struct3D XB
	if (col.nBlocks>=4) {
		if (coll.Read(&col.struct3DHead,8)!=8) return FALSE;
		if (col.struct3DHead.xbid!=XBID_STRUCT3D) return FALSE;
		s=col.struct3D=(struct COLSTRUCT3D *)
				malloc(col.struct3DHead.nrec*sizeof(struct COLSTRUCT3D));
		if (s==NULL) return FALSE;
		memset(s,0,col.struct3DHead.nrec*sizeof(struct COLSTRUCT3D));
		for (i=0;i<col.struct3DHead.nrec;i++,s++) {
			if (coll.Read(s,8)!=8) return FALSE;
			delta=(8+16*s->nVert+6*s->nPoly)%4;
			delta=(4-delta)%4;
			if (s->size!=8+16*s->nVert+6*s->nPoly+delta) return FALSE;
			s->vertex=(struct COLVERTEX *)malloc(16*s->nVert);
			if (s->vertex==NULL) return FALSE;
			if ((long)coll.Read(s->vertex,16*s->nVert)!=16*s->nVert) return FALSE;
			s->polygon=(struct COLPOLYGON *)malloc(6*s->nPoly);
			if (s->polygon==NULL) return FALSE;
			if ((long)coll.Read(s->polygon,6*s->nPoly)!=6*s->nPoly) return FALSE;
			if (delta>0) if ((int)coll.Read(&dummy,delta)!=delta) return FALSE;
		}

	// object XB
		if (coll.Read(&col.objectHead,8)!=8) return FALSE;
		if ((col.objectHead.xbid!=XBID_OBJECT)&&(col.objectHead.xbid!=XBID_OBJECT2)) return FALSE;
		o=col.object=(struct COLOBJECT *)
				malloc(col.objectHead.nrec*sizeof(struct COLOBJECT));
		if (o==NULL) return FALSE;
		memset(o,0,col.objectHead.nrec*sizeof(struct COLOBJECT));
		for (i=0;i<col.objectHead.nrec;i++,o++) {
			if (coll.Read(o,4)!=4) return FALSE;
			if (o->type==1) {
				if (o->size!=16) return FALSE;
				if (coll.Read(&(o->ptRef),12)!=12) return FALSE;
			} else if (o->type==3) {
				if (coll.Read(&(o->animLength),4)!=4) return FALSE;
				if (o->size!=8+20*o->animLength) return FALSE;
				o->animData=(struct ANIMDATA *)malloc(20*o->animLength);
				if (o->animData==NULL) return FALSE;
				if ((long)coll.Read(o->animData,20*o->animLength)!=20*o->animLength) return FALSE;
				o->ptRef.x=o->animData->pt.x;
				o->ptRef.z=o->animData->pt.z;
				o->ptRef.y=o->animData->pt.y;
			} else return FALSE; // unknown object type
		}
	}

	// object2 XB
	if (col.nBlocks==5) {
		if (coll.Read(&col.object2Head,8)!=8) return FALSE;
		if ((col.object2Head.xbid!=XBID_OBJECT)&&(col.object2Head.xbid!=XBID_OBJECT2)) return FALSE;
		o=col.object2=(struct COLOBJECT *)
				malloc(col.object2Head.nrec*sizeof(struct COLOBJECT));
		if (o==NULL) return FALSE;
		memset(o,0,col.object2Head.nrec*sizeof(struct COLOBJECT));
		for (i=0;i<col.object2Head.nrec;i++,o++) {
			if (coll.Read(o,4)!=4) return FALSE;
			if (o->type==1) {
				if (o->size!=16) return FALSE;
				if (coll.Read(&(o->ptRef),12)!=12) return FALSE;
			} else if (o->type==3) {
				if (coll.Read(&(o->animLength),4)!=4) return FALSE;
				if (o->size!=8+20*o->animLength) return FALSE;
				o->animData=(struct ANIMDATA *)malloc(20*o->animLength);
				if (o->animData==NULL) return FALSE;
				if ((long)coll.Read(o->animData,20*o->animLength)!=20*o->animLength) return FALSE;
				o->ptRef.x=o->animData->pt.x;
				o->ptRef.z=o->animData->pt.z;
				o->ptRef.y=o->animData->pt.y;
			} else return FALSE; // unknown object type
		}
	}

	// vroad XB
	if (coll.Read(&col.vroadHead,8)!=8) return FALSE;
	if (col.vroadHead.xbid!=XBID_VROAD) return FALSE;
	if (col.vroadHead.size!=8+36*col.vroadHead.nrec) return FALSE;
	ASSERT(col.vroadHead.nrec==trk[nBlocks-1].nStartPos+trk[nBlocks-1].nPositions);
	col.vroad=(struct COLVROAD *)malloc(col.vroadHead.nrec*sizeof(struct COLVROAD));
	if (col.vroad==NULL) return FALSE;
	if ((long)coll.Read(col.vroad,36*col.vroadHead.nrec)!=36*col.vroadHead.nrec) return FALSE;

	if (coll.Read(&i,4)!=0) return FALSE; // we ought to be at EOF now
	return TRUE;
}

void CT3EDDoc::SaveHSFRD(CArchive& ar)
{
	int i,j,k,l,m;
	struct TRKBLOCK *b;
	struct POLYGONBLOCK *p;
	struct XOBJDATA *x;
	struct HS_VROADBLOCK vroadblk;
	char ptrspace[44];
	struct POLYGONDATA tmppoly;

	HS_RecalcMinMaxXY(); // recompute some POLYVROADDATA

	ar.Write(header,28);
	nBlocks--;
	ar.Write(&nBlocks,4);
	nBlocks++;
	l=col.vroadHead.nrec;
	ar.Write(&l,4);

	for (i=0;i<l;i++) { // COL VROAD
		vroadblk.refPt.x=(float)(col.vroad[i].refPt.x/65536.0);
		vroadblk.refPt.z=(float)(col.vroad[i].refPt.z/65536.0);
		vroadblk.refPt.y=(float)(col.vroad[i].refPt.y/65536.0);
		vroadblk.normal.x=(float)(col.vroad[i].normal.x/128.0);
		vroadblk.normal.z=(float)(col.vroad[i].normal.z/128.0);
		vroadblk.normal.y=(float)(col.vroad[i].normal.y/128.0);
		vroadblk.forward.x=(float)(col.vroad[i].forward.x/128.0);
		vroadblk.forward.z=(float)(col.vroad[i].forward.z/128.0);
		vroadblk.forward.y=(float)(col.vroad[i].forward.y/128.0);
		vroadblk.right.x=(float)(col.vroad[i].right.x/128.0);
		vroadblk.right.z=(float)(col.vroad[i].right.z/128.0);
		vroadblk.right.y=(float)(col.vroad[i].right.y/128.0);
		vroadblk.leftWall=(float)(col.vroad[i].leftWall/65536.0);
		vroadblk.rightWall=(float)(col.vroad[i].rightWall/65536.0);
		memcpy(vroadblk.unknown1,col.hs_extra+7*i,28);
		ar.Write(&vroadblk,84);
	}

	memset(ptrspace,0,44);
	for (i=0;i<nBlocks;i++) { // TRKBLOCK heads
		b=&(trk[i]);
		p=&(poly[i]);
		ar.Write(p->sz,28); // track polygon numbers
		for (j=0;j<4;j++) ar.Write(&(p->obj[j].n1),4); // polyobjs
		ar.Write(ptrspace,44);
		ar.Write(&(b->nVertices),24); // vertices
		ar.Write(ptrspace,8);
		ar.Write(b,60); // ptCentre, ptBounding
		ar.Write(b->nbdData,4*0x12C);
		for (j=4*i;j<4*i+4;j++) {
			ar.Write(&(xobj[j].nobj),4);
			ar.Write(ptrspace,4);
		}
		// nVRoad has to be re-computed... (flags!=14)
		ASSERT(b->nPolygons==p->sz[4]);
		l=0;
		for (j=0;j<b->nPolygons;j++)
			if ((b->polyData[j].flags&15)!=14) l++;
		ar.Write(&l,4);
		ar.Write(&(b->hs_ptMin),24);
		ar.Write(ptrspace,4);
		ar.Write(&(b->nPositions),4);
		ar.Write(&(b->nXobj),4);
		ar.Write(ptrspace,12); // erases nPolyobj
		ar.Write(&(b->nSoundsrc),4);
		ar.Write(ptrspace,4);
		ar.Write(&(b->nLightsrc),4);
		ar.Write(ptrspace,4);
		ar.Write(b->hs_neighbors,32);
	}

	for (i=0;i<nBlocks;i++) { // TRKBLOCK data
		b=&(trk[i]);
		p=&(poly[i]);
		ar.Write(b->vert,12*b->nVertices);
		ar.Write(b->unknVertices,4*b->nVertices);
		for (j=0;j<b->nPolygons;j++)
			if ((b->polyData[j].flags&15)!=14) {
				ar.Write(b->polyData[j].hs_minmax,8);
				ar.Write(&(b->polyData[j].flags),1);
				ar.Write(&(b->polyData[j].hs_unknown),1);
				ar.Write(&j,2);
				ar.Write(b->vroadData+b->polyData[j].vroadEntry,12);
			}
		if (b->nXobj>0) ar.Write(b->xobj,20*b->nXobj);
		if (b->nSoundsrc) ar.Write(b->soundsrc,16*b->nSoundsrc);
		if (b->nLightsrc) ar.Write(b->lightsrc,16*b->nLightsrc);

		// polygons
		for (j=0;j<7;j++) for (k=0;k<p->sz[j];k++) {
			for (m=0;m<4;m++) tmppoly.vertex[m^1]=p->poly[j][k].vertex[m];
			memcpy(&(tmppoly.texture),&(p->poly[j][k].texture),5);
			ar.Write(&tmppoly,13);
		}
		for (j=0;j<4;j++) for (k=0;k<p->obj[j].nobj;k++)
			for (l=0;l<p->obj[j].numpoly[k];l++) {
				for (m=0;m<4;m++) tmppoly.vertex[m^1]=p->obj[j].poly[k][l].vertex[m];
				memcpy(&(tmppoly.texture),&(p->obj[j].poly[k][l].texture),5);
				ar.Write(&tmppoly,13);
			}

		// xobj
		for (j=4*i;j<4*i+4;j++) {
			for (k=0;k<xobj[j].nobj;k++) {
				x=&(xobj[j].obj[k]);
				ar.Write(x,12); // 3 headers
				if ((x->crosstype==4)||(x->crosstype==2))
					ar.Write(&(x->ptRef),12);
				else if (x->crosstype==3)
					ar.Write(x->unknown3,12);
				ar.Write(&(x->unknown2),4);
				ar.Write(ptrspace,4);
				ar.Write(&(x->nVertices),4);
				ar.Write(ptrspace,8);
				ar.Write(&(x->nPolygons),4);
				ar.Write(ptrspace,4);
			}
			for (k=0;k<xobj[j].nobj;k++) {
				x=&(xobj[j].obj[k]);
				if (x->crosstype==3) { // animated-specific
					ar.Write(x->unknown3+6,2);
					ar.Write(&(x->type3),6);
					ar.Write(x->animData,20*x->nAnimLength);
				}
				ar.Write(x->vert,12*x->nVertices);
				ar.Write(x->unknVertices,4*x->nVertices);
				for (l=0;l<x->nPolygons;l++) {
					for (m=0;m<4;m++) tmppoly.vertex[m^1]=x->polyData[l].vertex[m];
					memcpy(&(tmppoly.texture),&(x->polyData[l].texture),5);
					ar.Write(&tmppoly,13);
				}
			}
		}
	}

	if (hs_morexobjlen>0) ar.Write(hs_morexobj,hs_morexobjlen);
}

void CT3EDDoc::SaveFRD(CArchive& ar)
{
	int i,j,k,l;
	struct TRKBLOCK *b;
	struct POLYGONBLOCK *p;
	struct XOBJDATA *x;
	struct OBJPOLYBLOCK *o;

	ar.Write(header,28); // header & numblocks
	nBlocks--;
	ar.Write(&nBlocks,4);
	nBlocks++;

	// TRKBLOCKs
	for (i=0;i<nBlocks;i++) {
		b=&(trk[i]);
		// ptCentre, ptBounding, nVertices and 5 nUnknowns == 84 bytes
		ar.Write(b,84);
		ar.Write(b->vert,12*b->nVertices);
		ar.Write(b->unknVertices,4*b->nVertices);
		ar.Write(b->nbdData,4*0x12C);
		// nStartPos & various blk sizes == 32 bytes
		ar.Write(&(b->nStartPos),32);
		ar.Write(b->posData,8*b->nPositions);
		for (j=0;j<b->nPolygons;j++)
			ar.Write(b->polyData+j,8);
		ar.Write(b->vroadData,12*b->nVRoad);
		if (b->nXobj>0) ar.Write(b->xobj,20*b->nXobj);
//		if (b->nPolyobj>0) ar.Write(b->polyobj[0],20*b->nPolyobj);
		if (b->nSoundsrc>0) ar.Write(b->soundsrc,16*b->nSoundsrc);
		if (b->nLightsrc>0) ar.Write(b->lightsrc,16*b->nLightsrc);
	}

	// POLYGONBLOCKs
	for (i=0;i<nBlocks;i++) {
		p=&(poly[i]);
		for (j=0;j<7;j++) {
			ar.Write(&(p->sz[j]),4);
			if (p->sz[j]!=0) {
				ar.Write(&(p->szdup[j]),4);
				ar.Write(p->poly[j],14*p->sz[j]);
			}
		}
		for (j=0;j<4;j++) {
			o=&(p->obj[j]);
			ar.Write(&(o->n1),4);
			if (o->n1>0) {
				ar.Write(&(o->n2),4);
				l=0;
				for(k=0;k<o->n2;k++) {
					ar.Write(o->types+k,4);
					if (o->types[k]==1) {
						ar.Write(o->numpoly+l,4);
						ar.Write(o->poly[l],14*o->numpoly[l]);
						l++;
					}
				}
			}
		}
	}

	// XOBJBLOCKs
	for (i=0;i<=4*nBlocks;i++) {
		ar.Write(&(xobj[i].nobj),4);
		for (j=0;j<xobj[i].nobj;j++) {
			x=&(xobj[i].obj[j]);
			// 3 headers == 12 bytes 
			ar.Write(x,12);
			if (x->crosstype==4) { // basic objects
				ar.Write(&(x->ptRef),12);
				ar.Write(&(x->unknown2),4);
			} else if (x->crosstype==3) { // animated objects
				// unkn3, type3, objno, nAnimLength, unkn4 == 24 bytes
				ar.Write(x->unknown3,24);
				ar.Write(x->animData,20*x->nAnimLength);
			}
			ar.Write(&(x->nVertices),4);
			ar.Write(x->vert,12*x->nVertices);
			ar.Write(x->unknVertices,4*x->nVertices);
			ar.Write(&(x->nPolygons),4);
			ar.Write(x->polyData,14*x->nPolygons);
		}
	}

	// TEXTUREBLOCKs
	ar.Write(&nTextures,4);
	for (i=0;i<nTextures;i++)
		ar.Write(&(texture[i]),47);
}

void CT3EDDoc::SaveCOL(CFile& coll)
{
	struct COLSTRUCT3D *s;
	struct COLOBJECT *o;
	int i,delta,dummy;

	coll.Write(&col,16);
	coll.Write(col.xbTable,4*col.nBlocks);

	// texture XB
	coll.Write(&col.textureHead,8);
	coll.Write(col.texture,8*col.textureHead.nrec);

	// struct3D XB
	if (col.nBlocks>=4) {
		coll.Write(&col.struct3DHead,8);
		s=col.struct3D;
		for (i=0;i<col.struct3DHead.nrec;i++,s++) {
			coll.Write(s,8);
			coll.Write(s->vertex,16*s->nVert);
			coll.Write(s->polygon,6*s->nPoly);
			delta=(8+16*s->nVert+6*s->nPoly)%4;
			delta=(4-delta)%4; dummy=0; // padding
			if (delta>0) coll.Write(&dummy,delta);
		}

	// object XB
		coll.Write(&col.objectHead,8);
		o=col.object;
		for (i=0;i<col.objectHead.nrec;i++,o++) {
			coll.Write(o,4);
			if (o->type==1) coll.Write(&(o->ptRef),12);
			else if (o->type==3) {
				coll.Write(&(o->animLength),4);
				coll.Write(o->animData,20*o->animLength);
			}
		}
	}

	// object2 XB
	if (col.nBlocks==5) {
		coll.Write(&col.object2Head,8);
		o=col.object2;
		for (i=0;i<col.object2Head.nrec;i++,o++) {
			coll.Write(o,4);
			if (o->type==1) coll.Write(&(o->ptRef),12);
			else if (o->type==3) {
				coll.Write(&(o->animLength),4);
				coll.Write(o->animData,20*o->animLength);
			}
		}
	}

	// vroad XB
	coll.Write(&col.vroadHead,8);
	coll.Write(col.vroad,36*col.vroadHead.nrec);
	coll.Close();
}

void CT3EDDoc::Serialize(CArchive& ar)
{
	CFile coll;
	CString fileName;
	int i;
	
	fileName=ar.GetFile()->GetFilePath();
	if (!fileName.Right(4).CompareNoCase(".FRD"))
		fileName=fileName.Left(fileName.GetLength()-4);
	fileName+=".COL";
	
	if (ar.IsStoring())
	{
		ASSERT(!bEmpty);
		if (bHSMode) SaveHSFRD(ar);
		else {
			SaveFRD(ar);
			if (!coll.Open(fileName,CFile::modeCreate|CFile::modeWrite|CFile::shareDenyWrite))
				AfxThrowFileException(CFileException::accessDenied,-1,fileName);
			SaveCOL(coll);
		}
		for (i=0;i<undoLevel;i++) DeleteUndo(i);
		undoLevel=0;
	}
	else
	{
		if (!bEmpty) DeleteContents();
		bEmpty=FALSE;
		trk=NULL; poly=NULL; xobj=NULL; hs_morexobj=NULL;
		memset(&col,0,sizeof(struct COLFILE));
		texture=NULL;
		if (LoadFRD(ar)==FALSE) // failed loading FRD file
			AfxThrowArchiveException(CArchiveException::badIndex,NULL);
		if (!bHSMode) { // original NFS3 mode
			if (!coll.Open(fileName,CFile::modeRead|CFile::shareDenyWrite))
				AfxThrowFileException(CFileException::fileNotFound,-1,
					CString("The auxiliary file ")+fileName);
			if (LoadCOL(coll)==FALSE) // failed loading COL file
				AfxThrowArchiveException(CArchiveException::badIndex,NULL);
		}
		// prepare basic info for QFS viewer
		ASSERT(qfsView.pBitmaps==NULL);
		qfsView.promptLoad=TRUE;
		fileName=ar.GetFile()->GetFilePath();
		i=fileName.ReverseFind('\\');
		if (i<0) i=0;
		qfsView.defPath=fileName.Left(i);
		fileName=ar.GetFile()->GetFileName();
		if (!fileName.Right(4).CompareNoCase(".FRD"))
			 qfsView.defName=fileName.Left(fileName.GetLength()-4)+"0.QFS";
		else qfsView.defName.Empty();
		qfsView.nColEntries=nTextures;
		qfsView.col=texture;
		qfsView.bHSMode=bHSMode;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CT3EDDoc diagnostics

#ifdef _DEBUG
void CT3EDDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CT3EDDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CT3EDDoc commands

void CT3EDDoc::FreeTrkContents(struct TRKBLOCK *trk)
{
	if (trk==NULL) return;
	dofree(trk->vert);
	dofree(trk->unknVertices);
	dofree(trk->posData);
	dofree(trk->polyData);
	dofree(trk->vroadData);
	dofree(trk->xobj);
//	if (trk->polyobj!=NULL) dofree(trk->polyobj[0]); // because malloc is linear 20*nCross2
//	dofree(trk->polyobj);
	dofree(trk->soundsrc);
	dofree(trk->lightsrc);
}

void CT3EDDoc::FreePolyContents(struct POLYGONBLOCK *poly)
{
	int j,k;

	if (poly==NULL) return;
	for (j=0;j<7;j++) dofree(poly->poly[j]);
	for (j=0;j<4;j++) {
		dofree(poly->obj[j].types);
		dofree(poly->obj[j].numpoly);
		if (poly->obj[j].poly!=NULL)
			for (k=0;k<poly->obj[j].nobj;k++) 
				dofree(poly->obj[j].poly[k]);
		dofree(poly->obj[j].poly);
	}
}

void CT3EDDoc::FreeXobjContents(struct XOBJBLOCK *xobj)
{
	int j;

	if (xobj==NULL) return;
	if (xobj->obj!=NULL) for (j=0;j<xobj->nobj;j++) {
		dofree(xobj->obj[j].vert);
		dofree(xobj->obj[j].unknVertices);
		dofree(xobj->obj[j].polyData);
		if (xobj->obj[j].crosstype==3)
			dofree(xobj->obj[j].animData);
	}
	dofree(xobj->obj);
}

void CT3EDDoc::DeleteUndo(int i)
{
	int j,k;

	for (j=0;j<MAX_BLOCKS;j++) {
		FreeTrkContents(undo[i][j].trk);
		dofree(undo[i][j].trk);
		FreePolyContents(undo[i][j].poly);
		dofree(undo[i][j].poly);
		for (k=0;k<4;k++) {
			FreeXobjContents(undo[i][j].xobj[k]);
			dofree(undo[i][j].xobj[k]);
		}
	}
	dofree(undoCol[i]);
}

void CT3EDDoc::DeleteContents() 
{
	int i;

	if (bEmpty) return;
	bEmpty=TRUE;			// free all allocated memory
	if (trk!=NULL) for (i=0;i<nBlocks;i++) 
		FreeTrkContents(trk+i);
	dofree(trk);
	if (poly!=NULL) for (i=0;i<nBlocks;i++) 
		FreePolyContents(poly+i);
	dofree(poly);
	if (xobj!=NULL) for (i=0;i<=4*nBlocks;i++)
		FreeXobjContents(xobj+i);
	dofree(xobj);
	dofree(texture);
	dofree(hs_morexobj);
	dofree(col.hs_extra);
	dofree(col.texture);
	if (col.struct3D!=NULL) 
		for (i=0;i<col.struct3DHead.nrec;i++) {
			dofree(col.struct3D[i].vertex);
			dofree(col.struct3D[i].polygon);
		}
	dofree(col.struct3D);
	if (col.object!=NULL)
		for (i=0;i<col.objectHead.nrec;i++)
			dofree(col.object[i].animData);
	dofree(col.object);
	if (col.object2!=NULL)
		for (i=0;i<col.object2Head.nrec;i++)
			dofree(col.object2[i].animData);
	dofree(col.object2);
	dofree(col.vroad);
	for (i=0;i<undoLevel;i++) DeleteUndo(i);
	undoLevel=0;
	qfsView.Reset();
}

void CT3EDDoc::PrepareNewUndo(struct FLOATPT *refpt,int block,int ofsx,int ofsy)
{
	int i;

	if (undoLevel==0) wasInitiallyModified=IsModified();
	if (undoLevel==UNDO_LEVELS) {
		DeleteUndo(0);
		wasInitiallyModified=TRUE;
		for (i=0;i<UNDO_LEVELS-1;i++) {
			memcpy(undo[i],undo[i+1],MAX_BLOCKS*sizeof(struct UNDOINFO));
			memcpy(undoRefpt+i,undoRefpt+i+1,12);
			undoRefblk[i]=undoRefblk[i+1];
			undoOfsx[i]=undoOfsx[i+1];
			undoOfsy[i]=undoOfsy[i+1];
			undoCol[i]=undoCol[i+1];
		}
	} else undoLevel++;
	memset(undo[undoLevel-1],0,MAX_BLOCKS*sizeof(struct UNDOINFO));
	memcpy(&(undoRefpt[undoLevel-1]),refpt,12);
	undoRefblk[undoLevel-1]=block;
	undoOfsx[undoLevel-1]=ofsx;
	undoOfsy[undoLevel-1]=ofsy;
	undoCol[undoLevel-1]=NULL;
	SetModifiedFlag(TRUE);
}

void CT3EDDoc::PrepareModifyTrk(int blk)
{
	struct UNDOINFO *u;
	struct TRKBLOCK *t;

	if (undoLevel==0) return;
	u=&(undo[undoLevel-1][blk]);
	if (u->trk!=NULL) return;
	u->trk=(struct TRKBLOCK *)malloc(sizeof(struct TRKBLOCK));
	t=&(trk[blk]);
	memcpy(u->trk,t,sizeof(struct TRKBLOCK));
	u->trk->vert=NULL;
	u->trk->unknVertices=NULL;
	if (t->nVertices!=0) {
		u->trk->vert=(struct FLOATPT *)malloc(12*t->nVertices);
		memcpy(u->trk->vert,t->vert,12*t->nVertices);
		u->trk->unknVertices=(long *)malloc(4*t->nVertices);
		memcpy(u->trk->unknVertices,t->unknVertices,4*t->nVertices);
	}
	u->trk->posData=NULL;
	if (t->nPositions!=0) {
		u->trk->posData=(struct POSITIONDATA *)malloc(8*t->nPositions);
		memcpy(u->trk->posData,t->posData,8*t->nPositions);
	}
	u->trk->polyData=NULL;
	if (t->nPolygons!=0) {
		u->trk->polyData=(struct POLYVROADDATA *)malloc(sizeof(struct POLYVROADDATA)*t->nPolygons);
		memcpy(u->trk->polyData,t->polyData,sizeof(struct POLYVROADDATA)*t->nPolygons);
	}
	u->trk->vroadData=NULL;
	if (t->nVRoad!=0) {
		u->trk->vroadData=(struct VROADDATA *)malloc(12*t->nVRoad);
		memcpy(u->trk->vroadData,t->vroadData,12*t->nVRoad);
	}
	u->trk->xobj=NULL;
	if (t->nXobj!=0) {
		u->trk->xobj=(struct REFXOBJ *)malloc(20*t->nXobj);
		memcpy(u->trk->xobj,t->xobj,20*t->nXobj);
	}
	u->trk->soundsrc=NULL;
	if (t->nSoundsrc!=0) {
		u->trk->soundsrc=(struct SOUNDSRC *)malloc(16*t->nSoundsrc);
		memcpy(u->trk->soundsrc,t->soundsrc,16*t->nSoundsrc);
	}
	u->trk->lightsrc=NULL;
	if (t->nLightsrc!=0) {
		u->trk->lightsrc=(struct LIGHTSRC *)malloc(16*t->nLightsrc);
		memcpy(u->trk->lightsrc,t->lightsrc,16*t->nLightsrc);
	}
}

void CT3EDDoc::PrepareModifyPoly(int blk)
{
	struct UNDOINFO *u;
	struct POLYGONBLOCK *p;
	struct OBJPOLYBLOCK *o1,*o2;
	int j,k;

	if (undoLevel==0) return;
	u=&(undo[undoLevel-1][blk]);
	if (u->poly!=NULL) return;
	u->poly=(struct POLYGONBLOCK *)malloc(sizeof(struct POLYGONBLOCK));
	p=&(poly[blk]);
	memcpy(u->poly,p,sizeof(struct POLYGONBLOCK));
	for (j=0;j<7;j++) {
		u->poly->poly[j]=NULL;
		if (p->sz[j]!=0) {
			u->poly->poly[j]=(LPPOLYGONDATA)malloc(14*p->sz[j]);
			memcpy(u->poly->poly[j],p->poly[j],14*p->sz[j]);
		}
	}
	for (j=0;j<4;j++) {
		o1=&(p->obj[j]); 
		o2=&(u->poly->obj[j]);
		o2->types=NULL;
		if (o1->n2!=0) {
			o2->types=(long *)malloc(4*o1->n2);
			memcpy(o2->types,o1->types,4*o1->n2);
		}
		o2->numpoly=NULL;
		o2->poly=NULL;
		if (o1->nobj!=0) {
			o2->numpoly=(long *)malloc(4*o1->nobj);
			memcpy(o2->numpoly,o1->numpoly,4*o1->nobj);
			o2->poly=(LPPOLYGONDATA *)malloc(4*o1->nobj);
			for (k=0;k<o1->nobj;k++) {
				o2->poly[k]=(LPPOLYGONDATA)malloc(14*o1->numpoly[k]);
				memcpy(o2->poly[k],o1->poly[k],14*o1->numpoly[k]);
			}
		}
	}
}

void CT3EDDoc::PrepareModifyXobj(int blk)
{
	struct UNDOINFO *u;
	int j;
	struct XOBJDATA *x1,*x2;

	if (undoLevel==0) return;
	u=&(undo[undoLevel-1][blk/4]);
	if (u->xobj[blk%4]!=NULL) return;
	u->xobj[blk%4]=(struct XOBJBLOCK *)malloc(sizeof(struct XOBJBLOCK));
	u->xobj[blk%4]->nobj=xobj[blk].nobj;
	u->xobj[blk%4]->obj=NULL;
	if (xobj[blk].nobj==0) return;
	x1=xobj[blk].obj;
	x2=u->xobj[blk%4]->obj=(struct XOBJDATA *)
			malloc(xobj[blk].nobj*sizeof(struct XOBJDATA));
	memcpy(x2,x1,xobj[blk].nobj*sizeof(struct XOBJDATA));
	for (j=0;j<xobj[blk].nobj;j++,x1++,x2++) {
		if ((x1->crosstype==3)&&(x1->animData!=NULL)) {
			x2->animData=(struct ANIMDATA *)malloc(20*x1->nAnimLength);
			memcpy(x2->animData,x1->animData,20*x1->nAnimLength);
		}
		x2->vert=(struct FLOATPT *)malloc(12*x1->nVertices);
		memcpy(x2->vert,x1->vert,12*x1->nVertices);
		x2->unknVertices=(long *)malloc(4*x1->nVertices);
		memcpy(x2->unknVertices,x1->unknVertices,4*x1->nVertices);
		x2->polyData=(LPPOLYGONDATA)malloc(14*x1->nPolygons);
		memcpy(x2->polyData,x1->polyData,14*x1->nPolygons);
	}
}

void CT3EDDoc::PerformUndo()
{
	int i,j,n;
	BOOL recalcXobj=FALSE;

	undoLevel--;
	for (i=0;i<nBlocks;i++) {
		if (undo[undoLevel][i].trk!=NULL) {
			FreeTrkContents(&(trk[i]));
			memcpy(&(trk[i]),undo[undoLevel][i].trk,sizeof(struct TRKBLOCK));
			dofree(undo[undoLevel][i].trk);
		}
		if (undo[undoLevel][i].poly!=NULL) {
			FreePolyContents(&(poly[i]));
			memcpy(&(poly[i]),undo[undoLevel][i].poly,sizeof(struct POLYGONBLOCK));
			dofree(undo[undoLevel][i].poly);
		}
		for (j=0;j<4;j++) if (undo[undoLevel][i].xobj[j]!=NULL) {
			recalcXobj=TRUE;
			FreeXobjContents(&(xobj[4*i+j]));
			memcpy(&(xobj[4*i+j]),undo[undoLevel][i].xobj[j],sizeof(struct XOBJBLOCK));
			dofree(undo[undoLevel][i].xobj[j]);
		}
	}
	if (recalcXobj) {
		n=0;
		for (i=0;i<nBlocks;i++)
			for (j=0;j<trk[i].nXobj;j++)
				trk[i].xobj[j].globalno=n++;
	}
	if (undoCol[undoLevel]!=NULL) {
		dofree(col.vroad);
		col.vroad=undoCol[undoLevel];
	}
	if (undoLevel==0) SetModifiedFlag(wasInitiallyModified);
}

//////////////////////////////////////////////////////////////////////
// Editing functions

BOOL CT3EDDoc::CanContainPoint(struct TRKBLOCK *t,struct FLOATPT *pt,float margin)
{
	if ((t->ptBounding[0].x<pt->x-margin)&&(t->ptBounding[1].x<pt->x-margin)&&
		(t->ptBounding[2].x<pt->x-margin)&&(t->ptBounding[3].x<pt->x-margin))
			return FALSE;
	if ((t->ptBounding[0].x>pt->x+margin)&&(t->ptBounding[1].x>pt->x+margin)&&
		(t->ptBounding[2].x>pt->x+margin)&&(t->ptBounding[3].x>pt->x+margin))
			return FALSE;
	if ((t->ptBounding[0].y<pt->y-margin)&&(t->ptBounding[1].y<pt->y-margin)&&
		(t->ptBounding[2].y<pt->y-margin)&&(t->ptBounding[3].y<pt->y-margin))
			return FALSE;
	if ((t->ptBounding[0].y>pt->y+margin)&&(t->ptBounding[1].y>pt->y+margin)&&
		(t->ptBounding[2].y>pt->y+margin)&&(t->ptBounding[3].y>pt->y+margin))
			return FALSE;
	return TRUE;
}

void CT3EDDoc::RecalcBoundingBox(int i)
{
	float xmin,xmax,ymin,ymax;
	int j,k,l,n;
	struct FLOATPT *v,w;
	struct XOBJDATA *x;

	PrepareModifyTrk(i);
	xmin=xmax=trk[i].ptCentre.x;
	ymin=ymax=trk[i].ptCentre.y;
	n=trk[i].nHiResVert;
	v=trk[i].vert;
	for (j=0;j<n;j++,v++) {
		if (v->x<xmin) xmin=v->x;
		if (v->x>xmax) xmax=v->x;
		if (v->y<ymin) ymin=v->y;
		if (v->y>ymax) ymax=v->y;
	}
	for (j=0;j<trk[i].nLightsrc;j++) {
		w.x=((float)trk[i].lightsrc[j].refpoint.x)/65536;
		w.y=((float)trk[i].lightsrc[j].refpoint.y)/65536;
		if (w.x<xmin) xmin=w.x;
		if (w.x>xmax) xmax=w.x;
		if (w.y<ymin) ymin=w.y;
		if (w.y>ymax) ymax=w.y;
	}
	for (l=4*i;l<4*i+4;l++)
		for (k=0;k<xobj[l].nobj;k++) {
			x=&(xobj[l].obj[k]);
			n=x->nVertices;
			v=x->vert;
			for (j=0;j<n;j++,v++) {
				if (v->x+x->ptRef.x<xmin) xmin=v->x+x->ptRef.x;
				if (v->x+x->ptRef.x>xmax) xmax=v->x+x->ptRef.x;
				if (v->y+x->ptRef.y<ymin) ymin=v->y+x->ptRef.y;
				if (v->y+x->ptRef.y>ymax) ymax=v->y+x->ptRef.y;
			}
		}
	trk[i].ptBounding[0].x=xmin-1; trk[i].ptBounding[0].y=ymin-1;
	trk[i].ptBounding[1].x=xmax+1; trk[i].ptBounding[1].y=ymin-1;
	trk[i].ptBounding[2].x=xmax+1; trk[i].ptBounding[2].y=ymax+1;
	trk[i].ptBounding[3].x=xmin-1; trk[i].ptBounding[3].y=ymax+1;
	for (j=0;j<4;j++) trk[i].ptBounding[j].z=trk[i].ptCentre.z;
}

void CT3EDDoc::RecalcPolyVroad(int blk,int no,struct FLOATPT *optdir)
{
	BOOL isUnique=TRUE;
	int i;
	struct TRKBLOCK *t=&(trk[blk]);
	struct POLYVROADDATA *p=&(t->polyData[no]);
	struct VROADDATA *v;
	struct FLOATPT v1,v2,norm;
	float len,prod;
	short *vno;
	
	PrepareModifyTrk(blk);
	for (i=0;i<t->nPolygons;i++)
		if ((i!=no)&&(t->polyData[i].vroadEntry==p->vroadEntry)) 
			isUnique=FALSE;
	if (!isUnique) {
		t->vroadData=(struct VROADDATA *)
			realloc(t->vroadData,(t->nVRoad+1)*sizeof(struct VROADDATA));
		memcpy(t->vroadData+t->nVRoad,t->vroadData+p->vroadEntry,
			sizeof(struct VROADDATA));
		p->vroadEntry=(unsigned char)t->nVRoad++;
	}
	v=t->vroadData+p->vroadEntry;
	vno=poly[blk].poly[4][no].vertex;
	v1.x=t->vert[vno[1]].x-t->vert[vno[3]].x;
	v1.z=t->vert[vno[1]].z-t->vert[vno[3]].z;
	v1.y=t->vert[vno[1]].y-t->vert[vno[3]].y;
	v2.x=t->vert[vno[2]].x-t->vert[vno[0]].x;
	v2.z=t->vert[vno[2]].z-t->vert[vno[0]].z;
	v2.y=t->vert[vno[2]].y-t->vert[vno[0]].y;
	norm.x=-v1.y*v2.z+v1.z*v2.y;
	norm.y=-v1.z*v2.x+v1.x*v2.z;
	norm.z=-v1.x*v2.y+v1.y*v2.x;
	len=(float)sqrt(norm.x*norm.x+norm.y*norm.y+norm.z*norm.z);
	v->xNorm=(short)(norm.x*32767/len);
	v->zNorm=(short)(norm.z*32767/len);
	v->yNorm=(short)(norm.y*32767/len);
	if (optdir!=NULL) {
		v1.x=optdir->x; v1.z=optdir->z; v1.y=optdir->y;
	} else {
		prod=v->xForw*norm.x+v->yForw*norm.y+v->zForw*norm.z;
		v1.x=v->xForw-prod*norm.x/(len*len);
		v1.z=v->zForw-prod*norm.z/(len*len);
		v1.y=v->yForw-prod*norm.y/(len*len);
	}
	len=(float)sqrt(v1.x*v1.x+v1.y*v1.y+v1.z*v1.z);
	v->xForw=(short)(v1.x*32767/len);
	v->zForw=(short)(v1.z*32767/len);
	v->yForw=(short)(v1.y*32767/len);
}

void CT3EDDoc::MovePointBy(struct FLOATPT *refpt,float dx,float dy,float dz)
{
	int i,j,k,l,n;
	struct FLOATPT *v;
	BOOL isModified;
	LPPOLYGONDATA p;
	struct XOBJDATA *x;
	struct FLOATPT pt;

	pt.x=refpt->x; pt.y=refpt->y; pt.z=refpt->z;
	for (i=0;i<nBlocks;i++) {
		if (!CanContainPoint(trk+i,&pt,0.0)) continue;
		isModified=FALSE;
		v=trk[i].vert;
		n=trk[i].nVertices;
		for (j=0;j<n;j++,v++)
/*			if ((v->x==pt.x)&&(v->z==pt.z)&&(v->y==pt.y)) { */
			if ((fabs(v->x-pt.x)<1E-3)&&(fabs(v->z-pt.z)<1E-3)&&(fabs(v->y-pt.y)<1E-3))
			{
				PrepareModifyTrk(i);
				isModified=TRUE;
				v->x+=dx; v->z+=dz; v->y+=dy;
				p=poly[i].poly[4];
				for (k=0;k<trk[i].nPolygons;k++,p++)
					if ((j==p->vertex[0])||(j==p->vertex[1])||
						(j==p->vertex[2])||(j==p->vertex[3]))
					RecalcPolyVroad(i,k);
			}
		for (j=4*i;j<4*i+4;j++) {
			x=xobj[j].obj;
			for (k=0;k<xobj[j].nobj;k++,x++) {
				v=x->vert;
				for (l=0;l<x->nVertices;l++,v++)
/*					if ((v->x+x->ptRef.x==pt.x)&&
						(v->z+x->ptRef.z==pt.z)&&
						(v->y+x->ptRef.y==pt.y)) */
					if ((fabs(v->x+x->ptRef.x-pt.x)<1E-3)&&(fabs(v->z+x->ptRef.z-pt.z)<1E-3)&&(fabs(v->y+x->ptRef.y-pt.y)<1E-3))
					{
						PrepareModifyXobj(j);
						isModified=TRUE;
						v->x+=dx; v->z+=dz; v->y+=dy;
					}
			}
		}
		if (isModified) {
			if ((dx!=0)||(dy!=0)) RecalcBoundingBox(i);
		}
	}
}

void CT3EDDoc::ExtMovePointBy(struct FLOATPT *refpt,float dx,float dy,float dz,float sDist,float sWidth)
{
	int i,j,k,l,n;
	struct FLOATPT *v;
	BOOL isModified;
	float dist;
	struct XOBJDATA *x;
	struct FLOATPT pt;
	struct LIGHTSRC *light;
	struct SOUNDSRC *sound;

	pt.x=refpt->x; pt.y=refpt->y; pt.z=refpt->z;
	for (i=0;i<nBlocks;i++) {
		if (!CanContainPoint(trk+i,&pt,sDist+sWidth)) continue;
		isModified=FALSE;
		v=trk[i].vert;
		n=trk[i].nVertices;
		for (j=0;j<n;j++,v++) {
			dist=(float)sqrt((v->x-pt.x)*(v->x-pt.x)+(v->y-pt.y)*(v->y-pt.y)+(v->z-pt.z)*(v->z-pt.z));
			if (dist<sDist+sWidth)
			{
				PrepareModifyTrk(i);
				isModified=TRUE;
				if (dist<sDist) dist=1.0;
				else dist=(float)(0.5+0.5*cos(3.1415926*(dist-sDist)/sWidth));
				v->x+=dx*dist; v->z+=dz*dist; v->y+=dy*dist;
			}
		}
		if (isModified)
			for (k=0;k<trk[i].nPolygons;k++)
				RecalcPolyVroad(i,k);
		// lights etc...
		for (j=0,light=trk[i].lightsrc;j<trk[i].nLightsrc;j++,light++) {
			dist=(float)sqrt(
				(light->refpoint.x/65536-pt.x)*(light->refpoint.x/65536-pt.x)+
				(light->refpoint.y/65536-pt.y)*(light->refpoint.y/65536-pt.y)+
				(light->refpoint.z/65536-pt.z)*(light->refpoint.z/65536-pt.z));
			if (dist<sDist+sWidth)
			{
				PrepareModifyTrk(i); isModified=TRUE;
				if (dist<sDist) dist=1.0;
				else dist=(float)(0.5+0.5*cos(3.1415926*(dist-sDist)/sWidth));
				light->refpoint.x+=(long)(65536*dx*dist); 
				light->refpoint.z+=(long)(65536*dz*dist); 
				light->refpoint.y+=(long)(65536*dy*dist);
			}
		}
		for (j=0,sound=trk[i].soundsrc;j<trk[i].nSoundsrc;j++,sound++) {
			dist=(float)sqrt(
				(sound->refpoint.x/65536-pt.x)*(sound->refpoint.x/65536-pt.x)+
				(sound->refpoint.y/65536-pt.y)*(sound->refpoint.y/65536-pt.y)+
				(sound->refpoint.z/65536-pt.z)*(sound->refpoint.z/65536-pt.z));
			if (dist<sDist+sWidth)
			{
				PrepareModifyTrk(i); isModified=TRUE;
				if (dist<sDist) dist=1.0;
				else dist=(float)(0.5+0.5*cos(3.1415926*(dist-sDist)/sWidth));
				sound->refpoint.x+=(long)(65536*dx*dist); 
				sound->refpoint.z+=(long)(65536*dz*dist); 
				sound->refpoint.y+=(long)(65536*dy*dist);
			}
		}
		// xobj
		for (j=4*i;j<4*i+4;j++) {
			x=xobj[j].obj;
			for (k=0;k<xobj[j].nobj;k++,x++) {
				v=x->vert;
				for (l=0;l<x->nVertices;l++,v++) {
					dist=(float)sqrt((v->x+x->ptRef.x-pt.x)*(v->x+x->ptRef.x-pt.x)+
							  (v->y+x->ptRef.y-pt.y)*(v->y+x->ptRef.y-pt.y)+
							  (v->z+x->ptRef.z-pt.z)*(v->z+x->ptRef.z-pt.z));
					if (dist<sDist+sWidth) {
						PrepareModifyXobj(j);
						isModified=TRUE;
						if (dist<sDist) dist=1.0;
						else dist=(float)(0.5+0.5*cos(3.1415926*(dist-sDist)/sWidth));
						v->x+=dx*dist; v->z+=dz*dist; v->y+=dy*dist;
					}
				}
			}
		}
		if (isModified) {
			if ((dx!=0)||(dy!=0)) RecalcBoundingBox(i);
		}
	}
}

int CT3EDDoc::MoveObjectBy(int blk,int isxobj,int chunk,int no,float dx,float dy,float dz)
{
	struct XOBJDATA *x;
	struct INTPT *pt;
	LPPOLYGONDATA p;
	struct TRKBLOCK *b;
	int i,j,k,l,c,num;
	short vno;
	float dist,dist0;
	struct FLOATPT *ref,tmppt;

	PrepareModifyTrk(blk);
	b=&(trk[blk]);
	if (isxobj==2) {
		b->lightsrc[no].refpoint.x+=(long)(dx*65536);
		b->lightsrc[no].refpoint.z+=(long)(dz*65536);
		b->lightsrc[no].refpoint.y+=(long)(dy*65536);
		ref=&tmppt;
		tmppt.x=((float)b->lightsrc[no].refpoint.x)/65536;
		tmppt.z=((float)b->lightsrc[no].refpoint.z)/65536;
		tmppt.y=((float)b->lightsrc[no].refpoint.y)/65536;
	}
	else if (isxobj==1) {
		PrepareModifyXobj(4*blk+chunk);
		x=&(xobj[4*blk+chunk].obj[no]);
		if (x->crosstype==4) { // normal case
			pt=&(b->xobj[x->crossno].pt);
			pt->x+=(long)(dx*65536);
			pt->z+=(long)(dz*65536);
			pt->y+=(long)(dy*65536);
		}
		if (x->crosstype==3) { // animated xobj
			for (i=0;i<x->nAnimLength;i++) {
				x->animData[i].pt.x+=(long)(dx*65536);
				x->animData[i].pt.z+=(long)(dz*65536);
				x->animData[i].pt.y+=(long)(dy*65536);
			}
		}
		x->ptRef.x+=dx; x->ptRef.z+=dz; x->ptRef.y+=dy;
		ref=&(x->ptRef);
	} 
	else {
		num=poly[blk].obj[chunk].numpoly[no];
		p=poly[blk].obj[chunk].poly[no];
		ref=b->vert+p[0].vertex[0];
		for (i=0;i<num;i++) for (j=0;j<4;j++) {
			vno=p[i].vertex[j];
			c=0;
			for (k=0;k<i;k++) for (l=0;l<4;l++)
				if (p[k].vertex[l]==vno) c++;
			for (l=0;l<j;l++) if (p[i].vertex[l]==vno) c++;
			if (c==0) {
				b->vert[vno].x+=dx;
				b->vert[vno].y+=dy;
				b->vert[vno].z+=dz;
			}
		}
	}

	if ((dx!=0)||(dy!=0)) {
		RecalcBoundingBox(blk);
		// see if the block should be changed
		dist0=(ref->x-b->ptCentre.x)*(ref->x-b->ptCentre.x)+
			  (ref->z-b->ptCentre.z)*(ref->z-b->ptCentre.z)+
			  (ref->y-b->ptCentre.y)*(ref->y-b->ptCentre.y);
		dist0=dist0/10; num=blk;
		for (i=0;i<nBlocks;i++) {
			b=&(trk[i]);
			dist=(ref->x-b->ptCentre.x)*(ref->x-b->ptCentre.x)+
				 (ref->z-b->ptCentre.z)*(ref->z-b->ptCentre.z)+
				 (ref->y-b->ptCentre.y)*(ref->y-b->ptCentre.y);
			if (dist<dist0) { num=i; dist0=dist; }
		}
		if (num!=blk) ChangeObjBlock(blk,isxobj,chunk,no,num);
		return num;
	}
	return blk;
}

void CT3EDDoc::ChangeObjBlock(int blk1,int isxobj,int chunk,int no,int blk2)
{
	struct XOBJDATA *x;
	struct XOBJBLOCK *xb1,*xb2;
	int i,j,k,l,n,ii,jj,nn,oldno,oldpos,shiftby;
	short vno,vno2;
	struct OBJPOLYBLOCK *o,*oo;
	struct TRKBLOCK *t1,*t2;
	LPPOLYGONDATA p,pp;

	if (blk1==blk2) return;
	PrepareModifyTrk(blk1);
	PrepareModifyTrk(blk2);
	PrepareModifyPoly(blk1);
	PrepareModifyPoly(blk2);
	if (isxobj==2) {
		t1=&(trk[blk1]);
		t2=&(trk[blk2]);
		t1->nLightsrc--;
		t2->nLightsrc++;
		t2->lightsrc=(struct LIGHTSRC *)realloc(t2->lightsrc,t2->nLightsrc*sizeof(struct LIGHTSRC));
		memcpy(t2->lightsrc+t2->nLightsrc-1,t1->lightsrc+no,sizeof(struct LIGHTSRC));
		for (i=no;i<t1->nLightsrc;i++)
			memcpy(t1->lightsrc+i,t1->lightsrc+i+1,sizeof(struct LIGHTSRC));
	}
	else if (isxobj==1) {
		for (i=0;i<4;i++) PrepareModifyXobj(4*blk1+i);
		PrepareModifyXobj(4*blk2+chunk);
		// update xobj blocks
		xb2=&(xobj[4*blk2+chunk]);
		xb1=&(xobj[4*blk1+chunk]);
		xb2->nobj++;
		xb2->obj=(struct XOBJDATA *)realloc(xb2->obj,xb2->nobj*sizeof(struct XOBJDATA));
		x=&(xb2->obj[xb2->nobj-1]);
		memcpy(x,&(xb1->obj[no]),sizeof(struct XOBJDATA));
		xb1->nobj--;
		for (i=no;i<xb1->nobj;i++)
			memcpy(&(xb1->obj[i]),&(xb1->obj[i+1]),sizeof(struct XOBJDATA));
		oldno=x->crossno;
		if (x->crosstype==4)
			for (i=4*blk1;i<4*blk1+4;i++)
				for (j=0;j<xobj[i].nobj;j++)
					if (xobj[i].obj[j].crossno>oldno)
						xobj[i].obj[j].crossno--;
		x->crossno=trk[blk2].nXobj;
		// update polyobj blocks
		o=&(poly[blk1].obj[chunk]);
		if (o->n1>0) {
			oldpos=-1; j=-1;
			while (j<no) if (o->types[++oldpos]!=1) j++;
			o->n2--;
			for (i=oldpos;i<o->n2;i++) o->types[i]=o->types[i+1];
		}
		o=&(poly[blk2].obj[chunk]);
		if (o->n1>0) {
			o->n2++;
			o->types=(long *)realloc(o->types,4*o->n2);
			o->types[o->n2-1]=x->crosstype;
		}
		// update trk blocks
		t1=&(trk[blk1]);
		t2=&(trk[blk2]);
		if (x->crosstype==4) {
			t2->nXobj++;
			t2->xobj=(struct REFXOBJ *)realloc(t2->xobj,t2->nXobj*sizeof(struct REFXOBJ));
			memcpy(&(t2->xobj[t2->nXobj-1]),t1->xobj+oldno,sizeof(struct REFXOBJ));
			if (chunk==0) t2->xobj[t2->nXobj-1].crossindex=0;
			t1->nXobj--;
			for (i=oldno;i<t1->nXobj;i++) {
				memcpy(&(t1->xobj[i]),&(t1->xobj[i+1]),sizeof(struct REFXOBJ));
				if ((chunk==0)&&(t1->xobj[i].crossindex!=0)) 
					t1->xobj[i].crossindex--;
			}
		}
		// update global xobj sequence numbers
		n=0;
		for (i=0;i<nBlocks;i++)
			for (j=0;j<trk[i].nXobj;j++)
				trk[i].xobj[j].globalno=n++;
	} else {
		// update vertices
		t1=&(trk[blk1]);
		t2=&(trk[blk2]);
		o=&(poly[blk1].obj[chunk]);
		n=o->numpoly[no];
		p=o->poly[no];
		shiftby=0;
		for (i=0;i<n;i++) for (j=0;j<4;j++) {
			vno=p[i].vertex[j];
			if (vno<0) continue;
			shiftby++;
			vno2=(short)t2->nObjectVert;
			// update dest block
			t2->nVertices++; t2->nVerticesDup++;
			t2->nObjectVert++;
			t2->nLoResVert++; t2->nHiResVert++; t2->nMedResVert++;
			t2->vert=(struct FLOATPT *)realloc(t2->vert,t2->nVertices*12);
			t2->unknVertices=(long *)realloc(t2->unknVertices,t2->nVertices*4);
			memmove(t2->vert+vno2+1,t2->vert+vno2,12*(t2->nVertices-vno2-1));
			memmove(t2->unknVertices+vno2+1,t2->unknVertices+vno2,4*(t2->nVertices-vno2-1));
			t2->unknVertices[vno2]=t1->unknVertices[vno];
			memcpy(t2->vert+vno2,t1->vert+vno,12);
			for (k=i;k<n;k++) for (l=0;l<4;l++)
				if (p[k].vertex[l]==vno) {
					p[k].vertex[l]=-vno2-1;
				}
			// update src block
			oo=poly[blk1].obj;
			for (ii=0;ii<4;ii++,oo++) 
				for (jj=0;jj<oo->nobj;jj++) {
					nn=oo->numpoly[jj];
					pp=oo->poly[jj];
					for (k=0;k<nn;k++,pp++) for (l=0;l<4;l++) {
						ASSERT(pp->vertex[l]!=vno);
						if (pp->vertex[l]>vno) pp->vertex[l]--;
					}
				}
			t1->nVertices--; t1->nVerticesDup--;
			t1->nObjectVert--;
			t1->nLoResVert--; t1->nHiResVert--; t1->nMedResVert--;
			memmove(t1->vert+vno,t1->vert+vno+1,12*(t1->nVertices-vno));
			memmove(t1->unknVertices+vno,t1->unknVertices+vno+1,4*(t1->nVertices-vno));
		}
		for (i=0;i<n;i++) for (j=0;j<4;j++)
			p[i].vertex[j]=-1-p[i].vertex[j];
		// p and n must be preserved for below
		for (i=0;i<=6;i++) {
			nn=poly[blk1].sz[i];
			pp=poly[blk1].poly[i];
			for (j=0;j<nn;j++,pp++) for (k=0;k<4;k++)
				pp->vertex[k]-=shiftby;
			nn=poly[blk2].sz[i];
			pp=poly[blk2].poly[i];
			for (j=0;j<nn;j++,pp++) for (k=0;k<4;k++)
				pp->vertex[k]+=shiftby;
		}
		// update objpolyblock
		o->n1-=n;
		o->n2--;
		o->nobj--;
		for (i=no;i<o->nobj;i++) {
			o->numpoly[i]=o->numpoly[i+1];
			o->poly[i]=o->poly[i+1];
		}
		oldpos=-1; j=-1;
		while (j<no) if (o->types[++oldpos]==1) j++;
		for (i=oldpos;i<o->n2;i++) o->types[i]=o->types[i+1];
		o=&(poly[blk2].obj[chunk]);
		if (o->n1==0) { // re-create objpolyblock
			o->n2=xobj[4*blk2+chunk].nobj;
			o->nobj=0;
			o->types=(long *)realloc(o->types,4*o->n2);
			for (i=0;i<o->n2;i++) 
				o->types[i]=xobj[4*blk2+chunk].obj[i].crosstype;
		}
		o->n1+=n;
		o->n2++;
		o->nobj++;
		o->types=(long *)realloc(o->types,4*o->n2);
		o->types[o->n2-1]=1;
		o->numpoly=(long *)realloc(o->numpoly,4*o->nobj);
		o->numpoly[o->nobj-1]=n;
		o->poly=(LPPOLYGONDATA *)realloc(o->poly,4*o->nobj);
		o->poly[o->nobj-1]=p;
	}
	RecalcBoundingBox(blk1);
	RecalcBoundingBox(blk2);
}

inline float CT3EDDoc::Distance(struct FLOATPT &a,struct INTPT &b) 
{
	return ((65536*a.x-b.x)*(65536*a.x-b.x)
		   +(65536*a.y-b.y)*(65536*a.y-b.y));
}

int CT3EDDoc::GlobalLocalCoord(struct FLOATPT &org,struct FLOATPT &res,struct COLVROAD *c,int start,int minblk,int maxblk)
{
	int i,n;
	float dist,test;
	struct INTPT *p1,*p2;

	n=col.vroadHead.nrec;
	i=start;
	dist=Distance(org,c[i].refPt);
	test=Distance(org,c[(i+1)%n].refPt);
	if (test<dist) { // move right
		do {
			i=(i+1)%n; dist=test;
			if (i==maxblk) break;
			test=Distance(org,c[(i+1)%n].refPt);
		} while (test<dist);
	} else { // move left ?
		test=Distance(org,c[(i+n-1)%n].refPt);
		while (test<dist) {
			i=(i+n-1)%n; dist=test;
			if (i==minblk) break;
			test=Distance(org,c[(i+n-1)%n].refPt);
		}
	}
	if (Distance(org,c[(i+1)%n].refPt)>Distance(org,c[(i+n-1)%n].refPt))
		i=(i+n-1)%n;
	p1=&(c[i].refPt); p2=&(c[(i+1)%n].refPt);
	dist=(float)(p2->x-p1->x)*(float)(p2->x-p1->x)+(float)(p2->y-p1->y)*(float)(p2->y-p1->y);
	test=(65536*org.x-p1->x)*(p2->x-p1->x)+(65536*org.y-p1->y)*(p2->y-p1->y);
	res.x=test/dist;
	test=(65536*org.x-p1->x)*(p2->y-p1->y)-(65536*org.y-p1->y)*(p2->x-p1->x);
	res.y=test/((float)sqrt(dist));
	res.z=65536*org.z-p1->z-res.x*(p2->z-p1->z);
	return i;
}

void CT3EDDoc::LocalGlobalCoord(struct FLOATPT &org,struct FLOATPT &res,struct COLVROAD *c,int i)
{
	int n;
	float dist;
	struct INTPT *p1,*p2;

	n=col.vroadHead.nrec;
	p1=&(c[i].refPt); p2=&(c[(i+1)%n].refPt);
	dist=(float)sqrt((float)(p2->x-p1->x)*(float)(p2->x-p1->x)+(float)(p2->y-p1->y)*(float)(p2->y-p1->y));
	res.x=(p1->x+org.x*(p2->x-p1->x)+org.y*(p2->y-p1->y)/dist)/65536;
	res.y=(p1->y+org.x*(p2->y-p1->y)-org.y*(p2->x-p1->x)/dist)/65536;
	res.z=(org.z+p1->z+org.x*(p2->z-p1->z))/65536;
}

void CT3EDDoc::UpdateColVroadVecs(int i)
{
	struct INTPT *p1,*p2;
	float distxy,dist;

	p1=&(col.vroad[i].refPt);
	p2=&(col.vroad[i?(i-1):(col.vroadHead.nrec-1)].refPt);
	distxy=(float)(p1->x-p2->x)*(float)(p1->x-p2->x)+
		   (float)(p1->y-p2->y)*(float)(p1->y-p2->y);
	dist=(float)sqrt(distxy+(float)(p1->z-p2->z)*(float)(p1->z-p2->z));
	distxy=(float)sqrt(distxy);
	col.vroad[i].forward.x=(signed char)((p1->x-p2->x)*127/dist);
	col.vroad[i].forward.y=(signed char)((p1->y-p2->y)*127/dist);
	col.vroad[i].forward.z=(signed char)((p1->z-p2->z)*127/dist);
	col.vroad[i].right.x=(signed char)((p1->y-p2->y)*127/distxy);
	col.vroad[i].right.y=(signed char)(-(p1->x-p2->x)*127/distxy);
	col.vroad[i].right.z=0;
	col.vroad[i].normal.x=(signed char)(-((p1->z-p2->z)/dist)*(p1->x-p2->x)*127/distxy);
	col.vroad[i].normal.y=(signed char)(-((p1->z-p2->z)/dist)*(p1->y-p2->y)*127/distxy);
	col.vroad[i].normal.z=(signed char)(distxy*127/dist);
}

// if blk<0, then clear all track ; if sDist!=0 set XY circle, if sWidth!=0 set Z=0
void CT3EDDoc::MoveBlocks(int blk,float dx,float dy,float dz,int sDist,int sWidth,BOOL extraSmooth)
{
	int start,minblk,maxblk,i,j,k,n,ref,min2,max2;
	struct INTPT *p1,*p2;
	float coeff,t;
	struct FLOATPT tmppt,tpt,*v;
	struct FLOATPT interp[5];
	struct LIGHTSRC *light;
	struct SOUNDSRC *sound;

	n=col.vroadHead.nrec;
	undoCol[undoLevel-1]=(struct COLVROAD *)malloc(36*n);
	memcpy(undoCol[undoLevel-1],col.vroad,36*n);

	if (blk<0) {
		// new V0.06 clear-all function
		for (i=0;i<n;i++) {
			if (sDist!=0) {
				col.vroad[i].refPt.x=(int)(65536*n*cos(2*i*3.14159265359/n));
				col.vroad[i].refPt.y=(int)(65536*n*sin(2*i*3.14159265359/n));
			}
			if (sWidth!=0) col.vroad[i].refPt.z=0;
		}
		for (i=0;i<n;i++) UpdateColVroadVecs(i);
		minblk=0; maxblk=n-1;
	} else
	if (extraSmooth) {
		// new V0.02 deformation technique
		i=trk[blk].nStartPos+trk[blk].nPositions/2+sWidth;
		maxblk=(i+8)%n;
		i=i%n;
		interp[4].x=(float)col.vroad[i].refPt.x;
		interp[4].y=(float)col.vroad[i].refPt.y;
		interp[4].z=(float)col.vroad[i].refPt.z;
		interp[3].x=sWidth*(float)(col.vroad[i].refPt.x-col.vroad[(i+n-1)%n].refPt.x);
		interp[3].y=sWidth*(float)(col.vroad[i].refPt.y-col.vroad[(i+n-1)%n].refPt.y);
		interp[3].z=sWidth*(float)(col.vroad[i].refPt.z-col.vroad[(i+n-1)%n].refPt.z);
		i-=sWidth;
		if (i<0) i+=n;
		interp[2].x=(float)col.vroad[i].refPt.x+65536*dx;
		interp[2].y=(float)col.vroad[i].refPt.y+65536*dy;
		interp[2].z=(float)col.vroad[i].refPt.z+65536*dz;
		i-=sWidth;
		if (i<0) i+=n;
		minblk=(i+n-8)%n;
		interp[0].x=(float)col.vroad[i].refPt.x;
		interp[0].y=(float)col.vroad[i].refPt.y;
		interp[0].z=(float)col.vroad[i].refPt.z;
		interp[1].x=sWidth*(float)(col.vroad[(i+1)%n].refPt.x-col.vroad[i].refPt.x);
		interp[1].y=sWidth*(float)(col.vroad[(i+1)%n].refPt.y-col.vroad[i].refPt.y);
		interp[1].z=sWidth*(float)(col.vroad[(i+1)%n].refPt.z-col.vroad[i].refPt.z);
	
		for (j=-sWidth;j<=sWidth;j++) {
			t=((float)j)/sWidth;
			p1=&(col.vroad[i].refPt);
			if ((dx!=0)||(dy!=0)) {
				p1->x=(long)(interp[0].x*(1-t)*(t-1)*t*(2*t+3)/4+
							 interp[1].x*(1-t)*(t-1)*t*(t+1)/4+
							 interp[2].x*(1-t)*(1+t)*(1-t)*(1+t)+
							 interp[3].x*(t+1)*(t+1)*t*(t-1)/4+
							 interp[4].x*(t+1)*(t+1)*t*(3-2*t)/4);
				p1->y=(long)(interp[0].y*(1-t)*(t-1)*t*(2*t+3)/4+
							 interp[1].y*(1-t)*(t-1)*t*(t+1)/4+
							 interp[2].y*(1-t)*(1+t)*(1-t)*(1+t)+
							 interp[3].y*(t+1)*(t+1)*t*(t-1)/4+
							 interp[4].y*(t+1)*(t+1)*t*(3-2*t)/4);
			}
			if (dz!=0)
				p1->z=(long)(interp[0].z*(1-t)*(t-1)*t*(2*t+3)/4+
							 interp[1].z*(1-t)*(t-1)*t*(t+1)/4+
							 interp[2].z*(1-t)*(1+t)*(1-t)*(1+t)+
							 interp[3].z*(t+1)*(t+1)*t*(t-1)/4+
							 interp[4].z*(t+1)*(t+1)*t*(3-2*t)/4);
			UpdateColVroadVecs(i);
			if (++i==n) i=0;
		}
	} else {
		// V0.01 deformation technique
		i=trk[blk].nStartPos+(trk[blk].nPositions-sDist)/2-sWidth;
		while (i<0) i+=n;
		minblk=i;
		// construct the new vroad
		for (j=sWidth;j>=0;j--) {
			coeff=(float)(0.5+0.5*cos(3.1415926*j/sWidth));
			p1=&(col.vroad[i].refPt);
			p1->x+=(long)(dx*coeff*65536);
			p1->y+=(long)(dy*coeff*65536);
			p1->z+=(long)(dz*coeff*65536);
			UpdateColVroadVecs(i);
			if (++i==n) i=0;
		}
		for (j=1;j<sDist;j++) {
			p1=&(col.vroad[i].refPt);
			p1->x+=(long)(dx*65536);
			p1->y+=(long)(dy*65536);
			p1->z+=(long)(dz*65536);
			if (++i==n) i=0;
		}
		for (j=1;j<=sWidth;j++) {
			coeff=(float)(0.5+0.5*cos(3.1415926*j/sWidth));
			p1=&(col.vroad[i].refPt);
			p1->x+=(long)(dx*coeff*65536);
			p1->y+=(long)(dy*coeff*65536);
			p1->z+=(long)(dz*coeff*65536);
			UpdateColVroadVecs(i);
			if (++i==n) i=0;
		}
		maxblk=i;
	}

	// remap the vertices onto the vroad
	i=0;
	while (trk[i].nStartPos+trk[i].nPositions<=minblk) i++;
	while (TRUE) {
		PrepareModifyTrk(i);
		v=trk[i].vert;
		start=trk[i].nStartPos+trk[i].nPositions/2;
		min2=(trk[i].nStartPos+n-8)%n;
		max2=(trk[i].nStartPos+trk[i].nPositions+7)%n;
		ref=GlobalLocalCoord(trk[i].ptCentre,tpt,undoCol[undoLevel-1],start,min2,max2);
		LocalGlobalCoord(tpt,trk[i].ptCentre,col.vroad,ref);
		for (j=0;j<trk[i].nVertices;j++,v++) {
			if (fabs(v->x)>1E7) continue;
			if (fabs(v->y)>1E7) continue;
			ref=GlobalLocalCoord(*v,tpt,undoCol[undoLevel-1],start,min2,max2);
			LocalGlobalCoord(tpt,*v,col.vroad,ref);
		}
		for (j=0,light=trk[i].lightsrc;j<trk[i].nLightsrc;j++,light++) {
			tmppt.x=(float)(light->refpoint.x/65536);
			tmppt.y=(float)(light->refpoint.y/65536);
			tmppt.z=(float)(light->refpoint.z/65536);
			ref=GlobalLocalCoord(tmppt,tpt,undoCol[undoLevel-1],start,min2,max2);
			LocalGlobalCoord(tpt,tmppt,col.vroad,ref);
			light->refpoint.x=(long)(65536*tmppt.x);
			light->refpoint.y=(long)(65536*tmppt.y);
			light->refpoint.z=(long)(65536*tmppt.z);
		}
		for (j=0,sound=trk[i].soundsrc;j<trk[i].nSoundsrc;j++,sound++) {
			tmppt.x=(float)(sound->refpoint.x/65536);
			tmppt.y=(float)(sound->refpoint.y/65536);
			tmppt.z=(float)(sound->refpoint.z/65536);
			ref=GlobalLocalCoord(tmppt,tpt,undoCol[undoLevel-1],start,min2,max2);
			LocalGlobalCoord(tpt,tmppt,col.vroad,ref);
			sound->refpoint.x=(long)(65536*tmppt.x);
			sound->refpoint.y=(long)(65536*tmppt.y);
			sound->refpoint.z=(long)(65536*tmppt.z);
		}
		p1=&(col.vroad[trk[i].nStartPos].refPt);
		p2=&(col.vroad[trk[i].nStartPos+trk[i].nPositions-1].refPt);
		tmppt.x=(float)(p2->x-p1->x);
		tmppt.z=(float)(p2->z-p1->z);
		tmppt.y=(float)(p2->y-p1->y);
		for (j=0;j<trk[i].nPolygons;j++)
			RecalcPolyVroad(i,j,&tmppt);
		for (j=4*i;j<4*i+4;j++) if (xobj[j].nobj) {
			PrepareModifyXobj(j);
			for (k=0;k<xobj[j].nobj;k++) {
				ref=GlobalLocalCoord(xobj[j].obj[k].ptRef,tpt,undoCol[undoLevel-1],start,min2,max2);
				LocalGlobalCoord(tpt,xobj[j].obj[k].ptRef,col.vroad,ref);
			}
		}
		for (j=0;j<trk[i].nXobj;j++) {
			tmppt.x=(float)(trk[i].xobj[j].pt.x/65536.0);
			tmppt.z=(float)(trk[i].xobj[j].pt.z/65536.0);
			tmppt.y=(float)(trk[i].xobj[j].pt.y/65536.0);
			ref=GlobalLocalCoord(tmppt,tpt,undoCol[undoLevel-1],start,min2,max2);
			LocalGlobalCoord(tpt,tmppt,col.vroad,ref);
			trk[i].xobj[j].pt.x=(long)(tmppt.x*65536);
			trk[i].xobj[j].pt.z=(long)(tmppt.z*65536);
			trk[i].xobj[j].pt.y=(long)(tmppt.y*65536);
		}
		RecalcBoundingBox(i);
		if ((trk[i].nStartPos<=maxblk)&&
			(trk[i].nStartPos+trk[i].nPositions>maxblk)) break;
		i++;
		if (i==nBlocks) i=0;
	}
}

void CT3EDDoc::DelObject(int blk,int isxobj,int chunk,int no)
{
	struct XOBJBLOCK *xb;
	int i,j,k,l,n,ii,jj,nn,oldno,oldpos,shiftby;
	short vno;
	struct OBJPOLYBLOCK *o,*oo;
	struct TRKBLOCK *t;
	LPPOLYGONDATA p,pp;

	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	if (isxobj==2) {
		t=trk+blk;
		t->nLightsrc--;
		for (i=no;i<t->nLightsrc;i++)
			memcpy(t->lightsrc+i,t->lightsrc+i+1,sizeof(struct LIGHTSRC));
	} else
	if (isxobj==1) {
		for (i=0;i<4;i++) PrepareModifyXobj(4*blk+i);
		// update xobj blocks
		xb=&(xobj[4*blk+chunk]);
		oldno=xb->obj[no].crossno;
		nn=xb->obj[no].crosstype;
		if (nn==3) dofree(xb->obj[no].animData);
		dofree(xb->obj[no].vert);
		dofree(xb->obj[no].unknVertices);
		dofree(xb->obj[no].polyData);
		xb->nobj--;
		for (i=no;i<xb->nobj;i++)
			memcpy(&(xb->obj[i]),&(xb->obj[i+1]),sizeof(struct XOBJDATA));
		if (nn==4)
			for (i=4*blk;i<4*blk+4;i++)
				for (j=0;j<xobj[i].nobj;j++)
					if (xobj[i].obj[j].crossno>oldno)
						xobj[i].obj[j].crossno--;
		// update polyobj blocks
		o=&(poly[blk].obj[chunk]);
		if (o->n1>0) {
			oldpos=-1; j=-1;
			while (j<no) if (o->types[++oldpos]!=1) j++;
			o->n2--;
			for (i=oldpos;i<o->n2;i++) o->types[i]=o->types[i+1];
		}
		// update trk blocks
		t=&(trk[blk]);
		if (nn==4) {
			t->nXobj--;
			for (i=oldno;i<t->nXobj;i++) {
				memcpy(&(t->xobj[i]),&(t->xobj[i+1]),sizeof(struct REFXOBJ));
				if ((chunk==0)&&(t->xobj[i].crossindex!=0)) 
					t->xobj[i].crossindex--;
			}
		}
		// update global xobj sequence numbers
		n=0;
		for (i=0;i<nBlocks;i++)
			for (j=0;j<trk[i].nXobj;j++)
				trk[i].xobj[j].globalno=n++;
	} else {
		// update vertices
		t=&(trk[blk]);
		o=&(poly[blk].obj[chunk]);
		n=o->numpoly[no];
		p=o->poly[no];
		shiftby=0;
		for (i=0;i<n;i++) for (j=0;j<4;j++) {
			vno=p[i].vertex[j];
			if (vno<0) continue;
			shiftby++;
			for (k=i;k<n;k++) for (l=0;l<4;l++)
				if (p[k].vertex[l]==vno) p[k].vertex[l]=-1;
			oo=poly[blk].obj;
			for (ii=0;ii<4;ii++,oo++) 
				for (jj=0;jj<oo->nobj;jj++) {
					nn=oo->numpoly[jj];
					pp=oo->poly[jj];
					for (k=0;k<nn;k++,pp++) for (l=0;l<4;l++) {
						ASSERT(pp->vertex[l]!=vno);
						if (pp->vertex[l]>vno) pp->vertex[l]--;
					}
				}
			t->nVertices--; t->nVerticesDup--;
			t->nObjectVert--;
			t->nLoResVert--; t->nHiResVert--; t->nMedResVert--;
			memmove(t->vert+vno,t->vert+vno+1,12*(t->nVertices-vno));
			memmove(t->unknVertices+vno,t->unknVertices+vno+1,4*(t->nVertices-vno));
		}
		for (i=0;i<=6;i++) {
			nn=poly[blk].sz[i];
			pp=poly[blk].poly[i];
			for (j=0;j<nn;j++,pp++) for (k=0;k<4;k++)
				pp->vertex[k]-=shiftby;
		}
		// update objpolyblock
		o->n1-=n;
		o->n2--;
		o->nobj--;
		dofree(o->poly[no]);
		for (i=no;i<o->nobj;i++) {
			o->numpoly[i]=o->numpoly[i+1];
			o->poly[i]=o->poly[i+1];
		}
		oldpos=-1; j=-1;
		while (j<no) if (o->types[++oldpos]==1) j++;
		for (i=oldpos;i<o->n2;i++) o->types[i]=o->types[i+1];
	}
	RecalcBoundingBox(blk);
}

void CT3EDDoc::DuplObject(int blk,int isxobj,int chunk,int no)
{
	struct XOBJDATA *x;
	struct XOBJBLOCK *xb;
	int i,j,k,l,n,nn,oldno,shiftby;
	short vno,vno2;
	struct OBJPOLYBLOCK *o;
	struct TRKBLOCK *t;
	LPPOLYGONDATA p,pp;

	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	if (isxobj==2) {
		t=trk+blk;
		t->nLightsrc++;
		t->lightsrc=(struct LIGHTSRC *)realloc(t->lightsrc,t->nLightsrc*sizeof(struct LIGHTSRC));
		memcpy(t->lightsrc+t->nLightsrc-1,t->lightsrc+no,sizeof(struct LIGHTSRC));
	} else
	if (isxobj==1) {
		PrepareModifyXobj(4*blk+chunk);
		// update xobj blocks
		xb=&(xobj[4*blk+chunk]);
		xb->nobj++;
		xb->obj=(struct XOBJDATA *)realloc(xb->obj,xb->nobj*sizeof(struct XOBJDATA));
		x=&(xb->obj[xb->nobj-1]);
		memcpy(x,&(xb->obj[no]),sizeof(struct XOBJDATA));
		x->vert=(struct FLOATPT *)malloc(12*x->nVertices);
		memcpy(x->vert,xb->obj[no].vert,12*x->nVertices);
		x->unknVertices=(long *)malloc(4*x->nVertices);
		memcpy(x->unknVertices,xb->obj[no].unknVertices,4*x->nVertices);
		x->polyData=(LPPOLYGONDATA)malloc(14*x->nPolygons);
		memcpy(x->polyData,xb->obj[no].polyData,14*x->nPolygons);
		if (x->crosstype==3) {
			x->animData=(struct ANIMDATA *)malloc(x->nAnimLength*sizeof(struct ANIMDATA));
			memcpy(x->animData,xb->obj[no].animData,x->nAnimLength*sizeof(struct ANIMDATA));
		}
		oldno=x->crossno;
		x->crossno=trk[blk].nXobj;
		// update polyobj blocks
		o=&(poly[blk].obj[chunk]);
		if (o->n1>0) {
			o->n2++;
			o->types=(long *)realloc(o->types,4*o->n2);
			o->types[o->n2-1]=x->crosstype;
		}
		// update trk blocks
		t=&(trk[blk]);
		if (x->crosstype==4) {
			t->nXobj++;
			t->xobj=(struct REFXOBJ *)realloc(t->xobj,t->nXobj*sizeof(struct REFXOBJ));
			memcpy(&(t->xobj[t->nXobj-1]),t->xobj+oldno,sizeof(struct REFXOBJ));
			if (chunk==0) t->xobj[t->nXobj-1].crossindex=(char)t->nPolyobj;
		}
		// update global xobj sequence numbers
		n=0;
		for (i=0;i<nBlocks;i++)
			for (j=0;j<trk[i].nXobj;j++)
				trk[i].xobj[j].globalno=n++;
	} else {
		// update vertices
		t=&(trk[blk]);
		o=&(poly[blk].obj[chunk]);
		n=o->numpoly[no];
		p=(LPPOLYGONDATA)malloc(n*sizeof(struct POLYGONDATA));
		memcpy(p,o->poly[no],n*sizeof(struct POLYGONDATA));
		shiftby=0;
		for (i=0;i<n;i++) for (j=0;j<4;j++) {
			vno=p[i].vertex[j];
			if (vno<0) continue;
			shiftby++;
			vno2=(short)t->nObjectVert;
			t->nVertices++; t->nVerticesDup++;
			t->nObjectVert++;
			t->nLoResVert++; t->nHiResVert++; t->nMedResVert++;
			t->vert=(struct FLOATPT *)realloc(t->vert,t->nVertices*12);
			t->unknVertices=(long *)realloc(t->unknVertices,t->nVertices*4);
			memmove(t->vert+vno2+1,t->vert+vno2,12*(t->nVertices-vno2-1));
			memmove(t->unknVertices+vno2+1,t->unknVertices+vno2,4*(t->nVertices-vno2-1));
			t->unknVertices[vno2]=t->unknVertices[vno];
			memcpy(t->vert+vno2,t->vert+vno,12);
			for (k=i;k<n;k++) for (l=0;l<4;l++)
				if (p[k].vertex[l]==vno) {
					p[k].vertex[l]=-vno2-1;
				}
		}
		for (i=0;i<n;i++) for (j=0;j<4;j++)
			p[i].vertex[j]=-1-p[i].vertex[j];
		// p and n must be preserved for below
		for (i=0;i<=6;i++) {
			nn=poly[blk].sz[i];
			pp=poly[blk].poly[i];
			for (j=0;j<nn;j++,pp++) for (k=0;k<4;k++)
				pp->vertex[k]+=shiftby;
		}
		// update objpolyblock
		o->n1+=n;
		o->n2++;
		o->nobj++;
		o->types=(long *)realloc(o->types,4*o->n2);
		o->types[o->n2-1]=1;
		o->numpoly=(long *)realloc(o->numpoly,4*o->nobj);
		o->numpoly[o->nobj-1]=n;
		o->poly=(LPPOLYGONDATA *)realloc(o->poly,4*o->nobj);
		o->poly[o->nobj-1]=p;
	}
	RecalcBoundingBox(blk);
}

void CT3EDDoc::NewObject(int blk,int isxobj,int chunk,int texture,short flags)
{
	struct XOBJDATA *x;
	struct XOBJBLOCK *xb;
	int i,j,k,n,nn;
	struct OBJPOLYBLOCK *o;
	struct TRKBLOCK *t;
	struct REFXOBJ *rx;
	LPPOLYGONDATA p,pp;

	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	if (isxobj) {
		PrepareModifyXobj(4*blk+chunk);
		// update xobj blocks
		xb=&(xobj[4*blk+chunk]);
		xb->nobj++;
		xb->obj=(struct XOBJDATA *)realloc(xb->obj,xb->nobj*sizeof(struct XOBJDATA));
		x=&(xb->obj[xb->nobj-1]);
		memset(x,0,sizeof(struct XOBJDATA));
		x->crosstype=4;
		x->crossno=trk[blk].nXobj;
		memcpy(&(x->ptRef),&(trk[blk].ptCentre),12);
		x->nVertices=4;
		x->vert=(struct FLOATPT *)malloc(12*4);
		x->unknVertices=(long *)malloc(4*4);
		for (i=0;i<4;i++) {
			x->vert[i].z=(float)((i<2)?2:-2);
			x->vert[i].x=(float)((i%3)?2:-2);
			x->vert[i].y=0;
			x->unknVertices[i]=-1;
		}
		x->nPolygons=1;
		x->polyData=(LPPOLYGONDATA)malloc(14);
		for (i=0;i<4;i++) x->polyData->vertex[i]=i;
		x->polyData->texture=texture;
		x->polyData->unknown1=0;
		if (bHSMode) x->polyData->unknown1=flags;
		x->polyData->unknown2=0xF9;
		x->polyData->flags=0x30; // 2-sided
		// update polyobj blocks
		o=&(poly[blk].obj[chunk]);
		if (o->n1>0) {
			o->n2++;
			o->types=(long *)realloc(o->types,4*o->n2);
			o->types[o->n2-1]=4;
		}
		// update trk blocks
		t=&(trk[blk]);
		t->nXobj++;
		t->xobj=(struct REFXOBJ *)realloc(t->xobj,t->nXobj*sizeof(struct REFXOBJ));
		rx=t->xobj+t->nXobj-1;
		memset(rx,0,sizeof(struct REFXOBJ));
		rx->pt.x=(int)(65536*t->ptCentre.x);
		rx->pt.z=(int)(65536*t->ptCentre.z);
		rx->pt.y=(int)(65536*t->ptCentre.y);
		// update global xobj sequence numbers
		n=0;
		for (i=0;i<nBlocks;i++)
			for (j=0;j<trk[i].nXobj;j++)
				trk[i].xobj[j].globalno=n++;
	} else {
		// update vertices
		t=&(trk[blk]);
		o=&(poly[blk].obj[chunk]);
		p=(LPPOLYGONDATA)malloc(sizeof(struct POLYGONDATA));
		for (i=0;i<4;i++) p->vertex[i]=t->nObjectVert+i;
		p->texture=texture;
		p->unknown1=0;
		if (bHSMode) p->unknown1=flags;
		p->unknown2=0xF9;
		p->flags=0x30; // 2-sided
		t->nVertices+=4; t->nVerticesDup+=4;
		t->nObjectVert+=4;
		t->nLoResVert+=4; t->nHiResVert+=4; t->nMedResVert+=4;
		t->vert=(struct FLOATPT *)realloc(t->vert,t->nVertices*12);
		t->unknVertices=(long *)realloc(t->unknVertices,t->nVertices*4);
		memmove(t->vert+t->nObjectVert,t->vert+t->nObjectVert-4,12*(t->nVertices-t->nObjectVert));
		memmove(t->unknVertices+t->nObjectVert,t->unknVertices+t->nObjectVert-4,4*(t->nVertices-t->nObjectVert));
		for (i=0;i<4;i++) {
			t->vert[t->nObjectVert-4+i].z=t->ptCentre.z+((i<2)?2:-2);
			t->vert[t->nObjectVert-4+i].x=t->ptCentre.x+((i%3)?2:-2);
			t->vert[t->nObjectVert-4+i].y=t->ptCentre.y;
			t->unknVertices[t->nObjectVert-4+i]=-1;
		}
		for (i=0;i<=6;i++) {
			nn=poly[blk].sz[i];
			pp=poly[blk].poly[i];
			for (j=0;j<nn;j++,pp++) for (k=0;k<4;k++)
				pp->vertex[k]+=4;
		}
		// update objpolyblock
		if (o->n1==0) { // re-create objpolyblock
			o->n2=xobj[4*blk+chunk].nobj;
			o->nobj=0;
			o->types=(long *)realloc(o->types,4*o->n2);
			for (i=0;i<o->n2;i++) 
				o->types[i]=xobj[4*blk+chunk].obj[i].crosstype;
		}
		o->n1++;
		o->n2++;
		o->nobj++;
		o->types=(long *)realloc(o->types,4*o->n2);
		o->types[o->n2-1]=1;
		o->numpoly=(long *)realloc(o->numpoly,4*o->nobj);
		o->numpoly[o->nobj-1]=1;
		o->poly=(LPPOLYGONDATA *)realloc(o->poly,4*o->nobj);
		o->poly[o->nobj-1]=p;
	}
	RecalcBoundingBox(blk);
}

void CT3EDDoc::DelPolygon(int blk,int isxobj,int chunk,int obj,int no)
{
	struct XOBJDATA *x;
	int i,j,k,l,m,stopat;
	short vno;
	LPPOLYGONDATA p;
	struct POLYGONBLOCK *pp;
	struct OBJPOLYBLOCK *o;
	struct TRKBLOCK *t;
	struct FLOATPT backup;
	BOOL used;

	// XOBJ case
	if (isxobj) {
		PrepareModifyXobj(4*blk+chunk);
		x=&(xobj[4*blk+chunk].obj[obj]);
		ASSERT(no<x->nPolygons);
		if (x->nPolygons==1) {
			DelObject(blk,isxobj,chunk,obj);
			return;
		}
		for (i=0;i<4;i++) {
			vno=x->polyData[no].vertex[i];
			if (vno<0) continue;
			p=x->polyData; used=FALSE;
			for (j=0;j<x->nPolygons;j++,p++) if (j!=no)
				if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
					(p->vertex[2]==vno)||(p->vertex[3]==vno))
					used=TRUE;
			if (used) continue;
			p=x->polyData;
			for (j=0;j<x->nPolygons;j++,p++) for (k=0;k<4;k++) {
				if (p->vertex[k]==vno) p->vertex[k]=-1;
				if (p->vertex[k]>vno) p->vertex[k]--;
			}
			x->nVertices--;
			j=x->nVertices-vno; if (j==0) continue;
			memmove(x->vert+vno,x->vert+vno+1,12*j);
			memmove(x->unknVertices+vno,x->unknVertices+vno+1,4*j);
		}
		x->nPolygons--;
		memmove(x->polyData+no,x->polyData+no+1,(x->nPolygons-no)*sizeof(struct POLYGONDATA));
		return;
	}

	pp=&(poly[blk]);
	t=&(trk[blk]);
	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	// TRACK POLYGON case
	if (obj==-1) {
		ASSERT(no<pp->sz[chunk]);
		for (i=0;i<4;i++) {
			vno=pp->poly[chunk][no].vertex[i];
			if (vno>=t->nVertices) continue;
			// don't delete vertex if referenced elsewhere
			used=FALSE;
			for (k=0;k<=6;k++) {
				p=pp->poly[k];
				for (j=0;j<pp->sz[k];j++,p++) if ((k!=chunk)||(j!=no))
					if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
						(p->vertex[2]==vno)||(p->vertex[3]==vno))
						used=TRUE;
			}
			if (used) continue;
			stopat=t->nVertices; // will move to stopat-1
			if (chunk<=1) {
				p=pp->poly[2];
				for (j=0;j<pp->sz[2];j++,p++)
					if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
						(p->vertex[2]==vno)||(p->vertex[3]==vno))
						stopat=t->nLoResVert; // make it a medres
				p=pp->poly[3];
				for (j=0;j<pp->sz[3];j++,p++)
					if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
						(p->vertex[2]==vno)||(p->vertex[3]==vno))
						stopat=t->nLoResVert; // make it a medres
			}
			if ((chunk<=3)&&(stopat==t->nVertices)) {
				p=pp->poly[4];
				for (j=0;j<pp->sz[4];j++,p++)
					if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
						(p->vertex[2]==vno)||(p->vertex[3]==vno))
						stopat=t->nMedResVert; // make it a hires
				p=pp->poly[5];
				for (j=0;j<pp->sz[5];j++,p++)
					if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
						(p->vertex[2]==vno)||(p->vertex[3]==vno))
						stopat=t->nMedResVert; // make it a hires
			}
			for (l=0;l<=6;l++) {
				p=pp->poly[l];
				for (j=0;j<pp->sz[l];j++,p++) for (k=0;k<4;k++) {
					if (p->vertex[k]==vno) p->vertex[k]=stopat-1;
					else if ((p->vertex[k]>vno)&&(p->vertex[k]<stopat)) 
						p->vertex[k]--;
				}
			}
			if (t->nVertices==stopat) { t->nVertices--; t->nVerticesDup--; }
			if ((vno<t->nLoResVert)&&(t->nLoResVert<=stopat)) t->nLoResVert--;
			if ((vno<t->nMedResVert)&&(t->nMedResVert<=stopat)) t->nMedResVert--;
			if ((vno<t->nHiResVert)&&(t->nHiResVert<=stopat))  t->nHiResVert--;
			j=stopat-1-vno; if (j==0) continue;
			memcpy(&backup,t->vert+vno,12); l=t->unknVertices[vno];
			memmove(t->vert+vno,t->vert+vno+1,12*j);
			memmove(t->unknVertices+vno,t->unknVertices+vno+1,4*j);
			memcpy(t->vert+stopat-1,&backup,12);
			t->unknVertices[stopat-1]=l;
		}
		pp->sz[chunk]--; pp->szdup[chunk]--;
		memmove(pp->poly[chunk]+no,pp->poly[chunk]+no+1,(pp->sz[chunk]-no)*sizeof(struct POLYGONDATA));
		if (chunk==4) { // update TRKBLOCK too
			t->nPolygons--;
			for (i=0;i<t->nPositions;i++)
				if (t->posData[i].polygon>no) t->posData[i].polygon--;
			for (i=0;i<t->nPositions-1;i++)
				t->posData[i].nPolygons=t->posData[i+1].polygon-t->posData[i].polygon;
			t->posData[t->nPositions-1].nPolygons=t->nPolygons-t->posData[t->nPositions-1].polygon;
			j=t->polyData[no].vroadEntry;
			memmove(t->polyData+no,t->polyData+no+1,(t->nPolygons-no)*sizeof(struct POLYVROADDATA));
			used=FALSE;
			for (i=0;i<t->nPolygons;i++)
				if (t->polyData[i].vroadEntry==j) used=TRUE;
			if (!used) {
				for (i=0;i<t->nPolygons;i++)
					if (t->polyData[i].vroadEntry>j)
						t->polyData[i].vroadEntry--;
				t->nVRoad--;
				memmove(t->vroadData+j,t->vroadData+j+1,(t->nVRoad-j)*sizeof(struct VROADDATA));
			}
		}
		if (pp->sz[chunk]==0) {
			ASSERT((chunk!=0)&&(chunk!=2)&&(chunk!=4));
			free(pp->poly[chunk]);
			pp->poly[chunk]=NULL;
		}
		return;
	}

	// POLYOBJ case
	o=&(pp->obj[chunk]);
	ASSERT(no<o->numpoly[obj]);
	if (o->numpoly[obj]==1) {
		DelObject(blk,isxobj,chunk,obj);
		return;
	}
	stopat=0; // == shiftby
	for (i=0;i<4;i++) {
		vno=o->poly[obj][no].vertex[i];
		if (vno<0) continue;
		p=o->poly[obj]; used=FALSE;
		for (j=0;j<o->numpoly[obj];j++,p++) if (j!=no)
			if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
				(p->vertex[2]==vno)||(p->vertex[3]==vno))
				used=TRUE; // objects are disjoint by assumption
		if (used) continue;
		p=o->poly[obj]+no;
		for (k=0;k<4;k++) if (p->vertex[k]==vno) p->vertex[k]=-1;
		for (l=0;l<4;l++) for (m=0;m<pp->obj[l].nobj;m++) {
			p=pp->obj[l].poly[m];
			for (j=0;j<pp->obj[l].numpoly[m];j++,p++) for (k=0;k<4;k++) {
				ASSERT(p->vertex[k]!=vno);
				if (p->vertex[k]>vno) p->vertex[k]--;
			}
		}
		stopat++; t->nObjectVert--; 
		t->nLoResVert--; t->nMedResVert--; t->nHiResVert--;
		t->nVertices--; t->nVerticesDup--;
		memmove(t->vert+vno,t->vert+vno+1,12*(t->nVertices-vno));
		memmove(t->unknVertices+vno,t->unknVertices+vno+1,4*(t->nVertices-vno));
	}
	for (i=0;i<=6;i++) for (j=0;j<pp->sz[i];j++)
		for (k=0;k<4;k++) pp->poly[i][j].vertex[k]-=stopat;
	o->numpoly[obj]--;
	o->n1--;
	memmove(o->poly[obj]+no,o->poly[obj]+no+1,(o->numpoly[obj]-no)*sizeof(struct POLYGONDATA));
}

void CT3EDDoc::SetCollisionHandling(struct FLOATPT *pt)
{
	int i,j,k;
	struct FLOATPT *v;
	LPPOLYGONDATA p;
	struct POLYVROADDATA *data;

	for (i=0;i<nBlocks;i++) {
		if (!CanContainPoint(trk+i,pt,0.0)) continue;
		v=trk[i].vert+trk[i].nObjectVert;
		for (j=trk[i].nObjectVert;j<trk[i].nHiResVert;j++,v++)
			if ((fabs(v->x-pt->x)<1E-3)&&(fabs(v->z-pt->z)<1E-3)&&(fabs(v->y-pt->y)<1E-3))
			{
				PrepareModifyTrk(i);
				p=poly[i].poly[4];
				data=trk[i].polyData;
				for (k=0;k<trk[i].nPolygons;k++,p++,data++)
					if ((data->flags&0x0f)%14!=0)
						if ((j==p->vertex[0])||(j==p->vertex[1])||
							(j==p->vertex[2])||(j==p->vertex[3]))
								data->flags|=0x80; // collision detect
			}
	}
}

BOOL CT3EDDoc::DoesPointExist(struct FLOATPT *pt)
{
	int i,j,k,l,n;
	struct FLOATPT *v;
	struct XOBJDATA *x;

	for (i=0;i<nBlocks;i++) {
		if (!CanContainPoint(trk+i,pt,0.0)) continue;
		v=trk[i].vert;
		n=trk[i].nVertices;
		for (j=0;j<n;j++,v++)
			if ((fabs(v->x-pt->x)<1E-3)&&(fabs(v->z-pt->z)<1E-3)&&
				(fabs(v->y-pt->y)<1E-3)) return TRUE;
		for (j=4*i;j<4*i+4;j++) {
			x=xobj[j].obj;
			for (k=0;k<xobj[j].nobj;k++,x++) {
				v=x->vert;
				for (l=0;l<x->nVertices;l++,v++)
					if ((fabs(v->x+x->ptRef.x-pt->x)<1E-3)&&
						(fabs(v->z+x->ptRef.z-pt->z)<1E-3)&&
						(fabs(v->y+x->ptRef.y-pt->y)<1E-3))
						return TRUE;
			}
		}
	}
	return FALSE;
}

int CT3EDDoc::DuplPolygon(int blk,int isxobj,int chunk,int obj,int no)
{
	struct XOBJDATA *x;
	int i,j,k,l;
	short vno,vno2;
	LPPOLYGONDATA p;
	struct POLYGONBLOCK *pp;
	struct OBJPOLYBLOCK *o;
	struct TRKBLOCK *t;
	struct FLOATPT backup;

	// XOBJ case
	if (isxobj) {
		PrepareModifyXobj(4*blk+chunk);
		x=&(xobj[4*blk+chunk].obj[obj]);
		ASSERT(no<x->nPolygons);
		x->vert=(struct FLOATPT *)realloc(x->vert,12*(x->nVertices+4));
		x->unknVertices=(long *)realloc(x->unknVertices,4*(x->nVertices+4));
		x->polyData=(struct POLYGONDATA *)realloc(x->polyData,14*(x->nPolygons+1));
		p=x->polyData+x->nPolygons;
		memcpy(p,x->polyData+no,14);
		x->nPolygons++;
		for (i=0;i<4;i++) {
			vno=p->vertex[i];
			memcpy(&backup,x->vert+vno,12);
			backup.x+=0.5;
			while (DoesPointExist(&backup)) backup.x+=(float)2E-3;
			p->vertex[i]=(short)x->nVertices;
			memcpy(x->vert+x->nVertices,&backup,12);
			x->unknVertices[x->nVertices]=x->unknVertices[vno];
			x->nVertices++;
		}
		return x->nPolygons-1;
	}

	pp=&(poly[blk]);
	t=&(trk[blk]);
	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	// TRACK POLYGON case
	if (obj==-1) {
		ASSERT(no<pp->sz[chunk]);
		vno2=(short)t->nVertices;
		t->vert=(struct FLOATPT *)realloc(t->vert,12*(vno2+4));
		t->unknVertices=(long *)realloc(t->unknVertices,4*(vno2+4));
		if (chunk<6) { // create new vertices at nLoResVert
			vno2=(short)t->nLoResVert;
			memmove(t->vert+vno2+4,t->vert+vno2,12*(t->nVertices-vno2));
			memmove(t->unknVertices+vno2+4,t->unknVertices+vno2,4*(t->nVertices-vno2));
			for (l=0;l<=6;l++) { // l=2 would be enough
				p=pp->poly[l];
				for (j=0;j<pp->sz[l];j++,p++) 
					for (k=0;k<4;k++)
						if (p->vertex[k]>=vno2) p->vertex[k]+=4;
			}
			t->nLoResVert+=4;
			t->nMedResVert+=4;
			t->nHiResVert+=4;
		}
		t->nVertices+=4; t->nVerticesDup+=4;
		pp->poly[chunk]=(struct POLYGONDATA *)realloc(pp->poly[chunk],14*(pp->sz[chunk]+1));
		p=pp->poly[chunk]+no+1;
		memmove(p,pp->poly[chunk]+no,14*(pp->sz[chunk]-no));
		pp->sz[chunk]++; pp->szdup[chunk]++;
		for (i=0;i<4;i++) {
			vno=p->vertex[i];
			memcpy(&backup,t->vert+vno,12);
			backup.x+=0.5;
			while (DoesPointExist(&backup)) backup.x+=(float)2E-3;
			p->vertex[i]=vno2;
			memcpy(t->vert+vno2,&backup,12);
			t->unknVertices[vno2]=t->unknVertices[vno];
			vno2++;
		}
		if ((chunk>=2)&&(chunk<6)) { // multiresolution
			pp->poly[chunk-2]=(struct POLYGONDATA *)realloc(pp->poly[chunk-2],14*(pp->sz[chunk-2]+1));
			memcpy(pp->poly[chunk-2]+pp->sz[chunk-2],p,14);
			pp->sz[chunk-2]++; pp->szdup[chunk-2]++;
		}
		if ((chunk>=4)&&(chunk<6)) { // multiresolution
			pp->poly[chunk-4]=(struct POLYGONDATA *)realloc(pp->poly[chunk-4],14*(pp->sz[chunk-4]+1));
			memcpy(pp->poly[chunk-4]+pp->sz[chunk-4],p,14);
			pp->sz[chunk-4]++; pp->szdup[chunk-4]++;
		}
		if (chunk==4) { // update TRKBLOCK too
			t->nPolygons++;
			t->polyData=(struct POLYVROADDATA *)realloc(t->polyData,sizeof(struct POLYVROADDATA)*t->nPolygons);
			memmove(t->polyData+no+1,t->polyData+no,sizeof(struct POLYVROADDATA)*(t->nPolygons-1-no));
			for (i=0;i<t->nPositions;i++)
				if (t->posData[i].polygon>no) t->posData[i].polygon++;
			for (i=0;i<t->nPositions-1;i++)
				t->posData[i].nPolygons=t->posData[i+1].polygon-t->posData[i].polygon;
			t->posData[t->nPositions-1].nPolygons=t->nPolygons-t->posData[t->nPositions-1].polygon;
		}
		return (no+1);
	}

	// POLYOBJ case
	o=&(pp->obj[chunk]);
	ASSERT(no<o->numpoly[obj]);
	vno2=(short)t->nVertices;
	t->vert=(struct FLOATPT *)realloc(t->vert,12*(vno2+4));
	t->unknVertices=(long *)realloc(t->unknVertices,4*(vno2+4));
	vno2=(short)t->nObjectVert;
	memmove(t->vert+vno2+4,t->vert+vno2,12*(t->nVertices-vno2));
	memmove(t->unknVertices+vno2+4,t->unknVertices+vno2,4*(t->nVertices-vno2));
	for (l=0;l<=6;l++) {
		p=pp->poly[l];
		for (j=0;j<pp->sz[l];j++,p++) 
			for (k=0;k<4;k++)
				p->vertex[k]+=4;
	}
	t->nObjectVert+=4;
	t->nLoResVert+=4; t->nMedResVert+=4; t->nHiResVert+=4;
	t->nVertices+=4; t->nVerticesDup+=4;
	o->poly[obj]=(struct POLYGONDATA *)realloc(o->poly[obj],14*(o->numpoly[obj]+1));
	p=o->poly[obj]+o->numpoly[obj];
	memcpy(p,o->poly[obj]+no,14);
	o->numpoly[obj]++; 
	o->n1++;
	for (i=0;i<4;i++) {
		vno=p->vertex[i];
		memcpy(&backup,t->vert+vno,12);
		backup.x+=0.5;
		while (DoesPointExist(&backup)) backup.x+=(float)2E-3;
		p->vertex[i]=vno2;
		memcpy(t->vert+vno2,&backup,12);
		t->unknVertices[vno2]=t->unknVertices[vno];
		vno2++;
	}
	return o->numpoly[obj]-1;
}

void CT3EDDoc::MergePoint(struct FLOATPT *pt1,struct FLOATPT *pt2)
{
	struct FLOATPT src,tgt,*v;
	LPPOLYGONDATA p,pp;
	int i,j,k,l,m,jj,kk,ll,mm;
	struct TRKBLOCK *t;
	struct OBJPOLYBLOCK *o;
	struct XOBJDATA *x;
	short vno,vold;
	BOOL isModified,doit;

	memcpy(&src,pt1,12);
	memcpy(&tgt,pt2,12);
	for (i=0,t=trk;i<nBlocks;i++,t++) {
		if (!CanContainPoint(t,&src,0.0)) continue;
		isModified=FALSE;
		// track vertices
		v=t->vert+t->nObjectVert;
		vno=-1;
		for (j=t->nObjectVert;j<t->nVertices;) {
			if (j==t->nHiResVert) vno=-1; // restart for road lanes
			doit=((fabs(v->x-src.x)<1E-2)&&(fabs(v->z-src.z)<1E-2)&&
				  (fabs(v->y-src.y)<1E-2));
			if ((!doit)&&((fabs(v->x-tgt.x)>1E-2)||
				(fabs(v->z-tgt.z)>1E-2)||(fabs(v->y-tgt.y)>1E-2)))
					{ j++; v++; continue; }
			PrepareModifyTrk(i);
			isModified=TRUE;
			v->x=tgt.x; v->z=tgt.z; v->y=tgt.y;
			p=poly[i].poly[4];  // first recalc vroad
			for (k=0;k<t->nPolygons;k++,p++)
				if ((j==p->vertex[0])||(j==p->vertex[1])||
					(j==p->vertex[2])||(j==p->vertex[3]))
					RecalcPolyVroad(i,k);
			if (vno==-1) {
				vno=(short)j;
				j++; v++;
			} else {
				PrepareModifyPoly(i);
				for (l=0;l<=6;l++) {
					p=poly[i].poly[l];
					for (k=0;k<poly[i].sz[l];k++,p++)
						for (m=0;m<4;m++)
							if (p->vertex[m]==j) p->vertex[m]=vno;
							else if (p->vertex[m]>j) p->vertex[m]--;
				}
				memmove(t->vert+j,t->vert+j+1,12*(t->nVertices-j-1));
				memmove(t->unknVertices+j,t->unknVertices+j+1,4*(t->nVertices-j-1));
				t->nVertices--; t->nVerticesDup--;
				if (j<t->nLoResVert) t->nLoResVert--;
				if (j<t->nMedResVert) t->nMedResVert--;
				if (j<t->nHiResVert) t->nHiResVert--;
				// don't increase j & v
			}
		}
		// polygon object vertices
		o=poly[i].obj;
		for (j=0;j<4;j++,o++) for (k=0;k<o->nobj;k++) {
			vno=-1;
			p=o->poly[k];
			for (l=0;l<o->numpoly[k];l++,p++) for (m=0;m<4;m++) {
				vold=p->vertex[m]; v=t->vert+vold;
				if (vold==vno) continue; // already done !
				doit=((fabs(v->x-src.x)<1E-2)&&(fabs(v->z-src.z)<1E-2)&&
					  (fabs(v->y-src.y)<1E-2));
				if ((!doit)&&((fabs(v->x-tgt.x)>1E-2)||
					(fabs(v->z-tgt.z)>1E-2)||(fabs(v->y-tgt.y)>1E-2)))
						continue;
				PrepareModifyTrk(i);
				isModified=TRUE;
				v->x=tgt.x; v->z=tgt.z; v->y=tgt.y;
				if (vno==-1) { vno=vold; continue; }
				PrepareModifyPoly(i);
				for (ll=0;ll<=6;ll++) {
					pp=poly[i].poly[ll];
					for (kk=0;kk<poly[i].sz[ll];kk++,pp++)
						for (mm=0;mm<4;mm++)
							pp->vertex[mm]--;
				}
				for (ll=0;ll<4;ll++) 
					for (jj=0;jj<poly[i].obj[ll].nobj;jj++) {
						pp=poly[i].obj[ll].poly[jj];
						for (kk=0;kk<poly[i].obj[ll].numpoly[jj];kk++,pp++)
							for (mm=0;mm<4;mm++) {
								if (pp->vertex[mm]==vold) pp->vertex[mm]=vno;
								if (pp->vertex[mm]>vold) pp->vertex[mm]--;
							}
					}
				memmove(t->vert+vold,t->vert+vold+1,12*(t->nVertices-vold-1));
				memmove(t->unknVertices+vold,t->unknVertices+vold+1,4*(t->nVertices-vold-1));
				t->nVertices--; t->nVerticesDup--;
				t->nLoResVert--; t->nMedResVert--; t->nHiResVert--;
				t->nObjectVert--;
			}
		}
		// xobj vertices
		for (jj=4*i;jj<4*i+4;jj++) {
			x=xobj[jj].obj;
			for (kk=0;kk<xobj[jj].nobj;kk++,x++) {
				v=x->vert;
				vno=-1;
				for (j=0;j<x->nVertices;) {
					doit=((fabs(v->x+x->ptRef.x-src.x)<1E-2)&&
						  (fabs(v->z+x->ptRef.z-src.z)<1E-2)&&
						  (fabs(v->y+x->ptRef.y-src.y)<1E-2));
					if ((!doit)&&((fabs(v->x+x->ptRef.x-tgt.x)>1E-2)||
						(fabs(v->z+x->ptRef.z-tgt.z)>1E-2)||
						(fabs(v->y+x->ptRef.y-tgt.y)>1E-2)))
						{ j++; v++; continue; }
					PrepareModifyXobj(jj);
					isModified=TRUE;
					v->x=tgt.x-x->ptRef.x; 
					v->z=tgt.z-x->ptRef.z; 
					v->y=tgt.y-x->ptRef.y;
					if (vno==-1) {
						vno=(short)j;
						j++; v++;
					} else {
						p=x->polyData;
						for (k=0;k<x->nPolygons;k++,p++)
							for (m=0;m<4;m++)
								if (p->vertex[m]==j) p->vertex[m]=vno;
								else if (p->vertex[m]>j) p->vertex[m]--;
						memmove(x->vert+j,x->vert+j+1,12*(x->nVertices-j-1));
						memmove(x->unknVertices+j,x->unknVertices+j+1,4*(x->nVertices-j-1));
						x->nVertices--;
						// don't increase j & v
					}
				}
			}
		}
		if (isModified) RecalcBoundingBox(i);
	}
}

void CT3EDDoc::SplitPoint(struct FLOATPT *refpt)
{
	struct FLOATPT pt,diag,*v;
	float diaglen;
	int i,j,k,l,m,n,vno2;
	int ii,jj,k0,l0,m0,shiftby;
	struct TRKBLOCK *t;
	LPPOLYGONDATA p;
	struct OBJPOLYBLOCK *o;
	struct XOBJDATA *x;
	BOOL isModified,flag;

	memcpy(&pt,refpt,12);
	for (i=0,t=trk;i<nBlocks;i++,t++) {
		if (!CanContainPoint(t,&pt,0.0)) continue;
		isModified=FALSE;
		// track vertices
		for (j=t->nObjectVert;j<t->nVertices;j++) {
			v=t->vert+j;
			if ((fabs(v->x-pt.x)>1E-3)||(fabs(v->y-pt.y)>1E-3)||
				(fabs(v->z-pt.z)>1E-3)) continue;
			PrepareModifyPoly(i);
			PrepareModifyTrk(i);
			isModified=TRUE;
			n=0;
			for (k=0;k<=6;k++) {
				p=poly[i].poly[k];
				for (l=0;l<poly[i].sz[k];l++,p++) for (m=0;m<4;m++)
					if (p->vertex[m]==j) 
						{ p->vertex[m]=-1; k0=k; l0=l; m0=m; n++; }
			}
			if (n==0) continue; // unused vertex !
			p=poly[i].poly[k0];
			p[l0].vertex[m0]=j; n--; // re-use j
			ii=poly[i].poly[k0][l0].vertex[m0^2];
			shiftby=k0;
			// find in lower res
			if ((k0<=5)&&(k0>=2)) {
				p=poly[i].poly[k0-2];
				for (l=0;l<poly[i].sz[k0-2];l++,p++)
					if (p->vertex[m0]==-1) 
						{ p->vertex[m0]=j; n--; shiftby=k0-2; }
			}
			if ((k0<=5)&&(k0>=4)) {
				p=poly[i].poly[k0-4];
				for (l=0;l<poly[i].sz[k0-4];l++,p++)
					if (p->vertex[m0]==-1) 
						{ p->vertex[m0]=j; n--; shiftby=k0-4; }
			}
			// neighbor too ? => left neighbor (k0,l0,m0 is last)
			if ((k0==4)&&(l0>0)&&(m0%3==0)) {
				p=poly[i].poly[4]+l0-1;
				if ((p->vertex[m0^1]==-1)&&(p->vertex[m0^2]==p[1].vertex[m0^3])) {
					p->vertex[m0^1]=j; n--;
					ii=poly[i].poly[k0][l0].vertex[m0^3];
					p=poly[i].poly[2];
					for (l=0;l<poly[i].sz[2];l++,p++)
						if (p->vertex[m0^1]==-1) 
							{ p->vertex[m0^1]=j; n--; if (shiftby>2) shiftby=2; }
					p=poly[i].poly[0];
					for (l=0;l<poly[i].sz[0];l++,p++)
						if (p->vertex[m0^1]==-1) 
							{ p->vertex[m0^1]=j; n--; shiftby=0; }
				}
			}
					
			diag.x=t->vert[ii].x-pt.x;
			diag.z=t->vert[ii].z-pt.z;
			diag.y=t->vert[ii].y-pt.y;
			diaglen=2*(float)sqrt(diag.x*diag.x+diag.z*diag.z+diag.y*diag.y+0.01);
			diag.x=v->x+diag.x/diaglen;
			diag.z=v->z+diag.z/diaglen;
			diag.y=v->y+diag.y/diaglen;
			while (DoesPointExist(&diag)) diag.x+=(float)0.1;
			memcpy(v,&diag,12);
			if (n==0) continue;
			// create a new vertex
			vno2=(t->nVertices++); t->nVerticesDup++;
			if (shiftby<6) vno2=(t->nHiResVert++);
			if (shiftby<4) vno2=(t->nMedResVert++);
			if (shiftby<2) vno2=(t->nLoResVert++);
			ASSERT(vno2>j);
			t->vert=(struct FLOATPT *)realloc(t->vert,12*t->nVertices);
			t->unknVertices=(long *)realloc(t->unknVertices,4*t->nVertices);
			memmove(t->vert+vno2+1,t->vert+vno2,12*(t->nVertices-vno2-1));
			memmove(t->unknVertices+vno2+1,t->unknVertices+vno2,4*(t->nVertices-vno2-1));
			memcpy(t->vert+vno2,&pt,12);
			t->unknVertices[vno2]=t->unknVertices[j];
			for (k=0;k<=6;k++) {
				p=poly[i].poly[k];
				for (l=0;l<poly[i].sz[k];l++,p++) {
					flag=FALSE;
					for (m=0;m<4;m++)
						if (p->vertex[m]==-1) p->vertex[m]=vno2;
						else if (p->vertex[m]==j) flag=TRUE;
						else if (p->vertex[m]>=vno2) p->vertex[m]++;
					if ((k==4)&&flag) RecalcPolyVroad(i,l);
				}
			}
		}
		// polyobj vertices
		o=poly[i].obj;
		shiftby=0;
		for (j=0;j<4;j++,o++) for (k=0;k<o->nobj;k++) {
			p=o->poly[k];
			for (l=0;l<o->numpoly[k];l++) for (m=0;m<4;m++) {
				vno2=p[l].vertex[m]; v=t->vert+vno2;
				if ((fabs(v->x-pt.x)>1E-3)||(fabs(v->y-pt.y)>1E-3)||
					(fabs(v->z-pt.z)>1E-3)) continue;
				PrepareModifyPoly(i);
				PrepareModifyTrk(i);
				isModified=TRUE;
				n=0;
				for (ii=0;ii<o->numpoly[k];ii++) for (jj=0;jj<4;jj++)
					if (p[ii].vertex[jj]==vno2) {
						if (n>0) p[ii].vertex[jj]=(short)t->nObjectVert;
						n++;
					}
				ii=p[l].vertex[m^2];
				diag.x=t->vert[ii].x-pt.x;
				diag.z=t->vert[ii].z-pt.z;
				diag.y=t->vert[ii].y-pt.y;
				diaglen=2*(float)sqrt(diag.x*diag.x+diag.z*diag.z+diag.y*diag.y+0.01);
				diag.x=v->x+diag.x/diaglen;
				diag.z=v->z+diag.z/diaglen;
				diag.y=v->y+diag.y/diaglen;
				while (DoesPointExist(&diag)) diag.x+=(float)0.1;
				memcpy(v,&diag,12);
				if (n==1) continue;
				t->nVertices++; t->nVerticesDup++;
			    t->nHiResVert++; t->nMedResVert++; t->nLoResVert++;
				t->nObjectVert++;
				t->vert=(struct FLOATPT *)realloc(t->vert,12*t->nVertices);
				t->unknVertices=(long *)realloc(t->unknVertices,4*t->nVertices);
				memmove(t->vert+t->nObjectVert,t->vert+t->nObjectVert-1,12*(t->nVertices-t->nObjectVert));
				memmove(t->unknVertices+t->nObjectVert,t->unknVertices+t->nObjectVert-1,4*(t->nVertices-t->nObjectVert));
				memcpy(t->vert+t->nObjectVert-1,&pt,12);
				t->unknVertices[t->nObjectVert-1]=t->unknVertices[vno2];
				shiftby++;
			}
		}
		for (k=0;k<=6;k++) {
			p=poly[i].poly[k];
			for (l=0;l<poly[i].sz[k];l++,p++)
				for (m=0;m<4;m++) p->vertex[m]+=shiftby;
		}
		// xobj vertices
		for (j=4*i;j<4*i+4;j++) for (k=0,x=xobj[j].obj;k<xobj[j].nobj;k++,x++) {
			p=x->polyData;
			for (l=0;l<x->nPolygons;l++) for (m=0;m<4;m++) {
				vno2=p[l].vertex[m]; v=x->vert+vno2;
				if ((fabs(v->x+x->ptRef.x-pt.x)>1E-3)||
					(fabs(v->y+x->ptRef.y-pt.y)>1E-3)||
					(fabs(v->z+x->ptRef.z-pt.z)>1E-3)) continue;
				PrepareModifyXobj(j);
				isModified=TRUE;
				n=0;
				for (ii=0;ii<x->nPolygons;ii++) for (jj=0;jj<4;jj++)
					if (p[ii].vertex[jj]==vno2) {
						if (n>0) p[ii].vertex[jj]=(short)x->nVertices;
						n++;
					}
				ii=p[l].vertex[m^2];
				diag.x=x->vert[ii].x-v->x;
				diag.z=x->vert[ii].z-v->z;
				diag.y=x->vert[ii].y-v->y;
				diaglen=2*(float)sqrt(diag.x*diag.x+diag.z*diag.z+diag.y*diag.y+0.01);
				diag.x=x->ptRef.x+v->x+diag.x/diaglen;
				diag.z=x->ptRef.z+v->z+diag.z/diaglen;
				diag.y=x->ptRef.y+v->y+diag.y/diaglen;
				while (DoesPointExist(&diag)) diag.x+=(float)0.1;
				v->x=diag.x-x->ptRef.x;
				v->z=diag.z-x->ptRef.z;
				v->y=diag.y-x->ptRef.y;
				if (n==1) continue;
				x->nVertices++;
				x->vert=(struct FLOATPT *)realloc(x->vert,12*x->nVertices);
				x->unknVertices=(long *)realloc(x->unknVertices,4*x->nVertices);
				v=x->vert+(x->nVertices-1);
				v->x=pt.x-x->ptRef.x;
				v->z=pt.z-x->ptRef.z;
				v->y=pt.y-x->ptRef.y;
				x->unknVertices[x->nVertices-1]=x->unknVertices[vno2];
			}
		}

		if (isModified) RecalcBoundingBox(i);
	}
}

void CT3EDDoc::AdjustRoadWidth()
{
	int i,j,k,l,np;
	float mind,maxd,d;
	struct TRKBLOCK *t=trk;
	LPPOLYGONDATA p;
	struct COLVROAD *v;
	struct FLOATPT *pt;

	if (undoCol[undoLevel-1]==NULL) {
		undoCol[undoLevel-1]=(struct COLVROAD *)malloc(36*col.vroadHead.nrec);
		memcpy(undoCol[undoLevel-1],col.vroad,36*col.vroadHead.nrec);
	}
	for (i=0;i<nBlocks;i++,t++)
		for (j=t->nStartPos;j<t->nStartPos+t->nPositions;j++) {
			p=poly[i].poly[4];
			np=poly[i].sz[4];
			v=col.vroad+j;
			mind=0; maxd=0;
			for (k=0;k<np;k++,p++) 
				if ((t->polyData[k].flags&0x0f)%14!=0) // passable
					for (l=0;l<4;l++) {
						pt=t->vert+p->vertex[l];
						d=(pt->x*65536-v->refPt.x)*v->right.x+
						  (pt->y*65536-v->refPt.y)*v->right.y+
						  (pt->z*65536-v->refPt.z)*v->right.z;
						d=d/120; // allow safety margin
						if (d<mind) mind=d;
						if (d>maxd) maxd=d;
					}
			v->leftWall=-(long)mind;
			v->rightWall=(long)maxd;
		}
}

void CT3EDDoc::HS_RecalcMinMaxXY()
{
	int i,j,k;
	struct TRKBLOCK *t=trk;
	float x,y;
	unsigned char v,w;
	LPPOLYGONDATA p;

	for (i=0;i<nBlocks;i++,t++) {
		t->hs_ptMin.z=t->hs_ptMax.z=t->ptCentre.z;
		t->hs_ptMin.x=t->hs_ptMax.x=t->ptCentre.x;
		t->hs_ptMin.y=t->hs_ptMax.y=t->ptCentre.y;
		p=poly[i].poly[4];
		for (j=0;j<t->nPolygons;j++,p++)
			if ((t->polyData[j].flags&15)!=14)
				for (k=0;k<4;k++) {
					x=t->vert[p->vertex[k]].x;
					y=t->vert[p->vertex[k]].y;
					if (t->hs_ptMin.x>x) t->hs_ptMin.x=x;
					if (t->hs_ptMax.x<x) t->hs_ptMax.x=x;
					if (t->hs_ptMin.y>y) t->hs_ptMin.y=y;
					if (t->hs_ptMax.y<y) t->hs_ptMax.y=y;
				}
		t->hs_ptMin.x-=(float)0.1; t->hs_ptMin.y-=(float)0.1;
		t->hs_ptMax.x+=(float)0.1; t->hs_ptMax.y+=(float)0.1;
		p=poly[i].poly[4];
		for (j=0;j<t->nPolygons;j++,p++)
			if ((t->polyData[j].flags&15)!=14) {
				t->polyData[j].hs_minmax[0]=255;
				t->polyData[j].hs_minmax[1]=0;
				t->polyData[j].hs_minmax[2]=255;
				t->polyData[j].hs_minmax[3]=0;
				for (k=0;k<4;k++) {
					v=(unsigned char)(255*(t->vert[p->vertex[k]].x-t->hs_ptMin.x)/(t->hs_ptMax.x-t->hs_ptMin.x));
					w=(unsigned char)(255*(t->vert[p->vertex[k]].y-t->hs_ptMin.y)/(t->hs_ptMax.y-t->hs_ptMin.y));
					// min y
					if (w<t->polyData[j].hs_minmax[0]) t->polyData[j].hs_minmax[0]=w;
					// max y
					if (w>t->polyData[j].hs_minmax[1]) t->polyData[j].hs_minmax[1]=w;
					// min x
					if (v<t->polyData[j].hs_minmax[2]) t->polyData[j].hs_minmax[2]=v;
					// max x
					if (v>t->polyData[j].hs_minmax[3]) t->polyData[j].hs_minmax[3]=v;
				}
			}
	}
}

void CT3EDDoc::SetAllTextures(int texture,BOOL drivable,short flags)
{
	int i,j,k,l,np;
	struct TRKBLOCK *t=trk;
	LPPOLYGONDATA p;
	struct COLVROAD *v;
	struct FLOATPT pt;
	FLOAT mind,dist,ll;
	BOOL isin;

	for (i=0;i<nBlocks;i++,t++) {
		PrepareModifyPoly(i);
		for (j=0;j<=4;j+=2) {
			np=poly[i].sz[j];
			p=poly[i].poly[j];
			for (k=0;k<np;k++,p++) {
				// is it passable ?
				if (j==4) isin=((t->polyData[k].flags&0x0f)%14!=0);
				else {
					mind=(float)1E20;
					pt.x=65536*(t->vert[p->vertex[0]].x+t->vert[p->vertex[2]].x)/2;
					pt.z=65536*(t->vert[p->vertex[0]].z+t->vert[p->vertex[2]].z)/2;
					pt.y=65536*(t->vert[p->vertex[0]].y+t->vert[p->vertex[2]].y)/2;
					for (l=t->nStartPos;l<t->nStartPos+t->nPositions;l++) {
						v=col.vroad+l;
						dist=(pt.x-v->refPt.x)*(pt.x-v->refPt.x)
							+(pt.y-v->refPt.y)*(pt.y-v->refPt.y)
							+(pt.z-v->refPt.z)*(pt.z-v->refPt.z);
						if (dist<mind) { 
							mind=dist;
							ll=((pt.x-v->refPt.x)*v->right.x+
								(pt.y-v->refPt.y)*v->right.y+
								(pt.z-v->refPt.z)*v->right.z)/128;
							isin=((ll>-v->leftWall)&&(ll<v->rightWall));
						}
					}
				}
				if (isin==drivable) {
					p->texture=texture;
					if (bHSMode) p->unknown1=flags;
				}
			}
		}
	}
}

void CT3EDDoc::DelAllObjects(int blk,int isxobj)
{
	struct XOBJBLOCK *xb;
	int i,j,k,n;
	struct OBJPOLYBLOCK *o;
	struct TRKBLOCK *t;
	LPPOLYGONDATA p;

	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	if (isxobj) {
		for (i=0;i<4;i++) {
			PrepareModifyXobj(4*blk+i);
			xb=&(xobj[4*blk+i]);
			for (j=0;j<xb->nobj;j++) {
				if (xb->obj[j].crosstype==3) 
					dofree(xb->obj[j].animData);
				dofree(xb->obj[j].vert);
				dofree(xb->obj[j].unknVertices);
				dofree(xb->obj[j].polyData);
			}
			xb->nobj=0;
			o=&(poly[blk].obj[i]);
			if (o->n1>0) {
				o->n2=o->nobj;
				for (j=0;j<o->n2;j++) o->types[j]=1;
			}
		}
		trk[blk].nXobj=0;
		// update global xobj sequence numbers
		n=0;
		for (i=0;i<nBlocks;i++)
			for (j=0;j<trk[i].nXobj;j++)
				trk[i].xobj[j].globalno=n++;
	} else {
		t=&(trk[blk]);
		for (i=0;i<7;i++)
			for (j=0,p=poly[blk].poly[i];j<poly[blk].sz[i];j++,p++)
				for (k=0;k<4;k++) 
					p->vertex[k]-=(short)t->nObjectVert;
		t->nVertices-=t->nObjectVert; t->nVerticesDup-=t->nObjectVert;
		t->nLoResVert-=t->nObjectVert; t->nHiResVert-=t->nObjectVert; 
		t->nMedResVert-=t->nObjectVert;
		memmove(t->vert,t->vert+t->nObjectVert,12*t->nVertices);
		memmove(t->unknVertices,t->unknVertices+t->nObjectVert,4*t->nVertices);
		t->nObjectVert=0;
		dofree(t->lightsrc); t->lightsrc=NULL;
		t->nLightsrc=0;
		for (i=0,o=poly[blk].obj;i<4;i++,o++) {
			for (j=0;j<o->nobj;j++) dofree(o->poly[j]);
			o->n1=0; // block is marked unused ; no memory leak here
			o->nobj=0;
		}
	}
	RecalcBoundingBox(blk);
}

void CT3EDDoc::DelLanePolygons(int blk)
{
	int i,j,k,l,chunk,no;
	short vno;
	LPPOLYGONDATA p;
	struct POLYGONBLOCK *pp;
	struct TRKBLOCK *t;
	BOOL used;

	pp=&(poly[blk]);
	t=&(trk[blk]);
	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	
	for (chunk=0;chunk<=6;chunk++) {
		if ((chunk==0)||(chunk==2)||(chunk==4)) continue;
		for (no=0;no<pp->sz[chunk];no++) {
			for (i=0;i<4;i++) {
				vno=pp->poly[chunk][no].vertex[i];
				if (vno<0) continue;
				// don't delete vertex if referenced elsewhere
				used=FALSE;
				for (k=0;k<=4;k+=2) {
					p=pp->poly[k];
					for (j=0;j<pp->sz[k];j++,p++) if ((k!=chunk)||(j!=no))
						if ((p->vertex[0]==vno)||(p->vertex[1]==vno)||
							(p->vertex[2]==vno)||(p->vertex[3]==vno))
							used=TRUE;
				}
				if (used) continue;
				for (l=0;l<=6;l++) {
					p=pp->poly[l];
					for (j=0;j<pp->sz[l];j++,p++) for (k=0;k<4;k++) {
						if (p->vertex[k]==vno) p->vertex[k]=-1;
						else if (p->vertex[k]>vno) p->vertex[k]--;
					}
				}
				t->nVertices--; t->nVerticesDup--;
				if (vno<t->nLoResVert) t->nLoResVert--;
				if (vno<t->nMedResVert) t->nMedResVert--;
				if (vno<t->nHiResVert)  t->nHiResVert--;
				memmove(t->vert+vno,t->vert+vno+1,12*(t->nVertices-vno));
				memmove(t->unknVertices+vno,t->unknVertices+vno+1,4*(t->nVertices-vno));
			}
		}
		pp->sz[chunk]=0; pp->szdup[chunk]=0;
		dofree(pp->poly[chunk]);
		pp->poly[chunk]=NULL;
	}
	// soundsrc's come with fences
	dofree(t->soundsrc); t->soundsrc=NULL;
	t->nSoundsrc=0;
}

void CT3EDDoc::ClearSceneryZ()
{
	int i,start,min2,max2,ref,j,n;
	struct FLOATPT *v,tpt,tmppt;
	struct INTPT *p1,*p2;

	n=col.vroadHead.nrec;
	for (i=0;i<nBlocks;i++) {
		PrepareModifyTrk(i);
		v=trk[i].vert+trk[i].nObjectVert;
		start=trk[i].nStartPos+trk[i].nPositions/2;
		min2=(trk[i].nStartPos+n-8)%n;
		max2=(trk[i].nStartPos+trk[i].nPositions+7)%n;
		for (j=trk[i].nObjectVert;j<trk[i].nVertices;j++,v++) {
			if (fabs(v->x)>1E7) continue;
			if (fabs(v->y)>1E7) continue;
			ref=GlobalLocalCoord(*v,tpt,col.vroad,start,min2,max2);
			tpt.z=0;
			LocalGlobalCoord(tpt,tmppt,col.vroad,ref);
			v->z=tmppt.z;
		}
		p1=&(col.vroad[trk[i].nStartPos].refPt);
		p2=&(col.vroad[trk[i].nStartPos+trk[i].nPositions-1].refPt);
		tmppt.x=(float)(p2->x-p1->x);
		tmppt.z=(float)(p2->z-p1->z);
		tmppt.y=(float)(p2->y-p1->y);
		for (j=0;j<trk[i].nPolygons;j++) RecalcPolyVroad(i,j,&tmppt);
	}
}

void CT3EDDoc::DelTrackPolygon(int blk,int no)
{
	LPPOLYGONDATA p;
	struct POLYGONBLOCK *pp;
	struct TRKBLOCK *t;
	short *v;
	BOOL left,right;
	int i,j,k;
	struct FLOATPT a,b;

	pp=&(poly[blk]);
	t=&(trk[blk]);
	p=pp->poly[4]+no-1;
	left=right=FALSE;
	if (no>0) left=(p[0].vertex[1]==p[1].vertex[0])&&(p[0].vertex[2]==p[1].vertex[3]);
	if (no<pp->sz[4]-1) right=(p[1].vertex[1]==p[2].vertex[0])&&(p[1].vertex[2]==p[2].vertex[3]);
	if (!left&&!right) {
		if (AfxMessageBox("You are about to delete an isolated track polygon.\n"
			              "If this is the last polygon of a road node,\n"
						  "the resulting track will not work properly.\n"
						  "Are you sure you want to proceed ?",
			MB_ICONWARNING|MB_OKCANCEL)!=IDOK) return;
	}
	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);
	for (i=0;i<4;i++) SetCollisionHandling(t->vert+p[1].vertex[i]);
	if (bHSMode&&left)
		if ((t->polyData[no-1].flags&0x0f)%14) {
			t->polyData[no-1].hs_orphan[3]=0xFF;
			if (right) if ((t->polyData[no+1].flags&0x0f)%14!=0)
				t->polyData[no-1].hs_orphan[3]=0;
		}
	if (bHSMode&&right)
		if ((t->polyData[no+1].flags&0x0f)%14) {
			t->polyData[no+1].hs_orphan[1]=0xFF;
			if (left) if ((t->polyData[no-1].flags&0x0f)%14!=0)
				t->polyData[no+1].hs_orphan[1]=0;
		}

	if (left&&right) {
		// do some magic to reconnect the side polygons
		for (i=0;i<7;i++) for (j=0,p=pp->poly[i];j<pp->sz[i];j++,p++)
			for (k=0;k<4;k++)
				if (p->vertex[k]>=t->nHiResVert) p->vertex[k]+=2;
		p=pp->poly[4]+no-1;
		t->nVertices+=2; t->nVerticesDup+=2;
		t->nHiResVert+=2;
		t->vert=(struct FLOATPT *)realloc(t->vert,12*t->nVertices);
		t->unknVertices=(long *)realloc(t->unknVertices,4*t->nVertices);
		memmove(t->vert+t->nHiResVert,t->vert+t->nHiResVert-2,12*(t->nVertices-t->nHiResVert));
		memmove(t->unknVertices+t->nHiResVert,t->unknVertices+t->nHiResVert-2,4*(t->nVertices-t->nHiResVert));
		v=p[1].vertex;
		t->unknVertices[t->nHiResVert-2]=t->unknVertices[v[0]];
		t->unknVertices[t->nHiResVert-1]=t->unknVertices[v[2]];
		a.x=(t->vert[v[0]].x+t->vert[v[1]].x)/2;
		a.z=(t->vert[v[0]].z+t->vert[v[1]].z)/2;
		a.y=(t->vert[v[0]].y+t->vert[v[1]].y)/2;
		b.x=(t->vert[v[2]].x+t->vert[v[3]].x)/2;
		b.z=(t->vert[v[2]].z+t->vert[v[3]].z)/2;
		b.y=(t->vert[v[2]].y+t->vert[v[3]].y)/2;
		t->vert[t->nHiResVert-2].x=(19*a.x+b.x)/20;
		t->vert[t->nHiResVert-2].z=(19*a.z+b.z)/20;
		t->vert[t->nHiResVert-2].y=(19*a.y+b.y)/20;
		t->vert[t->nHiResVert-1].x=(19*b.x+a.x)/20;
		t->vert[t->nHiResVert-1].z=(19*b.z+a.z)/20;
		t->vert[t->nHiResVert-1].y=(19*b.y+a.y)/20;
		p[0].vertex[1]=t->nHiResVert-2;
		p[0].vertex[2]=t->nHiResVert-1;
		p[2].vertex[0]=t->nHiResVert-2;
		p[2].vertex[3]=t->nHiResVert-1;
		RecalcPolyVroad(blk,no-1);
		RecalcPolyVroad(blk,no+1);
	}

	DelPolygon(blk,FALSE,4,-1,no); // go through the usual DelPolygon procedure
 }

int CT3EDDoc::DuplTrackPolygon(int blk,int no)
{
	int i,j,k,l;
	LPPOLYGONDATA p;
	struct POLYGONBLOCK *pp;
	struct TRKBLOCK *t;
	struct FLOATPT a,b;
	short *v;

	pp=&(poly[blk]);
	t=&(trk[blk]);
	PrepareModifyTrk(blk);
	PrepareModifyPoly(blk);

	t->vert=(struct FLOATPT *)realloc(t->vert,12*(t->nVertices+2));
	t->unknVertices=(long *)realloc(t->unknVertices,4*(t->nVertices+2));
	// create 2 new vertices at nHiResVert
	memmove(t->vert+t->nHiResVert+2,t->vert+t->nHiResVert,12*(t->nVertices-t->nHiResVert));
	memmove(t->unknVertices+t->nHiResVert+2,t->unknVertices+t->nHiResVert,4*(t->nVertices-t->nHiResVert));
	for (l=0;l<=6;l++) {
		p=pp->poly[l];
		for (j=0;j<pp->sz[l];j++,p++) 
			for (k=0;k<4;k++)
				if (p->vertex[k]>=t->nHiResVert) p->vertex[k]+=2;
	}
	t->nHiResVert+=2;
	t->nVertices+=2; t->nVerticesDup+=2;
	pp->poly[4]=(struct POLYGONDATA *)realloc(pp->poly[4],14*(pp->sz[4]+1));
	p=pp->poly[4]+no;
	memmove(p+1,p,14*(pp->sz[4]-no));
	pp->sz[4]++; pp->szdup[4]++;

	v=p->vertex;
	t->unknVertices[t->nHiResVert-2]=t->unknVertices[v[0]];
	t->unknVertices[t->nHiResVert-1]=t->unknVertices[v[2]];
	a.x=(t->vert[v[0]].x+t->vert[v[1]].x)/2;
	a.z=(t->vert[v[0]].z+t->vert[v[1]].z)/2;
	a.y=(t->vert[v[0]].y+t->vert[v[1]].y)/2;
	b.x=(t->vert[v[2]].x+t->vert[v[3]].x)/2;
	b.z=(t->vert[v[2]].z+t->vert[v[3]].z)/2;
	b.y=(t->vert[v[2]].y+t->vert[v[3]].y)/2;
	t->vert[t->nHiResVert-2].x=(19*a.x+b.x)/20;
	t->vert[t->nHiResVert-2].z=(19*a.z+b.z)/20;
	t->vert[t->nHiResVert-2].y=(19*a.y+b.y)/20;
	t->vert[t->nHiResVert-1].x=(19*b.x+a.x)/20;
	t->vert[t->nHiResVert-1].z=(19*b.z+a.z)/20;
	t->vert[t->nHiResVert-1].y=(19*b.y+a.y)/20;
	p[0].vertex[1]=t->nHiResVert-2;
	p[0].vertex[2]=t->nHiResVert-1;
	p[1].vertex[0]=t->nHiResVert-2;
	p[1].vertex[3]=t->nHiResVert-1;
	
	// update TRKBLOCK too
	t->nPolygons++;
	t->polyData=(struct POLYVROADDATA *)realloc(t->polyData,sizeof(struct POLYVROADDATA)*t->nPolygons);
	memmove(t->polyData+no+1,t->polyData+no,sizeof(struct POLYVROADDATA)*(t->nPolygons-1-no));
	for (i=0;i<t->nPositions;i++)
		if (t->posData[i].polygon>no) t->posData[i].polygon++;
	for (i=0;i<t->nPositions-1;i++)
		t->posData[i].nPolygons=t->posData[i+1].polygon-t->posData[i].polygon;
	t->posData[t->nPositions-1].nPolygons=t->nPolygons-t->posData[t->nPositions-1].polygon;
	RecalcPolyVroad(blk,no);
	RecalcPolyVroad(blk,no+1);
	if (bHSMode&&((t->polyData[no].flags&0x0f)%14!=0)) {
		t->polyData[no].hs_orphan[3]=0;
		t->polyData[no+1].hs_orphan[1]=0;
	}
	return no;
}
