// T3EDView.cpp : implementation of the CT3EDView class
//

#include "stdafx.h"
#include "T3ED.h"
#include <math.h>

#include "T3EDDoc.h"
#include "T3EDView.h"
#include "smooth.h"
#include "NewobjDlg.h"
#include "ClearAll.h"
#include "PolyFlag.h"

#define SCROLLSZ 5000

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CT3EDView

IMPLEMENT_DYNCREATE(CT3EDView, CView)

BEGIN_MESSAGE_MAP(CT3EDView, CView)
	//{{AFX_MSG_MAP(CT3EDView)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_COMMAND(ID_VIEW_FULLRES, OnViewFullres)
	ON_COMMAND(ID_VIEW_HALFRES, OnViewHalfres)
	ON_COMMAND(ID_VIEW_LOWRES, OnViewLowres)
	ON_COMMAND(ID_VIEW_ZOOMIN, OnViewZoomin)
	ON_COMMAND(ID_VIEW_ZOOMOUT, OnViewZoomout)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FULLRES, OnUpdateViewFullres)
	ON_UPDATE_COMMAND_UI(ID_VIEW_HALFRES, OnUpdateViewHalfres)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LOWRES, OnUpdateViewLowres)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMIN, OnUpdateViewZoomin)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMOUT, OnUpdateViewZoomout)
	ON_COMMAND(ID_VIEW_ROTATE, OnViewRotateMode)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ROTATE, OnUpdateViewRotateMode)
	ON_COMMAND(ID_VIEW_HEIGHT, OnViewTranslMode)
	ON_UPDATE_COMMAND_UI(ID_VIEW_HEIGHT, OnUpdateViewTranslMode)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_WM_KEYDOWN()
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWHIDEOBJECTS, OnUpdateViewShowhideobjects)
	ON_COMMAND(ID_VIEW_SHOWHIDEOBJECTS, OnViewShowhideobjects)
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_MODE_BLOCK, OnModeBlock)
	ON_UPDATE_COMMAND_UI(ID_MODE_BLOCK, OnUpdateModeBlock)
	ON_COMMAND(ID_MODE_EXTPOINT, OnModeExtpoint)
	ON_UPDATE_COMMAND_UI(ID_MODE_EXTPOINT, OnUpdateModeExtpoint)
	ON_COMMAND(ID_MODE_POINT, OnModePoint)
	ON_UPDATE_COMMAND_UI(ID_MODE_POINT, OnUpdateModePoint)
	ON_COMMAND(ID_MODE_OBJECT, OnModeObject)
	ON_UPDATE_COMMAND_UI(ID_MODE_OBJECT, OnUpdateModeObject)
	ON_COMMAND(ID_MODE_POLYGON, OnModePolygon)
	ON_UPDATE_COMMAND_UI(ID_MODE_POLYGON, OnUpdateModePolygon)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_COMMAND(ID_VIEW_RECENTER, OnViewRecenter)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RECENTER, OnUpdateViewRecenter)
	ON_COMMAND(ID_VIEW_SHOWLANES, OnViewShowlanes)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWLANES, OnUpdateViewShowlanes)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_MOVEXY, OnUpdateToolsMovexy)
	ON_COMMAND(ID_TOOLS_MOVEXY, OnToolsMovexy)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_MOVEZ, OnUpdateToolsMovez)
	ON_COMMAND(ID_TOOLS_MOVEZ, OnToolsMovez)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_MODE_SMOOTHING, OnUpdateModeSmoothing)
	ON_COMMAND(ID_MODE_SMOOTHING, OnModeSmoothing)
	ON_UPDATE_COMMAND_UI(ID_EDITMODES_EXTRASMOOTHING, OnUpdateEditmodesExtrasmoothing)
	ON_COMMAND(ID_EDITMODES_EXTRASMOOTHING, OnEditmodesExtrasmoothing)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_DELETE, OnUpdateToolsDelete)
	ON_COMMAND(ID_TOOLS_DELETE, OnToolsDelete)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_DUPLICATE, OnUpdateToolsDuplicate)
	ON_COMMAND(ID_TOOLS_DUPLICATE, OnToolsDuplicate)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TEXTURE, OnUpdateToolsTexture)
	ON_COMMAND(ID_TOOLS_TEXTURE, OnToolsTexture)
	ON_COMMAND(ID_TOOLS_POLYFLAG, OnToolsPolyflag)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_POLYFLAG, OnUpdateToolsPolyflag)
	ON_COMMAND(ID_TOOLS_MERGE, OnToolsMerge)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_MERGE, OnUpdateToolsMerge)
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_TOOLS_ADJUSTWIDTH, OnToolsAdjustwidth)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_ADJUSTWIDTH, OnUpdateToolsAdjustwidth)
	ON_COMMAND(ID_TOOLS_CLEARALL, OnToolsClearall)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_CLEARALL, OnUpdateToolsClearall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CT3EDView construction/destruction

CT3EDView::CT3EDView()
{
	bluePen=new CPen(PS_SOLID,1,RGB(0,0,127));
	redPen=new CPen(PS_SOLID,1,RGB(255,0,0));
	greenPen=new CPen(PS_SOLID,1,RGB(0,127,0));
	brownPen=new CPen(PS_SOLID,1,RGB(127,127,0));
}

CT3EDView::~CT3EDView()
{
	delete bluePen;
	delete redPen;
	delete greenPen;
	delete brownPen;
}

BOOL CT3EDView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_HSCROLL|WS_VSCROLL;
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CT3EDView drawing

inline int CT3EDView::FloatX(struct FLOATPT &p)
{ 
	return (int)((p.x*cosPhi-p.y*sinPhi)/scale)+dxoffs; 
}

inline int CT3EDView::FloatY(struct FLOATPT &p)
{ 
	return (int)(-(p.y*cosPhi*cosTheta+p.x*sinPhi*cosTheta+
										p.z*sinTheta)/scale)+dyoffs;
}

inline int CT3EDView::IntX(struct INTPT &p)
{ 
	return (int)((p.x*cosPhi-p.y*sinPhi)/(65536*scale))+dxoffs;
}

inline int CT3EDView::IntY(struct INTPT &p)
{ 
	return (int)(-(p.y*cosPhi*cosTheta+p.x*sinPhi*cosTheta+
						p.z*sinTheta)/(65536*scale))+dyoffs;
}

inline int CT3EDView::FloatFloatX(struct FLOATPT &p,struct FLOATPT &q)
{ 
	return (int)(((p.x+q.x)*cosPhi-(p.y+q.y)*sinPhi)/scale)+dxoffs; 
}

inline int CT3EDView::FloatFloatY(struct FLOATPT &p,struct FLOATPT &q)
{ 
	return (int)(-((p.y+q.y)*cosPhi*cosTheta+(p.x+q.x)*sinPhi*cosTheta+
									(p.z+q.z)*sinTheta)/scale)+dyoffs;
}

BOOL CT3EDView::MeetsClipRect(struct TRKBLOCK *t,LPRECT r)
{
	int x[4],y[4],zsize,i;

	for (i=0;i<=3;i++) { 
		x[i]=FloatX(t->ptBounding[i]);
		y[i]=FloatY(t->ptBounding[i]);
	}
	zsize=(int)(200*sinTheta/scale);
	if ((x[0]<r->left)&&(x[1]<r->left)&&(x[2]<r->left)&&(x[3]<r->left))
		return FALSE;
	if ((x[0]>r->right)&&(x[1]>r->right)&&(x[2]>r->right)&&(x[3]>r->right))
		return FALSE;
	if ((y[0]<r->top-zsize)&&(y[1]<r->top-zsize)&&(y[2]<r->top-zsize)&&(y[3]<r->top-zsize))
		return FALSE;
	if ((y[0]>r->bottom+zsize)&&(y[1]>r->bottom+zsize)&&(y[2]>r->bottom+zsize)&&(y[3]>r->bottom+zsize))
		return FALSE;
	return TRUE;
}

void CT3EDView::ShowSelectionAt(CDC *pDC,int xx,int yy)
{
	CT3EDDoc* pDoc = GetDocument();
	int j,k,l,num;
	int truedx,truedy;
	LPPOLYGONDATA p;
	struct FLOATPT *v;
	struct OBJPOLYBLOCK *o;
	struct XOBJDATA *x;
	CSelData *sel;

	dxoffs=xx-(int)((refnode->x*cosPhi-refnode->y*sinPhi)/scale);
	dyoffs=yy+(int)((refnode->y*cosPhi*cosTheta+
				refnode->x*sinPhi*cosTheta+refnode->z*sinTheta)/scale);
	switch(selMode) {
		case ID_MODE_BLOCK:
			v=pDoc->trk[refblock].vert;
			p=pDoc->poly[refblock].poly[nDetail];
			num=pDoc->poly[refblock].sz[nDetail];
			for (j=0;j<num;j++,p++) {
				pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
				pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
				pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
				pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
				pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
			}
			break;
		case ID_MODE_EXTPOINT: // might add an extra circle ?
		case ID_MODE_POINT:
			for (sel=this;sel!=NULL;sel=sel->multisel) {
				j=FloatX(*(sel->refnode)); k=FloatY(*(sel->refnode));
				pDC->MoveTo(j-5,k);
				pDC->LineTo(j+5,k);
				pDC->MoveTo(j,k-5);
				pDC->LineTo(j,k+5);
			}
			break;
		case ID_MODE_POLYGON: 
			for (sel=this;sel!=NULL;sel=sel->multisel) {
				if (sel->refpoly==NULL) break;
				truedx=dxoffs; truedy=dyoffs;
				if (sel->isxobj) {
					dxoffs=FloatX(*(sel->refnode));
					dyoffs=FloatY(*(sel->refnode));
				}
				pDC->MoveTo(FloatX(sel->refvertices[sel->refpoly->vertex[0]]),
							FloatY(sel->refvertices[sel->refpoly->vertex[0]]));
				pDC->LineTo(FloatX(sel->refvertices[sel->refpoly->vertex[1]]),
							FloatY(sel->refvertices[sel->refpoly->vertex[1]]));
				pDC->LineTo(FloatX(sel->refvertices[sel->refpoly->vertex[2]]),
							FloatY(sel->refvertices[sel->refpoly->vertex[2]]));
				pDC->LineTo(FloatX(sel->refvertices[sel->refpoly->vertex[3]]),
							FloatY(sel->refvertices[sel->refpoly->vertex[3]]));
				pDC->LineTo(FloatX(sel->refvertices[sel->refpoly->vertex[0]]),
							FloatY(sel->refvertices[sel->refpoly->vertex[0]]));
				dxoffs=truedx; dyoffs=truedy;
			}
			break;
		case ID_MODE_OBJECT: 
		  for (sel=this;sel!=NULL;sel=sel->multisel) {
			if (sel->objno<0) break;
			if (sel->isxobj==IS_LIGHTSRC) {
				j=(int)(1/scale);
				k=IntX(pDoc->trk[sel->refblock].lightsrc[sel->objno].refpoint);
				l=IntY(pDoc->trk[sel->refblock].lightsrc[sel->objno].refpoint);
				pDC->MoveTo(k-j,l-j);
				pDC->LineTo(k+j+1,l+j+1);
				pDC->MoveTo(k-j,l+j);
				pDC->LineTo(k+j+1,l-j-1);
			} else
			if (sel->isxobj) {
				truedx=dxoffs; truedy=dyoffs;
				x=pDoc->xobj[4*sel->refblock+sel->objchunk].obj+sel->objno;
				dxoffs=FloatX(x->ptRef); dyoffs=FloatY(x->ptRef);
				v=x->vert;
				p=x->polyData;
				for (k=0;k<x->nPolygons;k++,p++) {
					pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
					pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
					pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
					pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
					pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
				}
				dxoffs=truedx; dyoffs=truedy;
			} else {
				v=pDoc->trk[sel->refblock].vert;
				o=&(pDoc->poly[sel->refblock].obj[sel->objchunk]);
				p=o->poly[sel->objno];
				num=o->numpoly[sel->objno];
				for (l=0;l<num;l++,p++) {
					pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
					pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
					pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
					pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
					pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
				}
			}
		  }
			break;
	}
}

void CT3EDView::ShowHideCursor()
{
	CDC *dc;

	if (!isDragging) return;
	dc=GetDC();
	dc->SelectObject(redPen);
	dc->SetROP2(R2_NOTXORPEN);
	ShowSelectionAt(dc,dragX,dragY);
	ReleaseDC(dc);
}

void CT3EDView::OnDraw(CDC* pDC)
{
	CT3EDDoc* pDoc = GetDocument();
	RECT rect;
	int i,j,k,l,m,num;
	int truedx,truedy;
	LPPOLYGONDATA p;
	struct FLOATPT *v;
	struct OBJPOLYBLOCK *o;
	struct XOBJDATA *x;
	struct LIGHTSRC *light;

	ASSERT_VALID(pDoc);
	if (pDoc->bEmpty) return;

	GetClientRect(&rect);
	dxoffs=rect.right/2-offsetx
			  -(int)((refnode->x*cosPhi-refnode->y*sinPhi)/scale);
	dyoffs=rect.bottom/2-offsety+(int)((refnode->y*cosPhi*cosTheta+
				refnode->x*sinPhi*cosTheta+refnode->z*sinTheta)/scale);
	pDC->GetClipBox(&rect);

	// remove the cursor to avoid interference
	if (isDragging) {
		pDC->SetROP2(R2_WHITE);
		ShowSelectionAt(pDC,dragX,dragY);
		pDC->SetROP2(R2_COPYPEN);
	}

	if (bShowLanes) {
		pDC->SelectObject(brownPen);
		for (i=0;i<pDoc->nBlocks;i++) {
			if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
			v=pDoc->trk[i].vert;
			for (k=1;k<7;k++) {
				if ((k!=6)&&(k!=nDetail+1)) continue;
				p=pDoc->poly[i].poly[k];
				num=pDoc->poly[i].sz[k];
				for (j=0;j<num;j++,p++) {
					pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
					pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
					pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
					pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
					pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
				}
			}
		}
	}

	pDC->SelectStockObject(BLACK_PEN);
	for (i=0;i<pDoc->nBlocks;i++) {
		if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
		v=pDoc->trk[i].vert;
		p=pDoc->poly[i].poly[nDetail];
		num=pDoc->poly[i].sz[nDetail];
		for (j=0;j<num;j++,p++) {
			pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
			pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
			pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
			pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
			pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
		}
	}

// HAVING A LOOK AT POLYGON FLAGS : impassability
/*	pDC->SelectObject(redPen);
	for (i=0;i<pDoc->nBlocks;i++) {
		if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
		v=pDoc->trk[i].vert;
		p=pDoc->poly[i].poly[nDetail];
		num=pDoc->poly[i].sz[nDetail];
		for (j=0;j<num;j++,p++)
			if ((pDoc->trk[i].polyData[j].unknownFlags&0xF)%14==0) {
			 pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
			 pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
			 pDC->MoveTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
			 pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
		}
	}
*/

// CHECK VROAD
/*	pDC->SelectObject(redPen);
	for (i=0;i<pDoc->nBlocks;i++) {
		if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
		v=pDoc->trk[i].vert;
		p=pDoc->poly[i].poly[4];
		num=pDoc->poly[i].sz[4];
		for (j=0;j<num;j++,p++) {
			struct FLOATPT pt;
			pt.x=(v[p->vertex[0]].x+v[p->vertex[2]].x)/2;
			pt.z=(v[p->vertex[0]].z+v[p->vertex[2]].z)/2;
			pt.y=(v[p->vertex[0]].y+v[p->vertex[2]].y)/2;
			pDC->MoveTo(FloatX(pt),FloatY(pt));
			pt.x+=pDoc->trk[i].vroadData[j].xForw/6000.0;
			pt.z+=pDoc->trk[i].vroadData[j].zForw/6000.0;
			pt.y+=pDoc->trk[i].vroadData[j].yForw/6000.0;
			pDC->LineTo(FloatX(pt),FloatY(pt));
		}
	}
*/
	if (bShowObjects) {
		pDC->SelectObject(brownPen);
		for (i=0;i<pDoc->nBlocks;i++) {
			if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
			// show light sources
			light=pDoc->trk[i].lightsrc;
			m=(int)(1/scale);
			for (j=0;j<pDoc->trk[i].nLightsrc;j++,light++) {
				k=IntX(light->refpoint);
				l=IntY(light->refpoint);
				pDC->MoveTo(k-m,l-m);
				pDC->LineTo(k+m+1,l+m+1);
				pDC->MoveTo(k-m,l+m);
				pDC->LineTo(k+m+1,l-m-1);
			}
		}
		pDC->SelectObject(bluePen);
		for (i=0;i<pDoc->nBlocks;i++) {
			if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
			v=pDoc->trk[i].vert;
			for (j=0;j<4;j++) {
				o=&(pDoc->poly[i].obj[j]);
				if (o->n1==0) continue;
				for (k=0;k<o->nobj;k++) {
					p=o->poly[k];
					num=o->numpoly[k];
					for (l=0;l<num;l++,p++) {
			pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
			pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
			pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
			pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
			pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
					}
				}
			}
		}
		pDC->SelectObject(greenPen);
		truedx=dxoffs; truedy=dyoffs;
		for (i=0;i<4*pDoc->nBlocks;i++) {
			if (!MeetsClipRect(&(pDoc->trk[i/4]),&rect)) { i=i|3; continue; }
			x=pDoc->xobj[i].obj;
			for (j=0;j<pDoc->xobj[i].nobj;j++,x++) {
				dxoffs=FloatX(x->ptRef); dyoffs=FloatY(x->ptRef);
				v=x->vert;
				p=x->polyData;
				for (k=0;k<x->nPolygons;k++,p++) {
			pDC->MoveTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
			pDC->LineTo(FloatX(v[p->vertex[1]]),FloatY(v[p->vertex[1]]));
			pDC->LineTo(FloatX(v[p->vertex[2]]),FloatY(v[p->vertex[2]]));
			pDC->LineTo(FloatX(v[p->vertex[3]]),FloatY(v[p->vertex[3]]));
			pDC->LineTo(FloatX(v[p->vertex[0]]),FloatY(v[p->vertex[0]]));
				}
				dxoffs=truedx; dyoffs=truedy;
			}
		}
	}

/* a glimpse at the vroad...
	pDC->SelectObject(greenPen);
	for (i=0;i<pDoc->col.vroadHead.nrec;i++) {
		struct INTPT pt;
		pt.x=pDoc->col.vroad[i].refPt.x-pDoc->col.vroad[i].right.x*(pDoc->col.vroad[i].leftWall/128);
		pt.y=pDoc->col.vroad[i].refPt.y-pDoc->col.vroad[i].right.y*(pDoc->col.vroad[i].leftWall/128);
		pt.z=pDoc->col.vroad[i].refPt.z-pDoc->col.vroad[i].right.z*(pDoc->col.vroad[i].leftWall/128);
		pDC->MoveTo(IntX(pt),IntY(pt));
		pt.x=pDoc->col.vroad[i].refPt.x+pDoc->col.vroad[i].right.x*(pDoc->col.vroad[i].rightWall/128);
		pt.y=pDoc->col.vroad[i].refPt.y+pDoc->col.vroad[i].right.y*(pDoc->col.vroad[i].rightWall/128);
		pt.z=pDoc->col.vroad[i].refPt.z+pDoc->col.vroad[i].right.z*(pDoc->col.vroad[i].rightWall/128);
		pDC->LineTo(IntX(pt),IntY(pt));
	}
*/
/* or at the bounding rectangles...
	pDC->SelectObject(brownPen);
	for (i=0;i<pDoc->nBlocks;i++) {
		// pDoc->RecalcBoundingBox(i);
		pDC->MoveTo(FloatX(pDoc->trk[i].ptBounding[0]),FloatY(pDoc->trk[i].ptBounding[0]));
		pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[1]),FloatY(pDoc->trk[i].ptBounding[1]));
		pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[2]),FloatY(pDoc->trk[i].ptBounding[2]));
		pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[3]),FloatY(pDoc->trk[i].ptBounding[3]));
		pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[0]),FloatY(pDoc->trk[i].ptBounding[0]));
	}
	pDC->SelectObject(redPen);
	i=refblock;
	pDC->MoveTo(FloatX(pDoc->trk[i].ptBounding[0]),FloatY(pDoc->trk[i].ptBounding[0]));
	pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[1]),FloatY(pDoc->trk[i].ptBounding[1]));
	pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[2]),FloatY(pDoc->trk[i].ptBounding[2]));
	pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[3]),FloatY(pDoc->trk[i].ptBounding[3]));
	pDC->LineTo(FloatX(pDoc->trk[i].ptBounding[0]),FloatY(pDoc->trk[i].ptBounding[0]));
*/
/* or at the first polyobj chunk refpositions
	pDC->SelectObject(brownPen);
	for (i=0;i<pDoc->nBlocks;i++)
		for (j=0;j<pDoc->trk[i].nPolyobj;j++) {
			pDC->MoveTo(IntX(pDoc->trk[i].polyobj[j]->pt)-5,IntY(pDoc->trk[i].polyobj[j]->pt));
			pDC->LineTo(IntX(pDoc->trk[i].polyobj[j]->pt)+5,IntY(pDoc->trk[i].polyobj[j]->pt));
			pDC->MoveTo(IntX(pDoc->trk[i].polyobj[j]->pt),IntY(pDoc->trk[i].polyobj[j]->pt)-5);
			pDC->LineTo(IntX(pDoc->trk[i].polyobj[j]->pt),IntY(pDoc->trk[i].polyobj[j]->pt)+5);
		}	
*/
	// selection highlighting
	GetClientRect(&rect);
	pDC->SelectObject(redPen);
	ShowSelectionAt(pDC,rect.right/2-offsetx,rect.bottom/2-offsety);

	// dragging cursor, using redPen in xor mode
	if (isDragging) {
		pDC->SetROP2(R2_NOTXORPEN);
		ShowSelectionAt(pDC,dragX,dragY);
	}

}

/////////////////////////////////////////////////////////////////////////////
// CT3EDView diagnostics

#ifdef _DEBUG
void CT3EDView::AssertValid() const
{
	CView::AssertValid();
}

void CT3EDView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CT3EDDoc* CT3EDView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CT3EDDoc)));
	return (CT3EDDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CT3EDView message handlers

void CT3EDView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	RECT rect;
	BOOL act=TRUE,scroll=FALSE;
	int oldx;

	if (bScrollRotate) {
		switch(nSBCode) {
			case SB_LEFT: phi=-180; break;
			case SB_LINELEFT: phi-=5; break;
			case SB_LINERIGHT: phi+=5; break;
			case SB_PAGELEFT: phi-=30; break;
			case SB_PAGERIGHT: phi+=30; break;
			case SB_RIGHT: phi=180; break;
			case SB_THUMBPOSITION: phi=nPos; break;
			case SB_THUMBTRACK: phi=nPos; act=FALSE; break;
			default: return;
		}
		if (phi<-180) phi+=360;
		if (phi>180) phi-=360;
		cosPhi=(float)cos(phi*3.14159265359/180.0);
		sinPhi=-(float)sin(phi*3.14159265359/180.0);
		SetScrollPos(SB_HORZ,phi,TRUE);
	} else {
		GetClientRect(&rect);
		oldx=offsetx;
		switch(nSBCode) {
			case SB_LEFT: offsetx=-SCROLLSZ; break;
			case SB_LINELEFT: offsetx-=40; scroll=TRUE; break;
			case SB_LINERIGHT: offsetx+=40; scroll=TRUE; break;
			case SB_PAGELEFT: offsetx-=rect.right/2; scroll=TRUE; break;
			case SB_PAGERIGHT: offsetx+=rect.right/2; scroll=TRUE; break;
			case SB_RIGHT: offsetx=SCROLLSZ; break;
			case SB_THUMBPOSITION: offsetx=nPos; break;
			case SB_THUMBTRACK: offsetx=nPos; act=FALSE; break;
			default: return;
		}
		if (offsetx<-SCROLLSZ) offsetx=-SCROLLSZ;
		if (offsetx>SCROLLSZ) offsetx=SCROLLSZ;
		SetScrollPos(SB_HORZ,offsetx,TRUE);
	}
	if (act) {
		if (scroll) { ScrollWindow(oldx-offsetx,0); UpdateWindow(); }
		else InvalidateRect(NULL,TRUE);
	}
}

void CT3EDView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	RECT rect;
	BOOL act=TRUE,scroll=FALSE;
	int oldy;

	if (bScrollRotate) {
		switch(nSBCode) {
			case SB_TOP: theta=0; break;
			case SB_LINEUP: theta-=5; break;
			case SB_LINEDOWN: theta+=5; break;
			case SB_PAGEUP: theta-=15; break;
			case SB_PAGEDOWN: theta+=15; break;
			case SB_BOTTOM: theta=90; break;
			case SB_THUMBPOSITION: theta=nPos; break;
			case SB_THUMBTRACK: theta=nPos; act=FALSE; break;
			default: return;
		}
		if (theta<0) theta=0;
		if (theta>90) theta=90;
		cosTheta=(float)cos(theta*3.14159265359/180.0);
		sinTheta=(float)sin(theta*3.14159265359/180.0);
		SetScrollPos(SB_VERT,theta,TRUE);
	} else {
		GetClientRect(&rect);
		oldy=offsety;
		switch(nSBCode) {
			case SB_TOP: offsety=-SCROLLSZ; break;
			case SB_LINEUP: offsety-=40; scroll=TRUE; break;
			case SB_LINEDOWN: offsety+=40; scroll=TRUE; break;
			case SB_PAGEUP: offsety-=rect.bottom/2; scroll=TRUE; break;
			case SB_PAGEDOWN: offsety+=rect.bottom/2; scroll=TRUE; break;
			case SB_BOTTOM: offsety=SCROLLSZ; break;
			case SB_THUMBPOSITION: offsety=nPos; break;
			case SB_THUMBTRACK: offsety=nPos; act=FALSE; break;
			default: return;
		}
		if (offsety<-SCROLLSZ) offsety=-SCROLLSZ;
		if (offsety>SCROLLSZ) offsety=SCROLLSZ;
		SetScrollPos(SB_VERT,offsety,TRUE);
	}
	if (act) {
		if (scroll) { ScrollWindow(0,oldy-offsety); UpdateWindow(); }
		else InvalidateRect(NULL,TRUE);
	}
}

void CT3EDView::OnViewFullres() 
{
	if (nDetail==HIGH_DETAIL) return;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	if ((refpoly!=NULL)&&IsPolyOfDetail(nDetail)) refpoly=NULL;
	nDetail=HIGH_DETAIL;
	if (isTruePoint&&!bShowLanes)
		if (!IsVisibleNode(refblock,refnode)) isTruePoint=FALSE;
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnViewHalfres() 
{
	if (nDetail==MED_DETAIL) return;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	if ((refpoly!=NULL)&&IsPolyOfDetail(nDetail)) refpoly=NULL;
	nDetail=MED_DETAIL;
	if (isTruePoint&&!bShowLanes)
		if (!IsVisibleNode(refblock,refnode)) isTruePoint=FALSE;
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnViewLowres() 
{
	if (nDetail==LOW_DETAIL) return;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	if ((refpoly!=NULL)&&IsPolyOfDetail(nDetail)) refpoly=NULL;
	nDetail=LOW_DETAIL;
	if (isTruePoint&&!bShowLanes)
		if (!IsVisibleNode(refblock,refnode)) isTruePoint=FALSE;
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnViewZoomin() 
{
	if (scale<0.05) return;
	scale=scale/2;
	offsetx=2*offsetx;
	offsety=2*offsety;
	if (offsetx<-SCROLLSZ) offsetx=-SCROLLSZ;
	if (offsety<-SCROLLSZ) offsety=-SCROLLSZ;
	if (offsetx>SCROLLSZ) offsetx=SCROLLSZ;
	if (offsety>SCROLLSZ) offsety=SCROLLSZ;
	InvalidateRect(NULL,TRUE);
	if (!bScrollRotate) {
		SetScrollPos(SB_HORZ,offsetx,TRUE);
		SetScrollPos(SB_VERT,offsety,TRUE);
	}
}

void CT3EDView::OnViewZoomout() 
{
	if (scale>5.0) return;
	scale=scale*2;
	offsetx=offsetx/2;
	offsety=offsety/2;
	InvalidateRect(NULL,TRUE);
	if (!bScrollRotate) {
		SetScrollPos(SB_HORZ,offsetx,TRUE);
		SetScrollPos(SB_VERT,offsety,TRUE);
	}
}

void CT3EDView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();

	refblock=0;
	multisel=NULL;
	offsetx=0; offsety=0;
	theta=30; phi=0;
	cosTheta=(float)sqrt(3.0)/2; sinTheta=0.5; cosPhi=1.0; sinPhi=0.0;
	scale=1.0;
	nDetail=HIGH_DETAIL;
	bShowObjects=TRUE; bShowLanes=TRUE;
	isScrolling=FALSE;
	bScrollRotate=FALSE;
	isEmpty=GetDocument()->bEmpty;
	selMode=ID_MODE_BLOCK;
	isTruePoint=FALSE; refpoly=NULL; objno=-1;
	isDragging=FALSE;
	editMode=NULL;
	smooth2Start=0; smooth2Width=25; // ~half a block
	smooth1Start=12; smooth1Width=20; // over 3 blocks
	extraSmooth=TRUE;

	SetScrollRange(SB_HORZ,-SCROLLSZ,SCROLLSZ,FALSE);
	SetScrollRange(SB_VERT,-SCROLLSZ,SCROLLSZ,FALSE);
	SetScrollPos(SB_HORZ,0,TRUE);
	SetScrollPos(SB_VERT,0,TRUE);
	statusbar=(CStatusBar *)GetParentFrame()->GetMessageBar();
	if (isEmpty) {
		statusbar->SetPaneText(1,"No Block",TRUE);
		statusbar->SetPaneText(2,"EMPTY",TRUE);
//		GetParentFrame()->GetMenu()->EnableMenuItem(2,MF_BYPOSITION|MF_GRAYED);
//		GetParentFrame()->GetMenu()->EnableMenuItem(3,MF_BYPOSITION|MF_GRAYED);
	} else {
		statusbar->SetPaneText(1,"Block 0",TRUE);
		statusbar->SetPaneText(2,"TRANSL",TRUE);
//		GetParentFrame()->GetMenu()->EnableMenuItem(2,MF_BYPOSITION|MF_ENABLED);
//		GetParentFrame()->GetMenu()->EnableMenuItem(3,MF_BYPOSITION|MF_ENABLED);
		refnode=&(GetDocument()->trk[refblock].ptCentre);
	}
}

void CT3EDView::OnUpdateViewFullres(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((nDetail==HIGH_DETAIL)&&!isEmpty);
}

void CT3EDView::OnUpdateViewHalfres(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((nDetail==MED_DETAIL)&&!isEmpty);
}

void CT3EDView::OnUpdateViewLowres(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((nDetail==LOW_DETAIL)&&!isEmpty);
}

void CT3EDView::OnUpdateViewZoomin(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((scale>=0.05)&&!isEmpty);
}

void CT3EDView::OnUpdateViewZoomout(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((scale<=5.0)&&!isEmpty);	
}

void CT3EDView::UpdateRefBlock()
{
	CString s;
	s.Format("Block %d",refblock);
	statusbar->SetPaneText(1,s,TRUE);
}

void CT3EDView::OnViewRotateMode() 
{
	int x,y,i,num,n0,d,d0;
	struct TRKBLOCK *trk0,*trk;
	RECT r;

	bScrollRotate=TRUE;
	statusbar->SetPaneText(2,"ROTATE",TRUE);
	SetScrollRange(SB_HORZ,-180,180,FALSE);
	SetScrollRange(SB_VERT,0,90,FALSE);
	SetScrollPos(SB_HORZ,phi,TRUE);
	SetScrollPos(SB_VERT,theta,TRUE);
	
	// look for a suitable reference point around which to rotate
	GetClientRect(&r);
	if ((offsetx>r.right)||(offsetx<-r.right)||
			(offsety>r.bottom)||(offsety<-r.bottom)) {
		dxoffs=-offsetx
				-(int)((refnode->x*cosPhi-refnode->y*sinPhi)/scale);
		dyoffs=-offsety+(int)((refnode->y*cosPhi*cosTheta+
				refnode->x*sinPhi*cosTheta+refnode->z*sinTheta)/scale);
		trk0=GetDocument()->trk;
		num=GetDocument()->nBlocks;
		n0=-1; d0=1<<30;
		for (i=0,trk=trk0;i<num;i++,trk++) {
			x=FloatX(trk->ptCentre); y=FloatY(trk->ptCentre);
			if (x<0) x=-x; if (y<0) y=-y;
			if ((x<r.right/2)&&(y<r.bottom/2)) {
				d=(x<<16)/r.right+(y<<16)/r.bottom;
				if (d<d0) { d0=d; n0=i; }
			}
		}
		if (n0>=0) {
			trk=trk0+n0;
			x=FloatX(trk->ptCentre); y=FloatY(trk->ptCentre);
			refblock=n0;
			UpdateRefBlock();
			refnode=&(trk->ptCentre);
			isTruePoint=FALSE; refpoly=NULL; objno=-1;
		}
	}

	offsetx=0; offsety=0; // recenter so we don't get lost
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnUpdateViewRotateMode(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck(bScrollRotate&&!isEmpty);
}

void CT3EDView::OnViewTranslMode() 
{
	bScrollRotate=FALSE;
	statusbar->SetPaneText(2,"TRANSL",TRUE);
	SetScrollRange(SB_HORZ,-SCROLLSZ,SCROLLSZ,FALSE);
	SetScrollRange(SB_VERT,-SCROLLSZ,SCROLLSZ,FALSE);
	SetScrollPos(SB_HORZ,offsetx,TRUE);
	SetScrollPos(SB_VERT,offsety,TRUE);
}

void CT3EDView::OnUpdateViewTranslMode(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck(!bScrollRotate&&!isEmpty);
}

void CT3EDView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);	
}

void CT3EDView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);	
}

void CT3EDView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (isDragging) return;
	switch(nChar) {
		case VK_LEFT:  OnHScroll(SB_LINELEFT,0,NULL); break;
		case VK_RIGHT: OnHScroll(SB_LINERIGHT,0,NULL); break;
		case VK_UP:    OnVScroll(SB_LINEUP,0,NULL); break;
		case VK_DOWN:  OnVScroll(SB_LINEDOWN,0,NULL); break;
		default: CView::OnKeyDown(nChar, nRepCnt, nFlags);
	}
}

void CT3EDView::OnUpdateViewShowhideobjects(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);	
	pCmdUI->SetCheck(bShowObjects&&!isEmpty);
}

void CT3EDView::OnViewShowhideobjects() 
{
	bShowObjects=!bShowObjects;
	if ((multisel!=NULL)&&!bShowObjects) { delete multisel; multisel=NULL; }
	if (!bShowObjects&&(refpoly!=NULL))
		if (!(IsPolyOfDetail(nDetail)||IsPolyOfDetail(6))) refpoly=NULL;
	if (!bShowObjects) objno=-1;
	InvalidateRect(NULL,!bShowObjects);
}

void CT3EDView::OnViewShowlanes() 
{
	bShowLanes=!bShowLanes;
	if ((multisel!=NULL)&&!bShowLanes) { delete multisel; multisel=NULL; }
	if (isTruePoint&&!bShowLanes)
		if (!IsVisibleNode(refblock,refnode)) isTruePoint=FALSE;
	if ((refpoly!=NULL)&&!bShowLanes&&!isxobj&&(refpolyobj<0))
		if ((refpolychunk==6)||(refpolychunk&1)) refpoly=NULL;
	InvalidateRect(NULL,!bShowLanes);
}

void CT3EDView::OnUpdateViewShowlanes(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck(bShowLanes&&!isEmpty);
}

void CT3EDView::OnLButtonDown(UINT nFlags, CPoint point) 
{	
	int i,j,k,l,n,x,y,i0,j0,k0,l0,dist,dist0,x0,y0;
	RECT rect;
	BOOL needErase=FALSE;
	CT3EDDoc *pDoc=GetDocument();
	struct FLOATPT *coreref,*pt,*pt0,mypt; //,tmppt;
	struct XOBJDATA *xx;
	LPPOLYGONDATA p,p0;
	struct OBJPOLYBLOCK *o;
	struct LIGHTSRC *light;
	int isx0;
	POINT ptnew;

	if (isEmpty) return;
	GetClientRect(&rect);
	dxoffs=rect.right/2-offsetx
			  -(int)((refnode->x*cosPhi-refnode->y*sinPhi)/scale);
	dyoffs=rect.bottom/2-offsety+(int)((refnode->y*cosPhi*cosTheta+
				refnode->x*sinPhi*cosTheta+refnode->z*sinTheta)/scale);

	rect.left=point.x-10; rect.right=point.x+10;
	rect.top=point.y-10; rect.bottom=point.y+10;

	CleanCursorZone(selMode,FALSE);
	switch(selMode) {
		case ID_MODE_BLOCK:
			i0=-1; dist0=1<<30;
			for (i=0;i<pDoc->nBlocks;i++) {
				x=FloatX(pDoc->trk[i].ptCentre);
				y=FloatY(pDoc->trk[i].ptCentre);
				dist=(x>point.x)?(x-point.x):(point.x-x);
				dist+=(y>point.y)?(y-point.y):(point.y-y);
				if (dist<dist0) { i0=i; x0=x; y0=y; dist0=dist; }
			}
			if (!MeetsClipRect(&(pDoc->trk[i0]),&rect)) return;
			if (refblock==i0) return;
			refblock=i0;
			refnode=&(pDoc->trk[i0].ptCentre);
			break;

		case ID_MODE_POINT:
		case ID_MODE_EXTPOINT:
			coreref=NULL; pt0=NULL; dist0=10;
			for (i=0;i<pDoc->nBlocks;i++) {
				if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
				pt=pDoc->trk[i].vert;
				n=pDoc->trk[i].nVertices;
				for (j=0;j<n;j++,pt++) {
					x=FloatX(*pt); y=FloatY(*pt);
					dist=((x>point.x)?(x-point.x):(point.x-x))
						+((y>point.y)?(y-point.y):(point.y-y));
					if (dist<dist0)
						if (IsVisibleNode(i,pt)) {
							i0=i; x0=x; y0=y; 
							dist0=dist; pt0=pt; 
							isx0=0;
							coreref=NULL;
						}
				}
			  if (bShowObjects||bShowLanes) {
				for (j=4*i;j<4*i+4;j++) { // explore xobjs
					xx=pDoc->xobj[j].obj;
					for (k=0;k<pDoc->xobj[j].nobj;k++,xx++) {
						pt=xx->vert;
						for (l=0;l<xx->nVertices;l++,pt++) {
							x=FloatFloatX(*pt,xx->ptRef); y=FloatFloatY(*pt,xx->ptRef);
							dist=((x>point.x)?(x-point.x):(point.x-x))
								+((y>point.y)?(y-point.y):(point.y-y));
							if (dist<dist0) {
								i0=i; x0=x; y0=y; 
								dist0=dist; pt0=pt;
								coreref=&(xx->ptRef);
								isx0=1;
							}
						}
					}
				}
/*				if (editMode!=ID_TOOLS_MERGE)
				for (j=0,light=pDoc->trk[i].lightsrc;j<pDoc->trk[i].nLightsrc;j++,light++)
				{
					x=IntX(light->refpoint);
					y=IntY(light->refpoint);
					dist=((x>point.x)?(x-point.x):(point.x-x))
						+((y>point.y)?(y-point.y):(point.y-y));
					if (dist<dist0) {
						i0=i; x0=x; y0=y; 
						dist0=dist;
						tmppt.x=((float)light->refpoint.x)/65536;
						tmppt.y=((float)light->refpoint.y)/65536;
						tmppt.z=((float)light->refpoint.z)/65536;
						pt0=&tmppt;
						isx0=2;
					}
				}
*/ // selecting lightsrcs is useless, can't move them !
			  }
			}
			if (pt0==NULL) return;
			if ((nFlags&(MK_CONTROL|MK_SHIFT))
				&& (editMode!=ID_TOOLS_MERGE) && (selMode==ID_MODE_POINT)) {
				CSelData *sel=new CSelData;
				sel->multisel=multisel;
				sel->refblock=refblock;
				if (refnode==&myrefnode) {
					sel->myrefnode.x=myrefnode.x;
					sel->myrefnode.y=myrefnode.y;
					sel->myrefnode.z=myrefnode.z;
					sel->refnode=&(sel->myrefnode);
				} 
				else sel->refnode=refnode;
				multisel=sel;
			} else {
				if (multisel!=NULL)
				{ delete multisel; multisel=NULL; }
			}
			memcpy(&mypt,refnode,12);
			if (!isx0) refnode=pt0;
			else if (isx0==1) { // chose a xobj
				refnode=&myrefnode;
				myrefnode.x=coreref->x+pt0->x;
				myrefnode.z=coreref->z+pt0->z;
				myrefnode.y=coreref->y+pt0->y;
			}
/*			else { // chose a lightsrc
				refnode=&myrefnode;
				memcpy(&myrefnode,&tmppt,12);
			}
*/
			// merge vertices command
			if ((editMode==ID_TOOLS_MERGE)&&(nFlags&MK_CONTROL)) {
				pDoc->PrepareNewUndo(&mypt,refblock,offsetx,offsety);
				pDoc->MergePoint(refnode,&mypt);
				refnode=&myrefnode;
				memcpy(refnode,&mypt,12);
				InvalidateRect(NULL,TRUE);
				isTruePoint=TRUE;
				return;
			}
			refblock=i0;
			isTruePoint=TRUE;
			break;

		case ID_MODE_POLYGON:
			i0=-1; dist0=1<<30; p0=NULL;
			for (i=0;i<pDoc->nBlocks;i++) {
				if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
				pt=pDoc->trk[i].vert;
				for (k=0;k<7;k++) {
					if (!bShowLanes) if (k!=nDetail) continue;
					if (bShowLanes) if (((k&6)!=nDetail)&&(k!=6)) continue;
					p=pDoc->poly[i].poly[k];
					n=pDoc->poly[i].sz[k];
					for (j=0;j<n;j++,p++) {
						x=(FloatX(pt[p->vertex[0]])+FloatX(pt[p->vertex[1]])
						  +FloatX(pt[p->vertex[2]])+FloatX(pt[p->vertex[3]]))/4;
						y=(FloatY(pt[p->vertex[0]])+FloatY(pt[p->vertex[1]])
						  +FloatY(pt[p->vertex[2]])+FloatY(pt[p->vertex[3]]))/4;
						dist=((x>point.x)?(x-point.x):(point.x-x))
							+((y>point.y)?(y-point.y):(point.y-y));
						if (dist<dist0) {
							i0=i; x0=x; y0=y; 
							j0=k; k0=-1; l0=j;
							dist0=dist; p0=p; pt0=pt; isx0=0;
						}
					}
				}
			}
		if (bShowObjects) {
			for (i=0;i<pDoc->nBlocks;i++) {
				if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
				pt=pDoc->trk[i].vert;
				for (j=0;j<4;j++) {
					o=&(pDoc->poly[i].obj[j]);
					if (o->n1==0) continue;
					for (k=0;k<o->nobj;k++) {
						p=o->poly[k];
						n=o->numpoly[k];
						for (l=0;l<n;l++,p++) {
							x=(FloatX(pt[p->vertex[0]])+FloatX(pt[p->vertex[1]])
							  +FloatX(pt[p->vertex[2]])+FloatX(pt[p->vertex[3]]))/4;
							y=(FloatY(pt[p->vertex[0]])+FloatY(pt[p->vertex[1]])
							  +FloatY(pt[p->vertex[2]])+FloatY(pt[p->vertex[3]]))/4;
							dist=((x>point.x)?(x-point.x):(point.x-x))
								+((y>point.y)?(y-point.y):(point.y-y));
							if (dist<dist0) {
								i0=i; x0=x; y0=y; 
								j0=j; k0=k; l0=l;
								dist0=dist; p0=p; pt0=pt; isx0=0;
							}
						}
					}
				}
			}
			for (i=0;i<4*pDoc->nBlocks;i++) {
				if (!MeetsClipRect(&(pDoc->trk[i/4]),&rect)) { i=i|3; continue; }
				xx=pDoc->xobj[i].obj;
				for (j=0;j<pDoc->xobj[i].nobj;j++,xx++) {
					pt=xx->vert;
					p=xx->polyData;
					for (k=0;k<xx->nPolygons;k++,p++) {
						x=(FloatFloatX(pt[p->vertex[0]],xx->ptRef)+FloatFloatX(pt[p->vertex[1]],xx->ptRef)
						  +FloatFloatX(pt[p->vertex[2]],xx->ptRef)+FloatFloatX(pt[p->vertex[3]],xx->ptRef))/4;
						y=(FloatFloatY(pt[p->vertex[0]],xx->ptRef)+FloatFloatY(pt[p->vertex[1]],xx->ptRef)
						  +FloatFloatY(pt[p->vertex[2]],xx->ptRef)+FloatFloatY(pt[p->vertex[3]],xx->ptRef))/4;
						dist=((x>point.x)?(x-point.x):(point.x-x))
							+((y>point.y)?(y-point.y):(point.y-y));
						if (dist<dist0) {
							i0=i/4; x0=x; y0=y; 
							j0=i%4; k0=j; l0=k;
							dist0=dist; p0=p; pt0=pt; 
							isx0=1; coreref=&(xx->ptRef);
						}
					}
				}
			}
		}
			if (p0==NULL) return;
			if ((nFlags&(MK_CONTROL|MK_SHIFT)) && (refpoly!=NULL)) {
				CSelData *sel=new CSelData;
				sel->multisel=multisel;
				sel->refblock=refblock;
				sel->refpolychunk=refpolychunk;
				sel->refpolyobj=refpolyobj;
				sel->refpolyno=refpolyno;
				sel->isxobj=isxobj;
				sel->refpoly=refpoly;
				sel->refvertices=refvertices;
				sel->refnode=refnode;
				multisel=sel;
			} else {
				if (multisel!=NULL)
				{ delete multisel; multisel=NULL; }
			}
			refblock=i0;
			refpolychunk=j0;
			refpolyobj=k0;
			refpolyno=l0;
			isxobj=isx0;
			refpoly=p0;
			refvertices=pt0;
			if (isx0) pt=coreref;
			else pt=refvertices+refpoly->vertex[0];
			x0=FloatX(*pt); y0=FloatY(*pt);
			refnode=pt;
			break;

		case ID_MODE_OBJECT:
			if (!bShowObjects) return;
			i0=-1; dist0=1<<30;
			for (i=0;i<pDoc->nBlocks;i++) {
				if (!MeetsClipRect(&(pDoc->trk[i]),&rect)) continue;
				pt=pDoc->trk[i].vert;
				for (j=0;j<4;j++) {
					o=&(pDoc->poly[i].obj[j]);
					if (o->n1==0) continue;
					for (k=0;k<o->nobj;k++) {
						p=o->poly[k];
						n=o->numpoly[k];
						for (l=0;l<n;l++,p++) {
							x=(FloatX(pt[p->vertex[0]])+FloatX(pt[p->vertex[1]])
							  +FloatX(pt[p->vertex[2]])+FloatX(pt[p->vertex[3]]))/4;
							y=(FloatY(pt[p->vertex[0]])+FloatY(pt[p->vertex[1]])
							  +FloatY(pt[p->vertex[2]])+FloatY(pt[p->vertex[3]]))/4;
							dist=((x>point.x)?(x-point.x):(point.x-x))
								+((y>point.y)?(y-point.y):(point.y-y));
							if (dist<dist0) {
								i0=i; j0=j; k0=k;
								dist0=dist; isx0=0;
							}
						}
					}
				}
				for (k=0,light=pDoc->trk[i].lightsrc;k<pDoc->trk[i].nLightsrc;k++,light++)
				{
					x=IntX(light->refpoint);
					y=IntY(light->refpoint);
					dist=((x>point.x)?(x-point.x):(point.x-x))
						+((y>point.y)?(y-point.y):(point.y-y));
					if (dist<dist0) {
						i0=i; j0=0; k0=k;
						dist0=dist;
						isx0=2;
					}
				}
			}
			for (i=0;i<4*pDoc->nBlocks;i++) {
				if (!MeetsClipRect(&(pDoc->trk[i/4]),&rect)) { i=i|3; continue; }
				xx=pDoc->xobj[i].obj;
				for (j=0;j<pDoc->xobj[i].nobj;j++,xx++) {
					pt=xx->vert;
					p=xx->polyData;
					for (k=0;k<xx->nPolygons;k++,p++) {
						x=(FloatFloatX(pt[p->vertex[0]],xx->ptRef)+FloatFloatX(pt[p->vertex[1]],xx->ptRef)
						  +FloatFloatX(pt[p->vertex[2]],xx->ptRef)+FloatFloatX(pt[p->vertex[3]],xx->ptRef))/4;
						y=(FloatFloatY(pt[p->vertex[0]],xx->ptRef)+FloatFloatY(pt[p->vertex[1]],xx->ptRef)
						  +FloatFloatY(pt[p->vertex[2]],xx->ptRef)+FloatFloatY(pt[p->vertex[3]],xx->ptRef))/4;
						dist=((x>point.x)?(x-point.x):(point.x-x))
							+((y>point.y)?(y-point.y):(point.y-y));
						if (dist<dist0) {
							i0=i/4; j0=i%4; k0=j;
							dist0=dist; isx0=1;
						}
					}
				}
			}
			if (i0<0) return;
			if ((nFlags&(MK_CONTROL|MK_SHIFT)) && (objno>=0)) {
				CSelData *sel=new CSelData;
				sel->multisel=multisel;
				sel->refblock=refblock;
				sel->isxobj=isxobj;
				sel->objchunk=objchunk;
				sel->objno=objno;
				if (refnode==&myrefnode) {
					sel->myrefnode.x=myrefnode.x;
					sel->myrefnode.y=myrefnode.y;
					sel->myrefnode.z=myrefnode.z;
					sel->refnode=&(sel->myrefnode);
				} 
				else sel->refnode=refnode;
				multisel=sel;
			} else {
				if (multisel!=NULL)
				{ delete multisel; multisel=NULL; }
			}
			refblock=i0;
			isxobj=isx0;
			objchunk=j0;
			objno=k0;
			if (isx0==2) {
				pt=&myrefnode;
				myrefnode.x=((float)pDoc->trk[i0].lightsrc[k0].refpoint.x)/65536;
				myrefnode.y=((float)pDoc->trk[i0].lightsrc[k0].refpoint.y)/65536;
				myrefnode.z=((float)pDoc->trk[i0].lightsrc[k0].refpoint.z)/65536;
			}
			else if (isx0==1) pt=&(pDoc->xobj[4*i0+j0].obj[k0].ptRef);
			else pt=pDoc->trk[i0].vert
					+pDoc->poly[i0].obj[j0].poly[k0]->vertex[0];
			x0=FloatX(*pt); y0=FloatY(*pt);
			refnode=pt;
			break;
	}

	GetClientRect(&rect);
	if (bScrollRotate) {
		offsetx=0; 
		offsety=0; 
		needErase=TRUE;
		ptnew.x=rect.right/2; ptnew.y=rect.bottom/2;
		ClientToScreen(&ptnew);
		if ((editMode==ID_TOOLS_MOVEXY)||(editMode==ID_TOOLS_MOVEZ))
			SetCursorPos(ptnew.x,ptnew.y);
	}
	else {	// x0,y0 == coordinates of new refnode
		offsetx=-(x0-rect.right/2); 
		offsety=-(y0-rect.bottom/2);
		if (offsetx<-rect.right/2+40)
			{ offsetx+=rect.right/2; needErase=TRUE; }
		if (offsetx>rect.right/2-40)
			{ offsetx-=rect.right/2; needErase=TRUE; }
		if (offsety<-rect.bottom/2+40)
			{ offsety+=rect.bottom/2; needErase=TRUE; }
		if (offsety>rect.bottom/2-40)
			{ offsety-=rect.bottom/2; needErase=TRUE; }
		SetScrollPos(SB_HORZ,offsetx,TRUE);
		SetScrollPos(SB_VERT,offsety,TRUE);
	}
	if (needErase) InvalidateRect(NULL,TRUE);
	else CleanCursorZone(selMode,TRUE);
	UpdateRefBlock();
	delayMouseMove=TRUE;
}

void CT3EDView::OnModeBlock() 
{
	if (isDragging) return; // safety
	CleanCursorZone(selMode,FALSE);
	selMode=ID_MODE_BLOCK;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	isTruePoint=FALSE; refpoly=NULL; objno=-1;
	editMode=NULL;
	CleanCursorZone(selMode,TRUE);
}

void CT3EDView::OnUpdateModeBlock(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((selMode==ID_MODE_BLOCK)&&!isEmpty);
}

void CT3EDView::OnModeExtpoint() 
{
	if (isDragging) return; // safety
	CleanCursorZone(selMode,FALSE);
	selMode=ID_MODE_EXTPOINT;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	refpoly=NULL; objno=-1;
	editMode=NULL;
	CleanCursorZone(selMode,TRUE);
}

void CT3EDView::OnUpdateModeExtpoint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((selMode==ID_MODE_EXTPOINT)&&!isEmpty);
}

void CT3EDView::OnModePoint() 
{
	if (isDragging) return; // safety
	CleanCursorZone(selMode,FALSE);
	selMode=ID_MODE_POINT;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	refpoly=NULL; objno=-1;
	editMode=NULL;
	CleanCursorZone(selMode,TRUE);
}

void CT3EDView::OnUpdateModePoint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((selMode==ID_MODE_POINT)&&!isEmpty);
}

void CT3EDView::OnModeObject() 
{
	if (isDragging) return; // safety
	CleanCursorZone(selMode,FALSE);
	selMode=ID_MODE_OBJECT;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	isTruePoint=FALSE; refpoly=NULL;
	editMode=NULL;
	CleanCursorZone(selMode,TRUE);
}

void CT3EDView::OnUpdateModeObject(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&bShowObjects);
	pCmdUI->SetCheck((selMode==ID_MODE_OBJECT)&&!isEmpty);
}

void CT3EDView::OnModePolygon() 
{
	if (isDragging) return; // safety
	CleanCursorZone(selMode,FALSE);
	selMode=ID_MODE_POLYGON;
	if (multisel!=NULL) { delete multisel; multisel=NULL; }
	isTruePoint=FALSE; objno=-1;
	editMode=NULL;
	CleanCursorZone(selMode,TRUE);
}

void CT3EDView::OnUpdateModePolygon(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck((selMode==ID_MODE_POLYGON)&&!isEmpty);
}

void CT3EDView::CleanCursorZone(int mode,BOOL newstate)
{
	RECT r;
	int x,y,zsize,i;
	struct FLOATPT *t;
	CSelData *sel;

	if (isEmpty) return;
	GetClientRect(&r);
	dxoffs=r.right/2-offsetx
			  -(int)((refnode->x*cosPhi-refnode->y*sinPhi)/scale);
	dyoffs=r.bottom/2-offsety+(int)((refnode->y*cosPhi*cosTheta+
				refnode->x*sinPhi*cosTheta+refnode->z*sinTheta)/scale);

	switch(mode) {
		case ID_MODE_BLOCK: 
		case ID_MODE_POLYGON: 
		case ID_MODE_OBJECT: 
			r.left=1<<30; r.right=-(1<<30);
			r.top=1<<30; r.bottom=-(1<<30);
			for (sel=this;sel!=NULL;sel=sel->multisel) {
				t=GetDocument()->trk[sel->refblock].ptBounding;
				zsize=(int)(200*sinTheta/scale);
				for (i=0;i<=3;i++) { 
					x=FloatX(t[i]);
					y=FloatY(t[i]);
					if (x<=r.left) r.left=x-1;
					if (x>=r.right) r.right=x+1;
					if (y-zsize<=r.top) r.top=y-zsize-1;
					if (y+zsize>=r.bottom) r.bottom=y+zsize+1;
				}
			}
			InvalidateRect(&r,FALSE); 
			break;
		case ID_MODE_EXTPOINT: // may later need to enlarge to circle
		case ID_MODE_POINT: 
			for (sel=this;sel!=NULL;sel=sel->multisel) {
				x=FloatX(*(sel->refnode));
				y=FloatY(*(sel->refnode));
				r.top=y-6; r.bottom=y+6;
				r.left=x-6; r.right=x+6;
				InvalidateRect(&r,!newstate);
			}
			break;
	}
}

void CT3EDView::OnViewRefresh() 
{
	InvalidateRect(NULL,TRUE);	
}

void CT3EDView::OnViewRecenter() 
{
	if ((offsetx==0)&&(offsety==0)) return;
	offsetx=0; offsety=0;
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnUpdateViewRecenter(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
}

BOOL CT3EDView::IsVisibleNode(int block,struct FLOATPT *pt)
{ 
// could be made much simpler using trk.nxxxxxVert !!!
	CT3EDDoc *pDoc=GetDocument();
	struct FLOATPT *v;
	struct OBJPOLYBLOCK *o;
	LPPOLYGONDATA p;
	int i,j,k,n;

	if (bShowLanes) return TRUE; // anything becomes visible
	if (pt==&myrefnode) return bShowObjects; // an xobj refpoint
	v=pDoc->trk[block].vert;
	p=pDoc->poly[block].poly[nDetail];
	n=pDoc->poly[block].sz[nDetail];
	for (i=0;i<n;i++,p++) {
		if (pt==v+p->vertex[0]) return TRUE;
		if (pt==v+p->vertex[1]) return TRUE;
		if (pt==v+p->vertex[2]) return TRUE;
		if (pt==v+p->vertex[3]) return TRUE;
	}
	if (bShowObjects) {
		for (j=0;j<4;j++) {
			o=&(pDoc->poly[block].obj[j]);
			if (o->n1==0) continue;
			for (k=0;k<o->nobj;k++) {
				p=o->poly[k];
				n=o->numpoly[k];
				for (i=0;i<n;i++,p++) {
					if (pt==v+p->vertex[0]) return TRUE;
					if (pt==v+p->vertex[1]) return TRUE;
					if (pt==v+p->vertex[2]) return TRUE;
					if (pt==v+p->vertex[3]) return TRUE;
				}
			}
		}
	}
	return FALSE;
}

BOOL CT3EDView::IsPolyOfDetail(int detail)
{
	if (refpoly==NULL) return FALSE;
	if (isxobj) return FALSE;
	if (refpolyobj>=0) return FALSE;
	return ((refpolychunk&6)==detail); // detail or detail+1
}

void CT3EDView::OnUpdateToolsMovexy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck(editMode==ID_TOOLS_MOVEXY);
}

void CT3EDView::OnToolsMovexy() 
{
	if (isDragging) return; // safety
	if (editMode==ID_TOOLS_MOVEXY) editMode=NULL;
	else editMode=ID_TOOLS_MOVEXY;
}

void CT3EDView::OnUpdateToolsMovez(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);
	pCmdUI->SetCheck(editMode==ID_TOOLS_MOVEZ);
}

void CT3EDView::OnToolsMovez() 
{
	if (isDragging) return; // safety
	if (editMode==ID_TOOLS_MOVEZ) editMode=NULL;
	else editMode=ID_TOOLS_MOVEZ;
}

void CT3EDView::OnMouseMove(UINT nFlags, CPoint point) 
{
	RECT rect;

	if (!(nFlags&MK_LBUTTON)) return;
	if (delayMouseMove) { delayMouseMove=FALSE; return; }
	if ((editMode!=ID_TOOLS_MOVEXY)&&(editMode!=ID_TOOLS_MOVEZ)) return;
	if (isDragging) ShowHideCursor(); // hide cursor
	else {
		// check if dragging is allowed
		if (selMode==ID_MODE_BLOCK) 
			if ((extraSmooth?1:smooth1Start)+2*smooth1Width
				>=GetDocument()->col.vroadHead.nrec-20) return;
		if (selMode==ID_MODE_POINT)
			if (!isTruePoint) return;
		if (selMode==ID_MODE_OBJECT)
			if ((!bShowObjects)||(objno<0)) return;
		if (selMode==ID_MODE_POLYGON)
			if (refpoly==NULL) return;
		isDragging=TRUE;
		SetCapture();
	}
	GetClientRect(&rect);
	if ((point.x<0)||(point.y<0)||(point.x>rect.right)||(point.y>rect.bottom)) 
		{ ReleaseCapture(); isDragging=FALSE; return; }
	dragX=point.x; dragY=point.y;
	if (editMode==ID_TOOLS_MOVEZ) dragX=rect.right/2-offsetx;
	if (((editMode==ID_TOOLS_MOVEZ)&&(theta==0))||
		((editMode==ID_TOOLS_MOVEXY)&&(theta==90)))
		dragY=rect.bottom/2-offsety;
	ShowHideCursor();
}

void CT3EDView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	float dx,dy,dz,a,b;
	RECT rect;
	CT3EDDoc *pDoc=GetDocument();
	int newblk,i,orgno,newno,orgblk;
	struct FLOATPT pt,*newpt;
	CSelData *sel,*sel2;

	if (!isDragging) return;
	GetClientRect(&rect);
	ShowHideCursor();
	isDragging=FALSE;
	ReleaseCapture();
	dragX=point.x; dragY=point.y;
	if (editMode==ID_TOOLS_MOVEZ) dragX=rect.right/2-offsetx;
	if (((editMode==ID_TOOLS_MOVEZ)&&(theta==0))||
		((editMode==ID_TOOLS_MOVEXY)&&(theta==90)))
		dragY=rect.bottom/2-offsety;

	dx=0; dy=0; dz=0;
	if ((editMode==ID_TOOLS_MOVEZ)&&(theta!=0))
		dz=(rect.bottom/2-offsety-dragY)*scale/sinTheta;
	if (editMode==ID_TOOLS_MOVEXY) {
		a=(dragX-rect.right/2+offsetx)*scale;
		if (theta==90) b=0;
		else b=(rect.bottom/2-offsety-dragY)*scale/cosTheta;
		dx=a*cosPhi+b*sinPhi;
		dy=-a*sinPhi+b*cosPhi;
	}
	// proceed with move depending on what we want
	pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
	switch(selMode) {
		case ID_MODE_BLOCK: 
			pDoc->MoveBlocks(refblock,dx,dy,dz,smooth1Start,smooth1Width,extraSmooth);
			break;
		case ID_MODE_POINT:
			for (sel=this;sel!=NULL;sel=sel->multisel)
				memcpy(sel->origpos,sel->refnode,12);
			for (sel=this;sel!=NULL;sel=sel->multisel)
				if (fabs(sel->refnode->x-sel->origpos->x)+
					fabs(sel->refnode->y-sel->origpos->y)+
					fabs(sel->refnode->z-sel->origpos->z) < 1E-3)
						pDoc->MovePointBy(sel->refnode,dx,dy,dz);
			break;
			pDoc->MovePointBy(refnode,dx,dy,dz);
			break;
		case ID_MODE_EXTPOINT:
			pDoc->ExtMovePointBy(refnode,dx,dy,dz,(float)smooth2Start,(float)smooth2Width);
			break;
		case ID_MODE_OBJECT:
			for (sel=this;sel!=NULL;sel=sel->multisel)
				sel->origflag=TRUE;
			for (sel=this;sel!=NULL;sel=sel->multisel) 
			if (sel->origflag) {
				orgblk=sel->refblock;
				orgno=sel->objno;
				newblk=pDoc->MoveObjectBy(orgblk,sel->isxobj,sel->objchunk,orgno,dx,dy,dz);
				for (sel2=this;sel2!=NULL;sel2=sel2->multisel)
					if ((sel2->refblock==orgblk)&&
						(sel2->isxobj==sel->isxobj)&&
						(sel2->objchunk==sel->objchunk)&&
						(sel2->objno==orgno))
							sel2->origflag=FALSE;
				if (newblk!=orgblk) {
					if (sel->isxobj==2) {
						newno=pDoc->trk[newblk].nLightsrc-1;
					} else
					if (sel->isxobj==1) {
						newno=pDoc->xobj[4*newblk+sel->objchunk].nobj-1;
						newpt=&(pDoc->xobj[4*newblk+sel->objchunk].obj[newno].ptRef);
					} else {
						newno=pDoc->poly[newblk].obj[sel->objchunk].nobj-1;
						newpt=pDoc->trk[newblk].vert+
							pDoc->poly[newblk].obj[sel->objchunk].poly[newno]->vertex[0];
					}
					for (sel2=this;sel2!=NULL;sel2=sel2->multisel)
						if ((sel2->refblock==orgblk)&&
							(sel2->isxobj==sel->isxobj)&&
							(sel2->objchunk==sel->objchunk)) 
						{
							if (sel2->objno>orgno) sel2->objno--;
							else if (sel2->objno==orgno) { 
								sel2->objno=newno;
								sel2->refblock=newblk;
								if (sel2->isxobj!=2) sel2->refnode=newpt;
							}
						}
				}
			}
			UpdateRefBlock();
			break;
		case ID_MODE_POLYGON:
			for (sel=this;sel!=NULL;sel=sel->multisel) {
				for (i=0;i<4;i++) {
					memcpy(sel->origpos+i,
						sel->refvertices+sel->refpoly->vertex[i],12);
					if (sel->isxobj) { 
						sel->origpos[i].x+=sel->refnode->x;
						sel->origpos[i].y+=sel->refnode->y;
						sel->origpos[i].z+=sel->refnode->z;
					}
				}
			}
			for (sel=this;sel!=NULL;sel=sel->multisel) {
				for (i=0;i<4;i++) {
					memcpy(&pt,
						sel->refvertices+sel->refpoly->vertex[i],12);
					if (sel->isxobj) { 
						pt.x+=sel->refnode->x;
						pt.y+=sel->refnode->y;
						pt.z+=sel->refnode->z;
					}
					if (fabs(pt.x-sel->origpos[i].x)+
						fabs(pt.y-sel->origpos[i].y)+
						fabs(pt.z-sel->origpos[i].z) < 1E-3)
							pDoc->MovePointBy(&pt,dx,dy,dz);
				}
			}
			break;
	}
	InvalidateRect(NULL,TRUE);
	if ((selMode==ID_MODE_POLYGON)&&isxobj) return; // no scroll !
	offsetx=rect.right/2-dragX;
	offsety=rect.bottom/2-dragY;
	for (sel=this;sel!=NULL;sel=sel->multisel)
		if (sel->refnode==&sel->myrefnode) {
			sel->myrefnode.x+=dx; 
			sel->myrefnode.y+=dy; 
			sel->myrefnode.z+=dz;
		}
}

void CT3EDView::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((!isEmpty)&&(GetDocument()->undoLevel>0));
}

void CT3EDView::OnEditUndo() 
{
	CT3EDDoc *pDoc=GetDocument();
	int lev=pDoc->undoLevel-1;

	if (multisel) delete multisel; multisel=NULL;
	refnode=&myrefnode;
	memcpy(refnode,&(pDoc->undoRefpt[lev]),12);
	refblock=pDoc->undoRefblk[lev];
	offsetx=pDoc->undoOfsx[lev];
	offsety=pDoc->undoOfsy[lev];
	pDoc->PerformUndo();
	isTruePoint=FALSE; refpoly=NULL; objno=-1;
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnUpdateModeSmoothing(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&(selMode==ID_MODE_BLOCK||selMode==ID_MODE_EXTPOINT));
}

void CT3EDView::OnModeSmoothing() 
{
	if (selMode==ID_MODE_BLOCK) {
		CSmoothingBox1 dlg;
		dlg.m_sDist=smooth1Start;
		dlg.m_sWidth=smooth1Width;
		dlg.m_extraSmooth=extraSmooth;
		if (dlg.DoModal()!=IDOK) return;
		smooth1Start=dlg.m_sDist;
		smooth1Width=dlg.m_sWidth;
		extraSmooth=dlg.m_extraSmooth;
	}
	if (selMode==ID_MODE_EXTPOINT) {
		CSmoothingBox2 dlg;
		dlg.m_sDist=smooth2Start;
		dlg.m_sWidth=smooth2Width;
		if (dlg.DoModal()!=IDOK) return;
		smooth2Start=dlg.m_sDist;
		smooth2Width=dlg.m_sWidth;
	}
}

void CT3EDView::OnUpdateEditmodesExtrasmoothing(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&(selMode==ID_MODE_BLOCK));
	pCmdUI->SetCheck(!isEmpty&&extraSmooth);
}

void CT3EDView::OnEditmodesExtrasmoothing() 
{
	extraSmooth=!extraSmooth;	
}

void CT3EDView::OnUpdateToolsDelete(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&
	   (((selMode==ID_MODE_OBJECT)&&(objno!=-1))||
		((selMode==ID_MODE_POLYGON)&&(refpoly!=NULL))));
}

void CT3EDView::OnToolsDelete() 
{
	CDC *dc;
	RECT rect;
	CT3EDDoc *pDoc=GetDocument();

	if ((selMode==ID_MODE_POLYGON)&&(!isxobj)&&(refpolyobj==-1)&&
		(refpolychunk<=4)&&!(refpolychunk&1))
		if (pDoc->poly[refblock].sz[refpolychunk]==1) {
			AfxMessageBox("Can't remove the last polygon of a block !");
			return;
		}

	dc=GetDC(); // delete object to avoid flicker
	dc->SelectObject(redPen);
	dc->SetROP2(R2_WHITE);
	GetClientRect(&rect);
	ShowSelectionAt(dc,rect.right/2-offsetx,rect.bottom/2-offsety);
	ReleaseDC(dc);

	// multisel doesn't work here
	if (multisel) { delete multisel; multisel=NULL; }

	myrefnode.x=refnode->x; 
	myrefnode.y=refnode->y; 
	myrefnode.z=refnode->z;
	refnode=&myrefnode;

	pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
	if (selMode==ID_MODE_OBJECT)
		pDoc->DelObject(refblock,isxobj,objchunk,objno);
	else if (selMode==ID_MODE_POLYGON) {
		if (!isxobj&&(refpolychunk==4)&&(refpolyobj==-1)) {
			pDoc->DelTrackPolygon(refblock,refpolyno);
			InvalidateRect(NULL,TRUE);
		} else pDoc->DelPolygon(refblock,isxobj,refpolychunk,refpolyobj,refpolyno);
	}
	objno=-1; refpoly=NULL;
	InvalidateRect(NULL,FALSE);
}

void CT3EDView::OnUpdateToolsDuplicate(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&
		(((selMode==ID_MODE_OBJECT)&&(bShowObjects))||
		((selMode==ID_MODE_POLYGON)&&(refpoly!=NULL))));
}

void CT3EDView::OnToolsDuplicate() 
{
	CT3EDDoc *pDoc=GetDocument();
	CNewobjDlg newDlg;
	int texture;
	short flags;
	struct XOBJDATA *x;

	// multisel doesn't work here
	if (multisel) delete multisel; multisel=NULL;

	if (selMode==ID_MODE_OBJECT) { // object new/duplicate
		if (objno==-1) {
			newDlg.qfs=&(pDoc->qfsView);
			if (newDlg.DoModal()!=IDOK) return;
			isxobj=newDlg.m_xobj;
			objchunk=newDlg.m_chunk;
			texture=newDlg.m_texture;
			flags=newDlg.m_flags; 
		}
		pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
		if (objno==-1) {
			pDoc->NewObject(refblock,isxobj,objchunk,texture,flags);
			offsetx=0; offsety=0;
		}
		else pDoc->DuplObject(refblock,isxobj,objchunk,objno);
		InvalidateRect(NULL,(objno==-1));
		if (isxobj==2) {
			objno=pDoc->trk[refblock].nLightsrc-1;
			// refnode is still &myrefnode
		} else
		if (isxobj==1) {
			objno=pDoc->xobj[4*refblock+objchunk].nobj-1;
			refnode=&(pDoc->xobj[4*refblock+objchunk].obj[objno].ptRef);
		} else {
			objno=pDoc->poly[refblock].obj[objchunk].nobj-1;
			refnode=pDoc->trk[refblock].vert+
				pDoc->poly[refblock].obj[objchunk].poly[objno]->vertex[0];
		}
	} else { // polygon duplicate
		pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
		if (!isxobj&&(refpolychunk==4)&&(refpolyobj==-1))
			pDoc->DuplTrackPolygon(refblock,refpolyno);
		else refpolyno=pDoc->DuplPolygon(refblock,isxobj,refpolychunk,refpolyobj,refpolyno);
		if (isxobj) {
			x=pDoc->xobj[4*refblock+refpolychunk].obj+refpolyobj;
			refpoly=x->polyData+refpolyno;
			refvertices=x->vert;
			refnode=&(x->ptRef);
		} else {
			if (refpolyobj==-1) refpoly=pDoc->poly[refblock].poly[refpolychunk]+refpolyno;
			else refpoly=pDoc->poly[refblock].obj[refpolychunk].poly[refpolyobj]+refpolyno;
			refvertices=pDoc->trk[refblock].vert;
			refnode=refvertices+refpoly->vertex[0];
		}
		InvalidateRect(NULL,TRUE);
	}
}

void CT3EDView::OnUpdateToolsTexture(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&(selMode==ID_MODE_POLYGON)&&(refpoly!=NULL));
}

void CT3EDView::OnToolsTexture() 
{
	CT3EDDoc *pDoc=GetDocument();
	CQFSView *qfs=&(pDoc->qfsView);
	CSelData *sel;
	
	qfs->m_nBmp=refpoly->texture;
	qfs->m_flags=refpoly->unknown1;
	qfs->bHasHitFlags=FALSE;
	if (qfs->DoModal()!=IDOK) return;
	pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
	for (sel=this;sel!=NULL;sel=sel->multisel) {
		if (sel->isxobj)
			pDoc->PrepareModifyXobj(4*sel->refblock+sel->refpolychunk);
		else pDoc->PrepareModifyPoly(sel->refblock);
		sel->refpoly->texture=qfs->m_nBmp;
		if (pDoc->bHSMode && qfs->bHasHitFlags)
			sel->refpoly->unknown1=qfs->m_flags;
	}
}

void CT3EDView::OnToolsPolyflag() 
{
	CT3EDDoc *pDoc=GetDocument();
	CPolyFlags polydlg;
	struct POLYVROADDATA *data;
	LPPOLYGONDATA p;
	int i;
	CSelData *sel;

	data=pDoc->trk[refblock].polyData+refpolyno;
	polydlg.m_walldetect=((data->flags&0x80)!=0);
	polydlg.m_xobjdetect=((data->flags&0x40)!=0);
	polydlg.m_type=(data->flags&0x0f);
	polydlg.bHSMode=pDoc->bHSMode;
	if ((pDoc->bHSMode)&&((data->flags&0x0f)%14!=0)) {
		polydlg.m_hsForwNeighbor=(data->hs_orphan[0]!=0);
		polydlg.m_hsBackNeighbor=(data->hs_orphan[2]!=0);
	}
	if (multisel) { 
		polydlg.m_walldetect=2;
		polydlg.m_xobjdetect=2;
		polydlg.m_hsForwNeighbor=2;
		polydlg.m_hsBackNeighbor=2;
	}
	if (polydlg.DoModal()!=IDOK) return;

	pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);

	for (sel=this;sel!=NULL;sel=sel->multisel) 
		if ((sel->refpolyobj==-1)&&(sel->refpolychunk==4))
	{
		pDoc->PrepareModifyTrk(sel->refblock);
		data=pDoc->trk[sel->refblock].polyData+sel->refpolyno;
		if ((polydlg.m_type%14==0)&&((data->flags&0x0f)%14!=0)) {
			for (i=0;i<4;i++) // made it impassable : warn neighbors
				pDoc->SetCollisionHandling(pDoc->trk[sel->refblock].vert+sel->refpoly->vertex[i]);
			if (pDoc->bHSMode) {
				p=pDoc->poly[sel->refblock].poly[4]+sel->refpolyno-1;
				if (sel->refpolyno>0) 
					if ((p[0].vertex[1]==p[1].vertex[0])&&(p[0].vertex[2]==p[1].vertex[3]))
						if (((data-1)->flags&0x0f)%14!=0)
							(data-1)->hs_orphan[3]=0xFF; // no right edge
				if (sel->refpolyno<pDoc->poly[sel->refblock].sz[4]-1) 
					if ((p[1].vertex[1]==p[2].vertex[0])&&(p[1].vertex[2]==p[2].vertex[3]))
						if (((data+1)->flags&0x0f)%14!=0)
							(data+1)->hs_orphan[1]=0xFF; // no left edge
				memset(data->hs_orphan,0,4);
			}
		}
		if ((polydlg.m_type%14!=0)&&((data->flags&0x0f)%14==0)&&pDoc->bHSMode) {
			// made it passable : beware of neighbors
			p=pDoc->poly[sel->refblock].poly[4]+sel->refpolyno-1;
			data->hs_orphan[1]=data->hs_orphan[3]=0xFF;
			if (sel->refpolyno>0) // left edge
				if ((p[0].vertex[1]==p[1].vertex[0])&&(p[0].vertex[2]==p[1].vertex[3])) {
					(data-1)->hs_orphan[3]=0;
					data->hs_orphan[1]=(((data-1)->flags&0x0F)%14)?0:0xFF;
				}
			if (sel->refpolyno<pDoc->poly[sel->refblock].sz[4]-1) // right edge
				if ((p[1].vertex[1]==p[2].vertex[0])&&(p[1].vertex[2]==p[2].vertex[3])) {
					(data+1)->hs_orphan[1]=0;
					data->hs_orphan[3]=(((data+1)->flags&0x0F)%14)?0:0xFF;
				}
		}

		if ((pDoc->bHSMode)&&(polydlg.m_type%14!=0)) {
			if (polydlg.m_hsForwNeighbor<=1)
				data->hs_orphan[0]=polydlg.m_hsForwNeighbor?0xFF:0;
			if (polydlg.m_hsBackNeighbor<=1)
				data->hs_orphan[2]=polydlg.m_hsBackNeighbor?0xFF:0;
		}
		data->flags=(data->flags&0xf0)+polydlg.m_type;
		if (polydlg.m_xobjdetect==1) data->flags|=0x40;
		if (polydlg.m_xobjdetect==0) data->flags&=0xbf;
		if (polydlg.m_walldetect==1) data->flags|=0x80;
		if (polydlg.m_walldetect==0) data->flags&=0x7f;
		if ((polydlg.m_type%14!=0)&&((data->flags&0x0f)%14==0))
			data->flags|=0x80; // made it passable : beware of neighbors
	}
}

void CT3EDView::OnUpdateToolsPolyflag(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&(selMode==ID_MODE_POLYGON)&&(refpoly!=NULL)
		&&(refpolyobj==-1)&&(refpolychunk==4));
}

void CT3EDView::OnToolsMerge() 
{
	if (isDragging) return; // safety
	if (editMode==ID_TOOLS_MERGE) editMode=NULL;
	else editMode=ID_TOOLS_MERGE;
	if (multisel) {
		CleanCursorZone(selMode,FALSE);
		delete multisel; multisel=NULL;
	}
}

void CT3EDView::OnUpdateToolsMerge(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty&&(selMode==ID_MODE_POINT));
	pCmdUI->SetCheck(editMode==ID_TOOLS_MERGE);
}

void CT3EDView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CT3EDDoc *pDoc=GetDocument();

	if (editMode!=ID_TOOLS_MERGE) return;
	if (selMode!=ID_MODE_POINT) return;
	isTruePoint=FALSE;
	OnLButtonDown(0,point); // select point, recenter...
	if (!isTruePoint) return;
	isTruePoint=FALSE;
	myrefnode.x=refnode->x;
	myrefnode.z=refnode->z;
	myrefnode.y=refnode->y;
	refnode=&myrefnode;
	pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
	pDoc->SplitPoint(refnode);
	InvalidateRect(NULL,TRUE);
}

void CT3EDView::OnToolsAdjustwidth() 
{
	if (AfxMessageBox("This command will adjust the virtual\n"
		"track width to avoid the presence of any\n"
		"invisible walls on each side of the track.\n"
		"Do you want to proceed ?",
		MB_ICONWARNING|MB_OKCANCEL)!=IDOK) return;
	GetDocument()->PrepareNewUndo(refnode,refblock,offsetx,offsety);
	GetDocument()->AdjustRoadWidth();
	InvalidateRect(NULL,FALSE);
}

void CT3EDView::OnUpdateToolsAdjustwidth(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);	
}

void CT3EDView::OnToolsClearall() 
{
	CT3EDDoc *pDoc=GetDocument();
	CClearAll clearDlg;
	int i;
	struct XOBJBLOCK *x;

	clearDlg.qfs=&(pDoc->qfsView);
	if (clearDlg.DoModal()!=IDOK) return;
	pDoc->PrepareNewUndo(refnode,refblock,offsetx,offsety);
	// one never knows what happens here
	myrefnode.x=refnode->x;
	myrefnode.z=refnode->z;
	myrefnode.y=refnode->y;
	refnode=&myrefnode;
	isTruePoint=FALSE;
	refpoly=NULL; objno=-1;

	if (clearDlg.m_xobj)
		for (i=0;i<pDoc->nBlocks;i++)
			pDoc->DelAllObjects(i,TRUE);

	if (clearDlg.m_polyobj)
		for (i=0;i<pDoc->nBlocks;i++)
			pDoc->DelAllObjects(i,FALSE);

	if (clearDlg.m_fences) {
		for (i=0;i<pDoc->nBlocks;i++)
			pDoc->DelLanePolygons(i);
	}

	if (clearDlg.m_trackXY||clearDlg.m_trackZ) {
		pDoc->MoveBlocks(-1,0,0,0,clearDlg.m_trackXY,clearDlg.m_trackZ,FALSE);
		refnode=&(pDoc->trk[refblock].ptCentre);
		offsetx=0; offsety=0;
	}

	if (clearDlg.m_sceneryZ)
		pDoc->ClearSceneryZ();

	if (clearDlg.m_roadTextures)
		pDoc->SetAllTextures(clearDlg.m_roadTexture,TRUE,clearDlg.m_roadFlags);

	if (clearDlg.m_sceneryTextures)
		pDoc->SetAllTextures(clearDlg.m_sceneryTexture,FALSE,clearDlg.m_sceneryFlags);

	if (clearDlg.m_globalobj) {
		// can't keep consistent undo, so delete it all
		for (i=0;i<pDoc->undoLevel;i++) pDoc->DeleteUndo(i);
		pDoc->undoLevel=0;
		// global xobj
		x=&(pDoc->xobj[4*pDoc->nBlocks]);
		pDoc->FreeXobjContents(x);
		x->obj=NULL;
		x->nobj=0;
		if (pDoc->hs_morexobjlen>0) {
			pDoc->hs_morexobj=(char *)realloc(pDoc->hs_morexobj,8);
			pDoc->hs_morexobjlen=8; // two 0L's
			memset(pDoc->hs_morexobj,0,8);
		}
		// COL objects
		if (pDoc->col.struct3D!=NULL) 
			for (i=0;i<pDoc->col.struct3DHead.nrec;i++) {
				dofree(pDoc->col.struct3D[i].vertex);
				dofree(pDoc->col.struct3D[i].polygon);
			}
		dofree(pDoc->col.struct3D);
		pDoc->col.struct3D=NULL;
		if (pDoc->col.object!=NULL)
			for (i=0;i<pDoc->col.objectHead.nrec;i++)
				dofree(pDoc->col.object[i].animData);
		dofree(pDoc->col.object);
		pDoc->col.object=NULL;
		if (pDoc->col.object2!=NULL)
			for (i=0;i<pDoc->col.object2Head.nrec;i++)
				dofree(pDoc->col.object2[i].animData);
		dofree(pDoc->col.object2);
		pDoc->col.object2=NULL;
		pDoc->col.nBlocks=2;
		pDoc->col.fileLength=24+pDoc->col.textureHead.size+pDoc->col.vroadHead.size;
		pDoc->col.xbTable[0]=8;
		pDoc->col.xbTable[1]=8+pDoc->col.textureHead.size;
	}

	InvalidateRect(NULL);
}

void CT3EDView::OnUpdateToolsClearall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!isEmpty);	
}
