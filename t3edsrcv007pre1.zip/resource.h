//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by T3ED.rc
//
#define IDD_ABOUTBOX                    100
#define ID_INDICATOR_BLOCKNUM           101
#define ID_INDICATOR_SCROLLMODE         103
#define IDR_MAINFRAME                   128
#define IDR_T3EDTYPE                    129
#define IDD_SMOOTHING1                  132
#define IDD_SMOOTHING2                  133
#define IDD_TEXTURES                    135
#define IDD_LOADING_QFS                 136
#define IDD_NEWOBJECT                   137
#define IDD_POLYFLAGS                   138
#define IDD_CLEARTRACK                  140
#define IDD_TEXTUREPROPS                141
#define IDC_COPYRIGHT                   1000
#define IDC_CHECK1                      1008
#define IDC_SMOOTH1_STATIC1             1009
#define IDC_SMOOTH1_STATIC2             1010
#define IDC_CHECK3                      1010
#define IDC_SMOOTH1_STATIC3             1011
#define IDC_CHECK4                      1011
#define IDC_SMOOTH1_STATIC4             1012
#define IDC_CHECK5                      1012
#define IDC_EDIT2                       1013
#define IDC_CHECK6                      1013
#define IDC_EDIT1                       1014
#define IDC_CHECK8                      1014
#define IDC_BITMAP                      1015
#define IDC_CHECK7                      1015
#define IDC_SPIN1                       1016
#define IDC_EDIT7                       1016
#define IDC_NUMBMP                      1017
#define IDC_CHECK9                      1017
#define IDC_FILEOPEN                    1018
#define IDC_PROGRESS1                   1019
#define IDC_RADIO1                      1020
#define IDC_RADIO2                      1021
#define IDC_CHUNK0                      1022
#define IDC_CHUNK1                      1023
#define IDC_CHUNK2                      1024
#define IDC_CHUNK3                      1025
#define IDC_BROWSE                      1026
#define IDC_CHECK2                      1027
#define IDC_COMBO1                      1029
#define IDC_BROWSE6                     1031
#define IDC_BROWSE7                     1032
#define IDC_EDIT6                       1033
#define IDC_HSPROPS                     1034
#define IDC_ROTNONE                     1035
#define IDC_ROT90                       1036
#define IDC_ROT180                      1037
#define IDC_ROT270                      1038
#define IDC_TILINGNONE                  1039
#define IDC_TILINGHOR2                  1040
#define IDC_TILINGHOR4                  1041
#define IDC_TILINGVERT2                 1042
#define IDC_TILINGVERT4                 1043
#define IDC_FLIPH                       1044
#define IDC_FLIPV                       1045
#define IDC_TWOSIDED                    1046
#define ID_VIEW_ZOOMIN                  32794
#define ID_VIEW_ZOOMOUT                 32795
#define ID_VIEW_ROTATE                  32798
#define ID_VIEW_HEIGHT                  32800
#define ID_MODE_BLOCK                   32801
#define ID_MODE_POINT                   32802
#define ID_MODE_EXTPOINT                32803
#define ID_MODE_OBJECT                  32804
#define ID_MODE_POLYGON                 32805
#define ID_MODE_SMOOTHING               32806
#define ID_TOOLS_MOVEXY                 32808
#define ID_TOOLS_MOVEZ                  32809
#define ID_TOOLS_TEXTURE                32813
#define ID_VIEW_FULLRES                 32815
#define ID_VIEW_HALFRES                 32816
#define ID_VIEW_LOWRES                  32817
#define ID_VIEW_NODESONLY               32818
#define ID_TOOLS_DELETE                 32819
#define ID_TOOLS_DUPLICATE              32820
#define ID_TOOLS_PROPERTIES             32821
#define ID_VIEW_SHOWHIDEOBJECTS         32822
#define ID_VIEW_RECENTER                32826
#define ID_VIEW_REFRESH                 32827
#define ID_VIEW_SHOWLANES               32828
#define ID_EDITMODES_EXTRASMOOTHING     32829
#define ID_TOOLS_MERGE                  32830
#define ID_TOOLS_POLYFLAG               32832
#define ID_TOOLS_ADJUSTWIDTH            32833
#define ID_TOOLS_CLEARALL               32834

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32835
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
